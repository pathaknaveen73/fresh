import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class HeaderService {

  constructor(private apiService: ApiService) { }

  // function to logout user
  logoutUser(payload) {
    const url = 'logout';
    return this.apiService.postApi(url, payload);
  }

  // function to search product
  searchRegularProduct(payload) {
    const url = 'searchProduct';
    return this.apiService.postApi(url, payload);
  }

  // function to search gyan product
  searchGyanProduct(payload) {
    const url = 'searchGyanstarProducts';
    return this.apiService.postApi(url, payload);
  }

  // update device token after getting it
  updateDeviceToken(payload) {
    const url = 'updateDeviceToken';
    return this.apiService.postApi(url, payload);
  }

  // function to get notification list
  getNotificationList() {
    const url = 'getNotificationList';
    return this.apiService.getApi(url);
  }

  // function to send read notification receipt
  sendReadReceipt(payload, id) {
    const url = 'readNotification/' + id;
    return this.apiService.putApi(url, payload);
  }

  // function to get subscription detail by ID
  getSubscriptionDetail(payload) {
    const url = 'subscriptionDetail/' + payload.id;
    return this.apiService.getApi(url);
  }

   // update device token after getting it
   addUserVersion(payload) {
    const url = 'addUserVersion';
    return this.apiService.postApi(url, payload);
  }

  // DC rating
  addDCrating(payload) {
    const url = 'addDCRating';
    return this.apiService.postApi(url, payload);
  }

  // function to get user profile
  getUserProfile() {
    const url = 'getProfile';
    return this.apiService.getApi(url);
  }
}
