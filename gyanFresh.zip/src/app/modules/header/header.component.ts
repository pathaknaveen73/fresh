import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/serviceFile/common.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HeaderService } from './serviceFile/header.service';
import Swal from 'sweetalert2';
import { AngularFireMessaging } from '@angular/fire/messaging';
import { mergeMap, debounceTime, take } from 'rxjs/operators'
import { Subscription } from 'rxjs';
import { environment } from 'src/environments/environment';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';
declare let $: any;
declare let clevertap: any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, AfterViewInit {
  totalItem;
  searchTerm = new FormControl('');
  searchTerm1 = new FormControl('');
  previouslySearchedTerm;
  options = [];
  userInfo;
  imageSelected = false;
  url: string;
  searchProductBox = true;
  searchGyanProductBox = false;
  fcmIDexist = false;
  messages = [];
  unreadNotifyCount;
  notificationArr;
  addressss = localStorage.getItem('isAdd');
  isAddress = true;
  // addressSubs: Subscription;
  showStar = false;
  walletData;
  cartCount;
  ratingFlag = false;
  tipWallet = [];
  tipStar = [];
  championDetailID = '';
  ratingForm: FormGroup;
  addTipFlag = false;
  tipArr = [];
  submittedRatingForm = false;
  profileSubs: Subscription;
  walletNeededBal = 0;
  rating$: Subscription;

  constructor(private commonService: CommonService, private router: Router, private sharedService: SharedService,
              private headerService: HeaderService, private route: ActivatedRoute, private afMessaging: AngularFireMessaging,
              private fb: FormBuilder, private fireAnalytics: FirebaseAnalyticsCustomService) {
                if (this.addressss === '1') {
                  this.isAddress = true;
                } else {
                  this.isAddress = false;
                }
               }

  ngOnInit(): void {
    this.createRatingForm();
    // to get user profile data
    this.sharedService.getUserProfileInfo().subscribe(userProfileInfo => {
      this.userInfo = userProfileInfo;
      if (this.userInfo && this.userInfo.image) {
        this.imageSelected = true;
      }
    });
    this.sharedService.starData$.subscribe(res => {
      if (res) {
        if (res && res.status === 'ACTIVE') {
          this.showStar = true;
        } else {
          this.showStar = false;
        }
        // this.walletData = res.value;
      }
    });
    this.sharedService.cartCount$.subscribe(res => {
      this.cartCount = res;
    });
    this.sharedService.walletData$.subscribe(res => {
      if (res) {
        this.walletData = res;
      }
    })
    // this.sharedService.getCount().subscribe(count => {
    //   this.totalItem = count;
    // });
    // this.sharedService.getAddressValidation().subscribe((res:any) => {
    //   // debugger
    //   console.log('CHECKadd', res);
    //   if (res === '1') {
    //     this.isAddress = true;
    //     // this.addressSubs.unsubscribe();
    //   } else {
    //     this.isAddress = false;
    //   }
    // });
    this.listen();
    // this.commonService.handleNotificationClick();
    this.getNotificationCount();
    if (Notification.permission === 'granted') {
      if (window.innerWidth < 992) {
        console.log('Mobile/tab detected');
      } else {
        this.requestPermission();
      }
    }

    // function to watch for url change
    // this.sharedService.getSearchBoxUrlParam().subscribe(data => {
    //   if (data === 'gyanProduct') {
    //     this.searchGyanProductBox = true;
    //     this.searchProductBox = false;
    //     this.searchTerm1.setValue('');
    //   } else {
    //     this.searchProductBox = true;
    //     this.searchGyanProductBox = false;
    //     this.searchTerm.setValue('');
    //   }
    // });

    // function to check if url is opened in mobile or tablet
    if (window.innerWidth < 992) {
      console.log('Mobile/tab detected');
      this.requestPermission();
    }
    this.searchProduct();
    this.searchGyanProduct();
    function searchToggle(obj, evt){
      var container = $(obj).closest('.search-wrapper');
          if(!container.hasClass('active')){
              container.addClass('active');
              evt.preventDefault();
          }
          else if(container.hasClass('active') && $(obj).closest('.input-holder').length == 0){
              container.removeClass('active');
              // clear input
              container.find('.search-input').val('');
          }
  }

  $("#show_search").click(function(){
    $(".mobile_seach_fixed").show();
  });
  $("#hide_search").click(function(){
    $(".mobile_seach_fixed").hide();
  });
  // this.openRatingPopup();
    const firstRechargeAmount = this.getCookie('firstRechargeAmount');
    const transactionCount = this.getCookie('transactionCount');
    const rechargeAmount = this.getCookie('rechargeAmount');
    // alert(`checkRechargeAmount>>> ${rechargeAmount}`);
    setTimeout(() => {
      if (rechargeAmount !== '') {
        this.profileSubs = this.headerService.getUserProfile().subscribe((res1: any) => {
          if (res1 && res1.status === 200) {
            // alert(`old>>${transactionCount}, new>>${res1.data.transactionCount}`)
            const updatedTransactionCount = res1.data.transactionCount;
            let rechargeSuccess;
            rechargeSuccess = Number(updatedTransactionCount) > Number(transactionCount) ? true : false;
            if (rechargeSuccess) {
              if (Number(updatedTransactionCount) === 1) {
                this.sendEvent(Number(rechargeAmount));
              } else {
                this.sendEvent2(Number(rechargeAmount));
              }
            }
          }
       });
      }
    }, 10000);
    // this.openRatingPopup();
   }

   // create delivery champion rating form
   createRatingForm() {
     this.ratingForm = this.fb.group({
       rating: ['', [Validators.required]],
       walletType: ['GYAN_WALLET'],
       championId: [''],
       tipAmount: [''],
       feedback: ['']
     });
   }

   get f() { return this.ratingForm.controls; }

  //  ratingChanges() {
  //    this.rating$ = this.ratingForm.controls.rating.valueChanges.subscribe(res => {
  //      if (Number(res) < 3) {}
  //    });
  //  }

  // function to subscribe notification
  getNotificationCount() {
    this.sharedService.getNotificationCount().subscribe((notifications: any) => {
      this.notificationArr = notifications;
      // this.unreadNotifyCount = ncount.length;
      this.getNotificaitons();
      let unreadNotificationArr = [];
      notifications.forEach(element => {
          if (element.read === 'UNREAD') {
            unreadNotificationArr.push(element);
          }
        });
      this.unreadNotifyCount = unreadNotificationArr.length;
      // console.log('NOTI', this.unreadNotifyCount);
    });
  }

  findMe() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        // console.log(position);
      });
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  }
  home() {
    this.router.navigate(['page']);
  }
  navigateToCart() {
    this.router.navigate(['page/cart']);
  }

  // function to logout user
  logout() {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to logout !',
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        const deviceID = localStorage.getItem('gyannFCMdeviceId');
        if (deviceID) {
          const deviceIdPayload = {
            deviceId: localStorage.getItem('gyannFCMdeviceId'),
            deviceType: 'web'
          };
          // console.log('logout deviceId update');
          this.headerService.logoutUser(deviceIdPayload).subscribe(response => {
            // console.log(response.message);
          });
        }
        clevertap.event.push('logout', {
          "platform": localStorage.getItem('deviceType')
        });

        if(localStorage.getItem('x-id') !=''){
         this.loginAsCustomer();
        }else{
          localStorage.clear();
        }

        this.commonService.showSuccess('Logout sucessfully');
        this.router.navigate(['/login']);
      } else if (result.dismiss === Swal.DismissReason.cancel) {
      }
    });
  }

/* From admin panel */
loginAsCustomer() {
  localStorage.removeItem('userToken');
  localStorage.removeItem('userLocation');
  localStorage.removeItem('userInfo');
  localStorage.removeItem('gyannFCMdeviceId');
  localStorage.removeItem('userToken');
  localStorage.removeItem('gyanReferralCode');      
  localStorage.removeItem('gName');
  localStorage.removeItem('user_idGyan');
  localStorage.removeItem('userStatus');
  localStorage.removeItem('gPhone');
  localStorage.removeItem('verifyOtpToken');
  localStorage.removeItem('userLocation'); 
}

  // function to navigate to address list
  address() {
    this.router.navigate(['page/address']);
  }
  // function to submit search term
  searchProduct() {
    this.searchTerm.valueChanges.pipe(debounceTime(500)).subscribe(data => {
      if (!data) {
        this.options = [];
        return;
      }
      let payload = {
        product: data
      };
      this.headerService.searchRegularProduct(payload).subscribe(response => {
        if (response.status === 200) {
          this.options = [];
          this.options = response.data;
        }
      });
    });
  }
  // function to navigate to profile
  profile() {
    this.router.navigate(['page/profile']);
  }
  // function to navigate to notifications
  notifications() {
    this.router.navigate(['page/notifications']);
  }

  // function to open searched product detail
  openSearchedProductDetail(productId) {
    // this.router.navigateByUrl('/page/product/list/' + productId);
    this.router.navigate(['/page/product/list/detail'], { queryParams: { id: productId } });
  }

  // function to search gyan product
  searchGyanProduct() {
    this.searchTerm1.valueChanges.pipe(debounceTime(500)).subscribe(data => {
      if (!data) {
        this.options = [];
        return;
      }
      let payload = {
        product: data
      };
      this.headerService.searchGyanProduct(payload).subscribe(response => {
        if (response.status === 200) {
          this.options = [];
          this.options = response.data;
        }
      });
    });
  }

  // function to opened searched gyan product detail
  openSearchedGyanProductDetail(productId) {
    this.router.navigateByUrl('/page/gyanStar/redeemStar/' + productId);
  }

  // function to request user for permission to send push notification
  requestPermission() {
    this.afMessaging.requestToken
      .subscribe(
        (token) => {
          console.log('Permission granted! Save to the server!', token);
          // this.commonService.showSuccess('You will recieve notifications');
          localStorage.setItem('gyannFCMdeviceId', token);
          $('.notificationReq').remove();
          // update device token after getting it
          const deviceID = localStorage.getItem('gyannFCMdeviceId');
          if (deviceID) {
            const deviceIdPayload = {
              deviceId: localStorage.getItem('gyannFCMdeviceId'),
              deviceType: 'web'
            };
            this.headerService.updateDeviceToken(deviceIdPayload).subscribe(resp => {
              if (resp.status === 200) {
                // console.log('deviceID updated sucessfully');
              } else {
                // console.log('deviceID not updated');
              }
            });
            const url = environment.api_url.split('/');
            const appUserVersion = {
              deviceId: localStorage.getItem('gyannFCMdeviceId'),
              deviceType: 'web',
              appVersion: url[5]
            };
            this.headerService.addUserVersion(appUserVersion).subscribe(res => {
              if (res && res.status === 200) {
                // if user already skipped rating form and 24 hrs not passed then don't open popup again
                const existUserId = this.getCookie('ratinguserid');
                if (existUserId !== '') {
                  const userID = localStorage.getItem('user_idGyan');
                  if (existUserId === userID) {
                    return;
                  }
                }
                // debugger

                // to delete starts
                // this.tipWallet = res.data && res.data.ratingDetail && res.data.ratingDetail.length ? res.data.ratingDetail[0].tipAmount : [];
                //   this.tipStar = res.data && res.data.ratingDetail && res.data.ratingDetail.length ? res.data.ratingDetail[0].tipStar : [];
                //   this.tipArr = [...this.tipWallet];
                //   this.ratingForm.controls.tipAmount.setValue(this.tipArr[0]);
                // to delete ends

                if ((res.data.ratingDetail && res.data.ratingDetail[0].enableRating) && (res.data.championDetail && res.data.championDetail.length && res.data.championDetail[0].orderStatusTrack.deliveryChampion._id)) {
                  this.tipWallet = res.data && res.data.ratingDetail && res.data.ratingDetail.length ? res.data.ratingDetail[0].tipAmount : [];
                  this.tipStar = res.data && res.data.ratingDetail && res.data.ratingDetail.length ? res.data.ratingDetail[0].tipStar : [];
                  this.tipArr = [...this.tipWallet];
                  this.ratingForm.controls.tipAmount.setValue(this.tipArr[0]);
                  this.ratingForm.controls.championId.setValue(res.data.championDetail[0].orderStatusTrack.deliveryChampion._id);
                  if (res.data.lastRatingGivenOn !== '') {
                    // do something logic to show popup
                    // datediff(parseDate(first.value), parseDate(second.value))
                    const firstDate = `${new Date(res.data.lastRatingGivenOn).getMonth() + 1}/${new Date(res.data.lastRatingGivenOn).getDate()}/${new Date(res.data.lastRatingGivenOn).getFullYear()}`;
                    const todayDate = `${new Date().getMonth() + 1}/${new Date().getDate()}/${new Date().getFullYear()}`;
                    const dayDiff = this.datediff(this.parseDate(firstDate), this.parseDate(todayDate));
                    if (dayDiff > 7) {
                      // show popup
                      // alert('rate champion');
                      this.ratingFlag = true;
                      setTimeout(() => {
                        // enable popup
                        this.openRatingPopup();
                      }, 1000);
                    }
                  } else {
                    // show popup directly
                    // alert('rate champion direct popup');
                    this.ratingFlag = true;
                    setTimeout(() => {
                      // enable popup
                      this.openRatingPopup();
                    }, 1000);
                  }
                }
              }
            });
          }
        },
        (error) => {
          // console.error(error);
          if (Notification.permission === 'denied') {
            this.commonService.showError('Permission denied!, Please check site settings in browser settings');
          }
        },
      );
  }

  parseDate(str) {
    const mdy = str.split('/');
    return new Date(mdy[2], mdy[0]-1, mdy[1]);
}

datediff(first, second) {
  // Take the difference between the dates and divide by milliseconds per day.
  // Round to nearest whole number to deal with DST.
  return Math.round((second-first)/(1000*60*60*24));
}

openRatingPopup() {
  $('#rating_tip').modal({
    backdrop: 'static',
    keyboard: false
  })
  $('#rating_tip').modal('show');
  setTimeout(() => {
    $('.icon').click(function(){
      $('.icon').removeClass("active");
      $(this).addClass("active");
    });
  }, 500);
}

walletTypeSelection() {
  if (this.ratingForm.controls.walletType.value === 'GYAN_WALLET') {
    this.tipArr = [...this.tipWallet];
  } else {
    this.tipArr = [...this.tipStar];
  }
  this.ratingForm.controls.tipAmount.setValue(this.tipArr[0]);
}

submitRatingForm() {
  // console.log('checkRatingFormValue>>>', this.f);
  if (!this.ratingForm.valid) {
    this.submittedRatingForm = true;
    return;
  }

  // console.log('checkRatingFormValueFinal', this.f);
  const obj = this.ratingForm.value;
  if (!this.addTipFlag) {
    obj.tipAmount = 0;
    obj.walletType = 'NONE';
  }
  if (obj.walletType === 'GYAN_WALLET') {
    if (this.walletData.walletAmount < obj.tipAmount) {
      this.walletNeededBal = Number(obj.tipAmount) - Number(this.walletData.walletAmount);
      $('#ratingTipAddMoney').modal('show');
      return;
    }
  } else if (obj.walletType === 'GYAN_STAR_WALLET') {
    if (this.walletData.walletStar < obj.tipAmount) {
      this.commonService.showError('Insufficient gyan star balance !');
      return;
    }
  }
  const closeModal = document.getElementById('skipBtn');
  this.headerService.addDCrating(obj).subscribe(res => {
    if (res && res.status === 200) {
      this.commonService.showSuccess(res.message);
      closeModal.click();
    } else {
      this.commonService.showError(res.message);
      closeModal.click();
    }
  }, err => {
    // this.commonService.showSuccess(err);
    closeModal.click();
  });
}

closeLessBalModal() {
  $('#ratingTipAddMoney').modal('hide');
}

// function to navigate to stripe checkout if wallet bal is below order total amount
navigateToAddMoney() {
  $('#ratingTipAddMoney').modal('hide');
  $('#rating_tip').modal('hide');
  const payload = {
    amount: this.walletNeededBal,
    currency: 'inr'
  };
  this.router.navigate(['page/wallet/addMoney'], { queryParams: { amount: this.walletNeededBal } });
}

  // function to delete fcm token
  deleteToken() {
    this.afMessaging.getToken
      .pipe(mergeMap(token => this.afMessaging.deleteToken(token)))
      .subscribe(
        (token) => { console.log('Token deleted!'); },
      );
  }

  // function to listen for messages
  listen() {
    if (localStorage.getItem('gyannFCMdeviceId')) {
      $('.notificationReq').remove();
    }
    this.afMessaging.messages
      .subscribe((message: any) => {
        console.log(message.notification.body);
        // this.commonService.showInfo(message.notification.body);
        this.showForegroundInfo(message.notification.body);
        this.sharedService.getNotifications();
        // this.messages.unshift(message['notification']);
        // if (this.messages.length >= 5) {
        //   this.messages.length = 4;
        // }
      });
  }

  // function to get notification list
  getNotificaitons() {

        const respMessage = [...this.notificationArr];
        if (respMessage.length >= 5) {
          respMessage.length = 5;
        }
        if (respMessage.length > 0) {
          respMessage.forEach(element => {
            element.body = element.description;
          });
          this.messages = respMessage;
        }
  }

  // notification redirect
  redirectNotification(data, orderId, subsciptionId, messageId) {
    if (data === 'ORDER_PLACED_ONCE' || data === 'ORDER_STATUS_CHANGED' || data === 'ORDER_PLACED') {
      const payload = {
        read: 'READ'
      };
      this.headerService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
          // this.router.navigate(['page/orders/viewOrder/' + orderId]);
          // this.router.navigate(['page/orders']);
          this.router.navigate(['page/gyan'], { skipLocationChange: true }).then(() => {
            this.router.navigate(['page/orders/viewPastOrder/' + orderId]);
          });
        }
      });
    } else if (data === 'SUBSCRIPTION_ADDED' || data === 'SUBSCRIPTION_UPDATED') {
      const payload = {
        read: 'READ'
      };
      this.headerService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
          // this.router.navigate(['page/subscription/list/' + subsciptionId]);
          this.getSubscriptionByid(subsciptionId);
        }
      });
    } else if (data === 'REFERAL_BONUS') {
      const payload = {
        read: 'READ'
      };
      this.headerService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
          this.router.navigate(['page/wallet']);
        }
      });
    } else if (data === 'MANUAL_NOTIFICATION') {
      const payload = {
        read: 'READ'
      };
      this.headerService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
          this.router.navigate(['page/notifications']);
        }
      });
    } else if (data === 'OFFER_ADDED') {
      const payload = {
        read: 'READ'
      };
      this.headerService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
          this.router.navigate(['page/offers']);
        }
      });
    } else {
      const payload = {
        read: 'READ'
      };
      this.headerService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
        }
      });
    }
  }

  showForegroundInfo(data: string) {
    this.commonService.showInfo(data);
  }

  getSubscriptionByid(_id) {
    const payload = {
      id: _id
    };
    this.commonService.showSpinner();
    this.headerService.getSubscriptionDetail(payload).subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.hideSpinner();
        console.log('subsDetail', res);
        const item = res.data;
        item.productInfo = JSON.parse(item.productInfo);
        const subsType = item.subscriptionDaysType === 'ONCE' ? 1 : 2;
          if (subsType === 1) {
            this.router.navigate(['/page/product/list/' + item._id + '/once'],
          { queryParams: { data: JSON.stringify(item), type: subsType, fromType: 'TOM' } });
          } else {
            this.router.navigate(['/page/product/list/' + item._id + '/editSubs'],
          { queryParams: { data: JSON.stringify(item), type: subsType, fromType: 'TOM' } });
          }
      } else {
        this.commonService.showError(res.message);
        this.commonService.hideSpinner();
      }
    }, error => {
      this.commonService.hideSpinner();
      this.commonService.showError(error);
    });
  }

  ngAfterViewInit() {
    setTimeout(() => {
      // debugger
      if (!this.isAddress) {
        Swal.fire({
          title: 'You have not added your delivery address !',
          text: 'Please add an address first',
          icon: 'warning',
          showCancelButton: true,
          allowOutsideClick: false,
          confirmButtonText: 'Add Address',
          cancelButtonText: 'Logout'
        }).then((result) => {
          if (result.value) {
            const title = [];
            this.router.navigate(['page/address/newAddress'], { queryParams: { title: JSON.stringify(title), first: '1' } });

          } else if (result.dismiss === Swal.DismissReason.cancel) {
            const deviceID = localStorage.getItem('gyannFCMdeviceId');
            if (deviceID) {
              const deviceIdPayload = {
                deviceId: localStorage.getItem('gyannFCMdeviceId'),
                deviceType: 'web'
              };
              // console.log('logout deviceId update');
              this.headerService.logoutUser(deviceIdPayload).subscribe(response => {
                // console.log(response.message);
                localStorage.clear();
                this.commonService.showSuccess('Logout sucessfully');
                this.router.navigate(['/login']);
              });
            }
            // localStorage.removeItem('userToken');
            // localStorage.removeItem('userLocation');
            // localStorage.removeItem('userInfo');
            // localStorage.removeItem('gyannFCMdeviceId');

          }
        });
      }
    }, 2000);
  }

  sendEvent(amount) {
    clevertap.event.push(app_strings.CUSTOME.FIRST_TIME_RECHARGE, {
      'Amount': amount,
      'date': new Date(),
      "platform": localStorage.getItem('deviceType')
    });
    this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.FIRST_TIME_RECHARGE, {
      'Amount': amount,
      'date': new Date(),
    });
    this.fireAnalytics.logRechargeEventFB(app_strings.FACEBOOK_PIXEL.FIRST_WALLET_RECHARGE, {
      'Amount': amount
    });
    this.fireAnalytics.logRechargeEventGA(app_strings.GOOGLE_ANALYTICS.FIRST_WALLET_RECHARGE, {
      'event': app_strings.GOOGLE_ANALYTICS.FIRST_WALLET_RECHARGE,
      'Amount': amount
    });
    this.delete_cookie('firstRechargeAmount');
    this.delete_cookie('transactionCount');
    this.delete_cookie('rechargeAmount');
    this.profileSubs.unsubscribe();
  }

  sendEvent2(amount) {
    clevertap.event.push(app_strings.CUSTOME.REPEAT_RECHARGE, {
      'Amount': amount,
      'date': new Date(),
      "platform": localStorage.getItem('deviceType')
    });
    this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.REPEAT_RECHARGE, {
      'Amount': amount,
      'date': new Date(),
    });
    this.fireAnalytics.logRechargeEventFB(app_strings.FACEBOOK_PIXEL.REPEAT_RECHARGE, {
      'Amount': amount
    });
    this.fireAnalytics.logRechargeEventGA(app_strings.GOOGLE_ANALYTICS.REPEAT_RECHARGE, {
      'event': app_strings.GOOGLE_ANALYTICS.REPEAT_RECHARGE,
      'Amount': amount
    });
    this.delete_cookie('firstRechargeAmount');
    this.delete_cookie('transactionCount');
    this.delete_cookie('rechargeAmount');
    this.profileSubs.unsubscribe();
  }

  getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

  delete_cookie(name) {
    document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
  }

  skipButtonClick() {
    // const closeModal = document.getElementById('skipBtn');
    const userID = localStorage.getItem('user_idGyan');
    this.setSkip24hrForRatingPopup('ratinguserid', userID, 1);
    // closeModal.click();
    $('#rating_tip').modal('toggle');
  }

  setSkip24hrForRatingPopup(name, value, days){
    if (days){
        const d = new Date();
        d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
        const expires = '; expires=' + d.toUTCString();
        document.cookie = name + '=' + value + expires + '; path=/';
    }
  }

}
