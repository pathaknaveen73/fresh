import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-notification-popup',
  templateUrl: './notification-popup.component.html',
  styleUrls: ['./notification-popup.component.scss']
})
export class NotificationPopupComponent implements OnInit, OnDestroy {

  constructor(private router: Router) { }

  ngOnInit(): void {
    console.log('component inititated');
  }

  // function to navigate to notifications
  notifications() {
    this.router.navigate(['page/notifications']);
  }

  // function on destroy of component
  ngOnDestroy() {
    console.log('component destroyed');
  }

}
