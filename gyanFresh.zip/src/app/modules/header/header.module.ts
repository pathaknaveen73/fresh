import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header.component';
import { HeaderService } from './serviceFile/header.service';
import { SidemenuModule } from '../sidemenu/sidemenu.module';
import {MatBadgeModule} from '@angular/material/badge';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {LazyLoadImageModule} from 'ng-lazyload-image';



@NgModule({
  declarations: [HeaderComponent],
  imports: [
    CommonModule,
    SidemenuModule,
    MatBadgeModule,
    ReactiveFormsModule,
    RouterModule,
    MatAutocompleteModule,
    LazyLoadImageModule
  ],
  exports: [HeaderComponent],
  providers: [HeaderService]
})
export class HeaderModule { }
