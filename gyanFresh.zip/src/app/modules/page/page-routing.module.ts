import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageComponent } from './page.component';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { ReferGuard } from 'src/app/guards/refer.guard';


const routes: Routes = [
  {
    path: '',
    component: PageComponent,
    children: [
      {
        path: 'home',
        loadChildren: () => import('../home/home.module').then(m => m.HomeModule)
      },
      {
        path: 'product',
        loadChildren: () => import('../product/product.module').then(m => m.ProductModule)
      },
      // {
      //   path: 'cart',
      //   loadChildren: () => import('../cart/cart.module').then(m => m.CartModule)
      // },
      {
        path: 'subscription',
        loadChildren: () => import('../subscriptions/subscriptions.module').then(m => m.SubscriptionsModule)
      },
      {
        path: 'address',
        loadChildren: () => import('../address/address.module').then(m => m.AddressModule)
      },
      {
        path: 'profile',
        loadChildren: () => import('../profile/profile.module').then(m => m.ProfileModule)
      },
      {
        path: 'notifications',
        loadChildren: () => import('../notification/notification.module').then(m => m.NotificationModule)
      },
      {
        path: 'wallet',
        loadChildren: () => import('../wallet/wallet.module').then(m => m.WalletModule)
      },
      // {
      //   path: 'pickup',
      //   loadChildren: () => import('../pickup/pickup.module').then(m => m.PickupModule)
      // },
      {
        path: 'orders',
        loadChildren: () => import('../order/order.module').then(m => m.OrderModule)
      },
      {
        path: 'gyanStar',
        loadChildren: () => import('../gyan-star/gyan-star.module').then(m => m.GyanStarModule)
      },
      {
        path: 'refer',
        loadChildren: () => import('../referral/referral.module').then(m => m.ReferralModule), canLoad: [ReferGuard]
      },
      {
        path: 'feedback',
        loadChildren: () => import('../feedback/feedback.module').then(m => m.FeedbackModule)
      },
      {
        path: 'static',
        loadChildren: () => import('../static-pages/static-pages.module').then(m => m.StaticPagesModule)
      },
      {
        path: 'offers',
        loadChildren: () => import('../offer/offer.module').then(m => m.OfferModule)
      },
      {
        path: 'content',
        loadChildren: () => import('../content/content.module').then(m => m.ContentModule)
      },
      {
        path: 'account-history',
        loadChildren: () => import('../account-history/account-history.module').then(m => m.AccountHistoryModule)
      },
      {
         path: '', redirectTo: 'home', pathMatch: 'full'
      },
      {
        path: '**', component: PageNotFoundComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PageRoutingModule { }
