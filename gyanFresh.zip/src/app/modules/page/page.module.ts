import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageComponent } from './page.component';
import { PageRoutingModule } from './page-routing.module';
import { HeaderModule } from '../header/header.module';
import { FooterModule } from '../footer/footer.module';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { BuyOnceService } from 'src/app/serviceFile/buyOnce.service';



@NgModule({
  declarations: [PageComponent, PageNotFoundComponent],
  imports: [
    CommonModule,
    PageRoutingModule,
    HeaderModule,
    FooterModule
  ],
  providers: [SharedService, BuyOnceService]
})
export class PageModule { }
