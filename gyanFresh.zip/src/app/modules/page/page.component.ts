import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { FirebaseAuthService } from 'src/app/serviceFile/firebaseAuth.service';

@Component({
  selector: 'app-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.scss']
})
export class PageComponent implements OnInit {
  //firebaseEmail = 'indranil@techugo.com';
  //firebaseAuthPassword = '123456';

  constructor(private sharedService: SharedService, private firebaseAuthService: FirebaseAuthService) { }

  ngOnInit(): void {
    // debugger
    // this.sharedService.getCartItems();
    // this.sharedService.checkAddress();
    this.sharedService.getAllLocation();
    this.sharedService.nearbyGFS();
    this.sharedService.getUserProfile();
    this.sharedService.getNotifications();
    this.sharedService.fetchUserHome();
    this.sharedService.getCartData();
    this.sharedService.fetchBalance();
    // this.firebaseAuthService.SignIn(this.firebaseEmail, this.firebaseAuthPassword);
  }

}
