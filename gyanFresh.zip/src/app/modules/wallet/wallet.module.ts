import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WalletListComponent } from './component/wallet-list/wallet-list.component';
import { Routes, RouterModule } from '@angular/router';
import { AddMoneyComponent } from './component/add-money/add-money.component';
import { AutoRechargeComponent } from './component/auto-recharge/auto-recharge.component';
import { StripeCheckoutComponent } from './component/stripe-checkout/stripe-checkout.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxStripeModule } from 'ngx-stripe';
import { WalletService } from './serviceFile/wallet.service';
import { CheckoutComponent } from './component/checkout/checkout.component';
import { DaterangepickerComponent } from './component/daterangepicker/daterangepicker.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MatMomentDateModule } from '@angular/material-moment-adapter';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import { SuccessComponent } from './component/success/success.component';
import { FailComponent } from './component/fail/fail.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { RazorpayComponent } from './component/razorpay/razorpay.component';
import { StandardCheckoutComponent } from './component/standard-checkout/standard-checkout.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
import {MatCardModule} from '@angular/material/card';

export const routes: Routes = [
  { path: '', component: WalletListComponent, pathMatch: 'full' },
  { path: 'addMoney', component: AddMoneyComponent },
  { path: 'autoRecharge', component: AutoRechargeComponent },
  { path: 'checkout', component: CheckoutComponent },
  { path: 'success', component: SuccessComponent },
  { path: 'fail', component: FailComponent },
  { path: 'proceedCheckout', component: RazorpayComponent },
  { path: 'standard-checkout', component: StandardCheckoutComponent }
];

@NgModule({
  declarations: [WalletListComponent, AddMoneyComponent, AutoRechargeComponent, StripeCheckoutComponent,
    CheckoutComponent, DaterangepickerComponent, SuccessComponent, FailComponent, RazorpayComponent, StandardCheckoutComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    NgxStripeModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    InfiniteScrollModule,
    CarouselModule,
    MatCardModule
  ],
  exports: [WalletListComponent],
  providers: [WalletService, {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}],
  entryComponents: [DaterangepickerComponent]
})
export class WalletModule { }
