import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WalletService } from '../../serviceFile/wallet.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import Swal from 'sweetalert2';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { MatDialog } from '@angular/material/dialog';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { environment } from 'src/environments/environment';
import { take } from 'rxjs/operators';
import { ScriptService } from 'src/app/_scripts/script.service';
import { v4 as uuidv4 } from 'uuid';
declare let $: any;
declare var clevertap: any;
declare var Razorpay: any;

@Component({
  selector: 'app-add-money',
  templateUrl: './add-money.component.html',
  styleUrls: ['./add-money.component.scss']
})
export class AddMoneyComponent implements OnInit {
  addMoneyForm: FormGroup;
  submitted = false;
  showCouponCodeFlag = true;
  autoRechargeDetail;
  cashCollectFlag: boolean;
  razorPayOptions = {
    "key": 'rzp_live_y62aN38w8dhRlw',  // rzp_test_wwHXgyLEIsXlWT  rzp_live_Dgv9W0Euq5meCV
    "amount": '',
    "currency": '',
    "order_id": '',
    "handler": (res) => {
      console.log(res);
    },
    // "prefill.method": '',
    "prefill.email": 'care@gyandairy.com',
    "prefill.contact": '',
    "prefill.name": '',
    "image": ''
  };
  totalAmount = 0;
  transactionId;
  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: true,
    nav: false,
    navSpeed: 700,
    autoplay: true,
    // navText: ['', ''],
    center: true,
    autoplayHoverPause: true,
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 1
      },
      740: {
        items: 1
      },
      940: {
        items: 1
      }
    },
    // nav: false
};
couponData = [
  { title: '7 days free milk',
    description: ['Recharge with Rs 500 or more', 'Apply coupon code before recharge', 'Place your first order'],
    code: 'FREEMILK',
    expand: false },
  { title: 'Get upto Rs 500 cashback in your wallet',
    description: ['First recharge', 'Wallet recharge value should be Rs500 or more', 'Only for Kanpur users'],
    code: 'GYAN10',
    expand: false },
  { title: 'Get upto Rs 1000 cashback in your wallet',
    description: ['First recharge', 'Wallet recharge value should be Rs500 or more', 'Only for Kanpur users'],
    code: 'GYAN20',
    expand: false },
  { title: 'Get upto Rs 1000 cashback in your wallet',
    description: ['First recharge', 'Wallet recharge value should be Rs500 or more', 'Only for Kanpur users'],
    code: 'GYAN20',
    expand: false }
];
slidesStore = [
  { id: '1', title: '7 days free milk with this coupon' },
  { id: '2', title: 'Recharge with Rs 250 and get Rs 250 back in your wallet' },
  { id: '3', title: 'Reacharge now and get one full cream 500ml free with any order' }
];
selectedCouponCode = '';
appliedCoupon = false;
availableOfferArr = [];
userid;
baseURL = environment.api_url;
disableBtn = false;
selectedCouponObj;
userMobile;
primaryLocation;

  constructor(private router: Router, private fb: FormBuilder, private walletService: WalletService,
              private commonService: CommonService, private route: ActivatedRoute,
              private fireAnalytics: FirebaseAnalyticsCustomService,
              public dialog: MatDialog, private sharedService: SharedService,
              private script: ScriptService) { }

  ngOnInit(): void {
    this.userid = localStorage.getItem('user_idGyan');
    this.userMobile = localStorage.getItem('gPhone');
    this.slidesStore = [];
    this.primaryLocation = localStorage.getItem('primaryLocation');


    /* filter datepicker start here */
  // $('#dp').datepicker({ isRTL: true });
  // $('#filteropen').on('click', function () {
  //   $('#dp').focus();
  // });
 /* filter datepicker end here */
    this.route.queryParams.subscribe(params => {
      if (params && params.amount) {
        this.totalAmount = params.amount;
      }
    })
    this.setFormField();
    this.getAutoRechargeDetail();
    this.getAvailableOffers();
  }

  // function to navigate to checkout
  navigateCheckout() {
    this.router.navigate(['page/wallet/proceedCheckout']);
  }

  // function to set add money form field
  setFormField() {
    this.addMoneyForm = this.fb.group({
      amount: [this.totalAmount ? this.totalAmount : '', [Validators.required, Validators.min(1)]],
      coupon: ['']
    });
  }

  // function to get form controls
  get f() { return this.addMoneyForm.controls; }

  // function on submit of add money form field
  submit() {
    // this.submitted = true;
    // if (!this.addMoneyForm.valid || (this.cashCollectFlag && this.addMoneyForm.controls.amount.value < 3000)) {
    //   console.log('invalidAddMoneyForm', this.addMoneyForm.controls);
    //   return;
    // }
    if (this.cashCollectFlag) {
      this.cashCollect();
      return;
    }
    const payload = {
      // amount: this.addMoneyForm.controls.amount.value * 100,   // for stripe payment
      // currency: 'inr'
      amount: this.addMoneyForm.controls.amount.value
    };
    // this.router.navigate(['page/wallet/proceedCheckout'], {queryParams: {data: JSON.stringify(payload)}});
    try {
      clevertap.event.push(app_strings.CT_WALLET_RECHARGE_PROCESS, {
        'paymentType': 'RazorPay',
        'rechargeAmount': payload.amount,
        "platform": localStorage.getItem('deviceType')
      });
      this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.WALLET_RECHARGE_IN_PROCESS, {
        'paymentType': 'RazorPay',
        'rechargeAmount': payload.amount,
      });
    } catch (error) {
      console.log(error);
    }
    this.router.navigate(['page/wallet/standard-checkout'], {queryParams: {data: JSON.stringify(payload)}});
    return;
    this.createOrder();
  }

  // function to get auto recharge details
  getAutoRechargeDetail() {
    this.walletService.getAutoRechargeDetail().subscribe(response => {
      if (response.status === 200) {
        this.autoRechargeDetail = response.data;
        console.log('autoRechargeDetail', this.autoRechargeDetail);
      }
    });
  }

  // function to accept number only
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // function to request cash collect
  cashCollect() {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to add money through cash collection ',
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        const payload = {
          amount: this.addMoneyForm.controls.amount.value
        };
        this.walletService.cashCollect(payload).subscribe(response => {
          if (response.status === 200) {
            this.commonService.showSuccess(response.message);
            this.router.navigate(['page/wallet']);
          } else {
            this.commonService.showError(response.message);
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {

      }
    });
  }

  createOrder() {
    const payload = {
      amount: Number(this.f.amount.value * 100),
      // currency: 'INR',
      // name: this.userinfo.firstName + ' ' + this.userinfo.lastName
    };
    this.walletService.createOrder(payload).subscribe(res => {
      if (res && res.status === 200) {
        console.log('orderCreated', res);
        // this.mainService.hideSpinner();
        this.razorPayOptions.amount = res.data.amount;
        this.razorPayOptions.order_id = res.data.id;
        this.razorPayOptions.currency = res.data.currency;
        this.razorPayOptions.handler = this.razorpayResponseHandler.bind(this);
        this.razorPayOptions["prefill.contact"] = '+' + '91' + localStorage.getItem('gPhone');
        // this.razorPayOptions["prefill.email"] = localStorage.getItem('userEmail');
        this.razorPayOptions["image"] = "assets/img/notLogo.png"
        this.razorPayOptions["prefill.name"] = localStorage.getItem('gName');
        // this.razorPayOptions["prefill.method"] = this.paymentSelected;
        var rzp = new Razorpay(this.razorPayOptions);
        rzp.open();
        console.log('opened');
      } else {
        this.commonService.showError(res.message);
      }
    }, error => {
      this.commonService.showError(error);
    });
  }

  razorpayResponseHandler (response) {
    console.log(response);
    // return;
    this.transactionId = response.razorpay_payment_id;
    const payload = {
      paymentMode: 'RAZOR_PAY',
      status: 'ACTIVE',
      trackId: response.razorpay_payment_id,
      // razorpayOrderId: response.razorpay_order_id,
      // razorpayPaymentId: response.razorpay_payment_id,
      // razorpaySignature: response.razorpay_signature,
      amount: this.f.amount.value
    };
    console.log('orderPlacePayload', payload);
    this.walletService.savePaymentData(payload).subscribe(res => {
      if (res && res.status === 200) {
        sessionStorage.setItem('GT-id', response.razorpay_payment_id);
        try {
          clevertap.event.push(app_strings.CT_WALLET_RECHARGE_SUCCESS, {
            'addedAmount': this.f.amount.value,
            "platform": localStorage.getItem('deviceType')
          });
          this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.WALLET_RECHARGED, {
            'addedAmount': this.f.amount.value,
          });
        } catch (error) {
          console.log(error);
        }
        this.router.navigate(['page/wallet/success'], { queryParams: { id: response.razorpay_payment_id, amount: this.f.amount.value } });
      } else {
        this.commonService.showError(res.message);
      }
    }, error => {
      this.commonService.showError(error);
    });
  }

  getAvailableOffers() {
    this.walletService.availableOffers().subscribe(res => {
      if (res && res.status === 200) {
          this.availableOfferArr = res.data;
          this.availableOfferArr.forEach(element => {
            element.expand = false;
            if (element.customer_type === 'NEW_CUSTOMER' && element.couponCode === 'MILK7') {
              this.applyCoupon(element.couponCode, element.title);
            }
          });
      }
    });
  }

  openDialog() {
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '600px',
      height: 'auto',
      disableClose: false,
      data: {type: 'coupon', data: this.availableOfferArr}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('check>>>', result);
        this.applyCoupon(result);
      }
    });
  }

  applyCoupon(result, firstRecharge?: string) {
    if (result && result === this.selectedCouponCode) {
      this.commonService.showWarning(`${result} Coupon Code is already applied`);
      return;
    }
    this.walletService.applyCoupoon({ couponCode: result }).subscribe(res1 => {
      if (res1 && res1.status === 200) {
        if (firstRecharge) {
          this.commonService.showSuccess(firstRecharge, `WOHOO!! ${result} Applied`);
        } else {
          this.commonService.showSuccess(`WOHOO!! ${result} Applied`);
        }
        this.selectedCouponCode = result;
        this.showCouponCodeFlag = false;
        this.selectedCouponObj = res1.data;
      } else {
        this.commonService.showWarning(res1.message);
      }
    }, err => {
      this.commonService.showWarning(err);
    });
  }

  removeCoupon(submitType: boolean, code?: string) {
    const payload = {
      couponCode: code ? code : 'NO_COUPON'
    };
    this.commonService.showSpinner();
    this.walletService.removeCoupon(payload).subscribe(res => {
      this.commonService.hideSpinner();
      if (res && res.status === 200) {
        if (code) {
          this.showCouponCodeFlag = true;
          this.selectedCouponCode = '';
          this.appliedCoupon = false;
          this.selectedCouponObj = '';
        }
        if (submitType) {
          // this.submit();
          this.initPaytmPayment();
          // this.initJuspayPayment();
        }
      } else {
        console.log('aaaa')
        this.commonService.showError('Something went wrong, please try again !');
      }
    }, err => {
      console.log('err')
      this.commonService.showError('Something went wrong, please try again !');
    });
  }

  applyCouponClick() {
    this.appliedCoupon = true;
    if (!this.f.coupon.value) {
      return;
    }
    this.selectedCouponCode = this.f.coupon.value;
    this.showCouponCodeFlag = false;
  }

  checkSubmit() {
       //console.info('proceed click');   
    let pmLocation = JSON.parse(this.primaryLocation);   
    if(pmLocation.city._id =='5f85d7fd882e5a15e76a732a'){
      this.commonService.showWarning(`Dear customer, this is to inform you that we are temporarily not servicing your area. We regret the inconvenience caused`);
        return;
    }


    this.submitted = true;
    if (!this.addMoneyForm.valid || (this.cashCollectFlag && this.addMoneyForm.controls.amount.value < 3000)) {
      console.log('invalidAddMoneyForm', this.addMoneyForm.controls);
      return;
    }
    if (this.selectedCouponCode) {
      // const coupon = this.availableOfferArr.filter( x => x.couponCode === this.selectedCouponCode);
      const coupon = this.selectedCouponObj;
      if (coupon) {
        console.log(coupon);
        if (this.addMoneyForm.controls.amount.value < coupon.minRecharge) {
          this.commonService.showWarning(`Wallet Recharge value should be ₹${coupon.minRecharge} or more to avail this coupon code`);
          return;
        } else {
          // this.submit();
          // this.initPaytmPayment();
          this.initJuspayPayment();
        }
      }
    } else {
      this.removeCoupon(true);
    }
  }

  initPaytmPayment() {
  
    this.disableBtn = true;
    if (window['Paytm']) {
      this.createPaytmOrder();
    } else {
      this.script.load(`${environment.paytm.script}`).then(data => {
        // debugger;
        // console.log('script loaded ', data);
        // this.disableBtn = false;
        const timeInterval = setInterval(() => {
          if (window['Paytm'].CheckoutJS.init) {
            // this.disableBtn = false;
            console.log('clearingTimeIntervalNow');
            this.createPaytmOrder();
            clearInterval(timeInterval);
          }
        }, 500);
    }).catch(error => console.log(error));
    }
  }

  createPaytmOrder() {
    const orderid = `ORDERID_${new Date().getTime()}`;
    const checksumObj = {
      requestType: 'Payment',
      mid: environment.paytm.mid,
      websiteName: environment.paytm.websiteName,
      orderId: orderid,
      callbackUrl: `${this.baseURL}webSucessResponsePage`, // https://gyanfresh.gyandairy.com/api/user/v3/webSucessResponsePage
      txnAmount: {
        value: `${this.f.amount.value}.00`,
        currency: 'INR',
      },
      userInfo: {
        custId: `${this.userid}`
      }
    };
    this.walletService.createPaytmOrder(checksumObj).subscribe(res => {
      if (res && res.status === 200) {
        console.log('checksum', res);
        let config = {
          "root": "",
          "flow": "DEFAULT",
          "data": {
          "orderId": res.data.checksumReq.orderId, /* update order id */
          "token": res.data.body.txnToken, /* update token value */
          "tokenType": "TXN_TOKEN",
          "amount": res.data.checksumReq.txnAmount.value /* update amount */
          },
          "handler": {
            "notifyMerchant": (eventName,data) => {
              console.log("notifyMerchant handler function called");
              console.log("eventName => ",eventName);
              // console.log("data => ",data);
              if (eventName === 'APP_CLOSED') {
                this.disableBtn = false;
                this.delete_cookie('firstRechargeAmount');
                this.delete_cookie('transactionCount');
                this.delete_cookie('rechargeAmount');
              }
            }
          }
        };
        this.sharedService.getUserProfileInfo().pipe(take(1)).subscribe((res1: any) => {
          // console.log('check>>>>', res1);
          this.setCookie('firstRechargeAmount', res1.firstRechargeAmount ? res1.firstRechargeAmount : 0);
          this.setCookie('transactionCount', res1.transactionCount);
          this.setCookie('rechargeAmount', config.data.amount);

                    // initialze configuration using init method
          window['Paytm'].CheckoutJS.init(config).then( () => {
            debugger;
            // after successfully updating configuration, invoke JS Checkout
            window['Paytm'].CheckoutJS.invoke();
        }).catch((error) => {
            console.log("error => ",error);
            this.disableBtn = false;
            this.commonService.showError('Something went wrong, please try again later');
        });
        });
        this.sharedService.getUserProfile();
        // setInterval(() => {
        //   this.sharedService.getUserProfile();
        // }, 4000);
      }
    });
  }

  setCookie(cname, cvalue) {
    const d = new Date();
    d.setTime(d.getTime() + (24*60*400));
    let expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }

  delete_cookie(name) {
    document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
  }

  initJuspayPayment() {
    this.disableBtn = true;
    if (window['HyperServices']) {
      this.createJuspayOrder();
    } else {
      this.script.load(`juspay`).then(data => {
        // console.log('script loaded ', data);
        // this.disableBtn = false;
        const timeInterval = setInterval(() => {
          if (window['HyperServices']) {
            // this.disableBtn = false;
            console.log('clearingTimeIntervalNow');
            this.createJuspayOrder();
            clearInterval(timeInterval);
          }
        }, 500);
    }).catch(error => console.log(error));
    }
  }

  createJuspayOrder() {
    this.disableBtn = false;
    // alert('hyper available in window');
    const requestid = uuidv4();
    const payload = {
      "requestId" : requestid, //UUID v4 String
      "service" : "in.juspay.hyperpay",
      "payload"  : {
          "clientId" : "gyandairy"
      }
    };
    window['HyperServices'].preFetch(payload); // skip this step
    const signPayload = {
      merchant_id: 'gyandairy',
      customer_id: `${this.userid}`,
      mobile_number: `${this.userMobile}`,
      email_address: 'rakesh.k@srmtechsol.com',
      first_name: 'Rakesh',
      last_name: 'Kumar',
      timestamp: `${new Date().getTime()}`
    };
    const hyperServiceObject = new window['HyperServices']();
    this.walletService.fetchSignedOrderPayload(signPayload).pipe(take(1)).subscribe(res => {
      if (res && res.status === 200) {
        console.log(res.data);
        // debugger
        const initiatePayload = {
          action: 'initiate',
          clientId: 'gyandairy',
          merchantId: 'gyandairy',
          merchantKeyId: '5093',
          signaturePayload: res.data.payload,
          signature : res.data.signature, // Signature generated for signaturePayload
          environment: 'sandbox', // sandbox or production
          integrationType: 'redirection'
          // hyperSDKDiv: "juspay_iframe" // Div ID to be used for rendering
       };

        const sdkPayload = {
          service: 'in.juspay.hyperpay',
          requestId: requestid,
          payload: initiatePayload
       };

        hyperServiceObject.initiate(sdkPayload);
        const orderid = `GF${new Date().getTime()}`;
        const orderDetails = {
          order_id: orderid,
          merchant_id: 'gyandairy',
          amount: `${this.f.amount.value}.00`,
          timestamp: new Date().getTime().toString(),
          customer_id: this.userid,
          return_url: `${environment.api_url}jusPayRedirect`, // http://localhost:4200/page/wallet/success  https://replica.gyandairy.com/page/wallet/success
          customer_email: 'rakesh.k@srmechsol.com',
          customer_phone: `${this.userMobile}`,
          websiteName: environment.paytm.websiteName,
          callbackUrl: `${this.baseURL}webSucessResponsePage`,
          txnAmount: {
            value: `${this.f.amount.value}.00`,
            currency: 'INR',
          }
        };
        this.walletService.fetchSignedOrderPayload(orderDetails).pipe(take(1)).subscribe(res1 => {
          if (res1 && res1.status === 200) {
            const processPayload = {
              action: 'paymentPage',
              merchantId: 'gyandairy',
              clientId: 'gyandairy',
              orderId: orderid,
              amount: `${this.f.amount.value}.00`,
              customerId: this.userid,
              customerEmail: 'kuldeep@techugo.com',
              customerMobile: `${this.userMobile}`,
              orderDetails: res1.data.payload,
              signature: res1.data.signature,
              merchantKeyId: '5093'
            };
            const sdkPayload1 = {
              service: 'in.juspay.hyperpay',
              requestId: requestid,
              payload: processPayload
           };
            hyperServiceObject.process(sdkPayload1);
          }
        });
      }
    });
  }

  hyperCallbackHandler(eventData){
    try {
        if (eventData){
            const eventJSON  = JSON.parse(eventData);
            const event = eventJSON.event;
            console.log('checkEventData', eventJSON);
            // Check for event key
            if (event == "initiate_result") {
                // Handle initiate result here
            } else if (event == "process_result") {
                // Handle process result here
            } else if (event == "user_event") {
                // Handle Payment Page events
            } else {
                console.log("Unhandled event",event, " Event data", eventData);
            }
        } else {
            console.log("No data received in event",eventData);
        }
    } catch (error) {
        console.log("Error in hyperSDK response",error);
    }
 }

}
