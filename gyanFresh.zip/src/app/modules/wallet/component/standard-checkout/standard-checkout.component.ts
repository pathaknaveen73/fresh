import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { ActivatedRoute, Router } from '@angular/router';
import { WalletService } from '../../serviceFile/wallet.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ScriptService } from 'src/app/_scripts/script.service';
import { MatDialog } from '@angular/material/dialog';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';
import { environment } from 'src/environments/environment';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { take } from 'rxjs/operators';
declare var clevertap: any;
declare var Razorpay: any;

@Component({
  selector: 'app-standard-checkout',
  templateUrl: './standard-checkout.component.html',
  styleUrls: ['./standard-checkout.component.scss']
})
export class StandardCheckoutComponent implements OnInit {
  paymentOption = 1;
  amount = 0;
  transactionId;
  userid;
  baseURL = environment.api_url;
  headers = new HttpHeaders({ 'noauth': 'yes' });
  disableBtn = true;
  razorPayOptions = {
    'key': 'rzp_test_NwpIyN8iGn8Gce',  // rzp_test_PGt5r4jq4Ib6WF  rzp_live_y62aN38w8dhRlw
    'amount': '',
    'currency': '',
    'order_id': '',
    'handler': (res) => {
      console.log(res);
    },
    // "prefill.method": '',
    'prefill.email': 'care@gyandairy.com',
    'prefill.contact': '',
    'prefill.name': '',
    'image': ''
  };

  constructor(private route: ActivatedRoute, private walletService: WalletService, private commonService: CommonService,
              private router: Router, private http: HttpClient, private script: ScriptService, public dialog: MatDialog,
              private cd: ChangeDetectorRef, private fireAnalytics: FirebaseAnalyticsCustomService, private sharedService: SharedService,private ngZone: NgZone) {
                this.script.load(`${environment.paytm.script}`).then(data => {
                  // console.log('script loaded ', data);
                  // this.disableBtn = false;
                  const timeInterval = setInterval(() => {
                    if (window['Paytm'].CheckoutJS.init) {
                      this.disableBtn = false;
                      console.log('clearingTimeIntervalNow');
                      clearInterval(timeInterval);
                    }
                  }, 500);
              }).catch(error => console.log(error));
               }

  ngOnInit(): void {
    this.userid = localStorage.getItem('user_idGyan');
    this.amount = JSON.parse(this.route.snapshot.queryParams.data).amount;
    console.log('amount', this.amount);
  }

  proceed() {
    console.log('payment option', this.paymentOption);
    if (!this.paymentOption) {
      return this.commonService.showError('Please select payment method');
    }
    this.disableBtn = true;
    const METHOD = this.paymentOption === 1 ? 'Paytm' : 'Razorpay';
    try {
      clevertap.event.push(app_strings.CT_WALLET_RECHARGE_PROCESS, {
        'paymentType': METHOD,
        'rechargeAmount': this.amount,
        "platform": localStorage.getItem('deviceType')
      });
      this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.WALLET_RECHARGE_IN_PROCESS, {
        'paymentType': METHOD,
        'rechargeAmount': this.amount
      });
    } catch (error) {
      console.log(error);
    }
    if (this.paymentOption === 1) {
      // paytm create order logic
      this.createPaytmOrder();
    } else {
      // razor pay create order logic
       this.createRazorpayOrder();
    }
  }

  createRazorpayOrder() {
    const payload = {
      amount: Number(this.amount * 100),
      // currency: 'INR',
      // name: this.userinfo.firstName + ' ' + this.userinfo.lastName
    };
    this.walletService.createOrder(payload).subscribe(res => {
      if (res && res.status === 200) {
        console.log('orderCreated', res);
        // this.mainService.hideSpinner();
        this.razorPayOptions.amount = res.data.amount;
        this.razorPayOptions.order_id = res.data.id;
        this.razorPayOptions.currency = res.data.currency;
        this.razorPayOptions.handler = this.razorpayResponseHandler.bind(this);
        this.razorPayOptions["prefill.contact"] = '+' + '91' + localStorage.getItem('gPhone');
        // this.razorPayOptions["prefill.email"] = localStorage.getItem('userEmail');
        this.razorPayOptions["image"] = "assets/img/notLogo.png"
        this.razorPayOptions["prefill.name"] = localStorage.getItem('gName');
        // this.razorPayOptions["prefill.method"] = this.paymentSelected;
        var rzp = new Razorpay(this.razorPayOptions);
        rzp.open();
        console.log('opened');
      } else {
        this.commonService.showError(res.message);
      }
    }, error => {
      this.commonService.showError(error);
    });
  }

  razorpayResponseHandler(response) {
    console.log(response);
    // return;
    this.transactionId = response.razorpay_payment_id;
    const payload = {
      paymentMode: 'RAZOR_PAY',
      status: 'ACTIVE',
      trackId: response.razorpay_payment_id,
      // razorpayOrderId: response.razorpay_order_id,
      // razorpayPaymentId: response.razorpay_payment_id,
      // razorpaySignature: response.razorpay_signature,
      amount: this.amount,
      paymentGatewayResponse: response,
      paymentGatewayOrderId: response.razorpay_order_id
    };
    console.log('orderPlacePayload', payload);
    this.walletService.savePaymentData(payload).subscribe(res => {
      if (res && res.status === 200) {
        sessionStorage.setItem('GT-id', response.razorpay_payment_id);
        try {
          clevertap.event.push(app_strings.CT_WALLET_RECHARGE_SUCCESS, {
            'addedAmount': this.amount,
            "platform": localStorage.getItem('deviceType')
          });
        } catch (error) {
          console.log(error);
        }
        this.cd.detectChanges();
        // this.router.navigate(['page/wallet/success'], { queryParams: { id: response.razorpay_payment_id, amount: this.amount } });
        this.ngZone.run(() => {
          this.router.navigate(['page/wallet/success'], { queryParams: { id: response.razorpay_payment_id, amount: this.amount } });
        });
      } else {
        this.commonService.showError(res.message);
        this.openDialog1();
      }
    }, error => {
      this.commonService.showError(error);
      this.openDialog1();
    });
  }
  // function to open golabl dialog
  openDialog1() {
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '600px',
      height: 'auto',
      disableClose: true,
      data: {type: 'wallet'}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'walletOK') {
        this.router.navigate(['page/wallet']);
      }
    });
  }

  createPaytmOrder() {
    const orderid = `ORDERID_${new Date().getTime()}`;
    const checksumObj = {
      requestType: 'Payment',
      mid: environment.paytm.mid,
      websiteName: environment.paytm.websiteName,
      orderId: orderid,
      callbackUrl: `${this.baseURL}webSucessResponsePage`, // https://gyanfresh.gyandairy.com/api/user/v3/webSucessResponsePage
      txnAmount: {
        value: `${this.amount}.00`,
        currency: 'INR',
      },
      userInfo: {
        custId: `${this.userid}`
      }
    };
    this.walletService.createPaytmOrder(checksumObj).subscribe(res => {
      if (res && res.status === 200) {
        console.log('checksum', res);
        let config = {
          "root": "",
          "flow": "DEFAULT",
          "data": {
          "orderId": res.data.checksumReq.orderId, /* update order id */
          "token": res.data.body.txnToken, /* update token value */
          "tokenType": "TXN_TOKEN",
          "amount": res.data.checksumReq.txnAmount.value /* update amount */
          },
          "handler": {
            "notifyMerchant": (eventName,data) => {
              console.log("notifyMerchant handler function called");
              console.log("eventName => ",eventName);
              // console.log("data => ",data);
              if (eventName === 'APP_CLOSED') {
                this.disableBtn = false;
                this.delete_cookie('firstRechargeAmount');
                this.delete_cookie('transactionCount');
                this.delete_cookie('rechargeAmount');
              }
            }
          }
        };
        this.sharedService.getUserProfileInfo().pipe(take(1)).subscribe((res1: any) => {
          // console.log('check>>>>', res1);
          this.setCookie('firstRechargeAmount', res1.firstRechargeAmount ? res1.firstRechargeAmount : 0);
          this.setCookie('transactionCount', res1.transactionCount);
          this.setCookie('rechargeAmount', config.data.amount);

                    // initialze configuration using init method
          window['Paytm'].CheckoutJS.init(config).then( () => {
            // after successfully updating configuration, invoke JS Checkout
            window['Paytm'].CheckoutJS.invoke();
        }).catch((error) => {
            console.log("error => ",error);
            this.commonService.showError('Something went wrong, please try again later');
        });
        });
        this.sharedService.getUserProfile();
        // setInterval(() => {
        //   this.sharedService.getUserProfile();
        // }, 4000);
      }
    });
  }

  setCookie(cname, cvalue) {
    const d = new Date();
    d.setTime(d.getTime() + (24*60*400));
    let expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }

  delete_cookie(name) {
    document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
  }

}
