import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-fail',
  templateUrl: './fail.component.html',
  styleUrls: ['./fail.component.scss']
})
export class FailComponent implements OnInit {
  failObj;
  orderId;

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params) {
        // fail logic
        this.failObj = params;
        this.orderId = this.failObj.tracking_id;
        // console.log('falied', this.failObj);
      } else {
        // redirect to wallet page
        this.router.navigate(['page/wallet'], {replaceUrl: true});
      }
    });
    console.log('KULDEEP111', this.failObj);
  }

  navigateWallet() {
    this.router.navigate(['page/wallet'], {replaceUrl: true});
  }

}
