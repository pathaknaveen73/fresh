import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { WalletService } from '../../serviceFile/wallet.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

declare var Razorpay: any;
declare let $: any;

@Component({
  selector: 'app-razorpay',
  templateUrl: './razorpay.component.html',
  styleUrls: ['./razorpay.component.scss']
})
export class RazorpayComponent implements OnInit {
  // submitted = false;
  // razorPayData: FormGroup;
  razorPayOptions = {
    "key": 'rzp_test_NwpIyN8iGn8Gce',  // rzp_test_wwHXgyLEIsXlWT  rzp_live_Dgv9W0Euq5meCV
    "amount": '',
    "currency": '',
    "order_id": '',
    "handler": (res) => {
      console.log(res);
    },
    // "prefill.method": '',
    "prefill.email": '',
    "prefill.contact": '',
    "prefill.name": '',
    "image": ''
  };
  totalAmount = 0;
  userinfo;
  paymentMethodArr = [
    {id: 1, title: 'UPI / QR', description: 'Instant payment using UPI app or UPI id', value: 'upi'},
    {id: 2, title: 'Credit / Debit / ATM cards', description: 'Visa, MasterCard, Rupay & more', value: 'card'},
    {id: 3, title: 'Netbanking', description: 'All Indian banks', value: 'netbanking'},
    {id: 4, title: 'Wallets', description: 'Phonepe & more', value: 'wallet'}
  ];
  paymentSelected;
  continue = false;
  orderId;
  result;
  transactionId;

  constructor(private cartService: WalletService, private commonService: CommonService,
              private route: ActivatedRoute, private location: Location, private router: Router) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(param => {
      if (param && param.data) {
        console.log('checkParam', param.data);
        const paramData = JSON.parse(param.data);
        this.totalAmount = paramData.amount;
      } else {
        this.location.back();
      }
    });
  }

  // setCheckoutForm() {
  //   this.razorPayData = this.fb.group({
  //     totalAmount: '',
  //     name: '',
  //     id: ''
  //   });
  // }

  // funtion on buy click
  buyRazorPay(formData: any) {
    // this.submitted = true;
    this.commonService.showSpinner();

  }

  createOrder() {
    const payload = {
      amount: Number(this.totalAmount * 100),
      // currency: 'INR',
      // name: this.userinfo.firstName + ' ' + this.userinfo.lastName
    };
    this.cartService.createOrder(payload).subscribe(res => {
      if (res && res.status === 200) {
        console.log('orderCreated', res);
        // this.mainService.hideSpinner();
        this.razorPayOptions.amount = res.data.amount;
        this.razorPayOptions.order_id = res.data.id;
        this.razorPayOptions.currency = res.data.currency;
        this.razorPayOptions.handler = this.razorpayResponseHandler.bind(this);
        this.razorPayOptions["prefill.contact"] = '+' + '91' + localStorage.getItem('gPhone');
        this.razorPayOptions["prefill.email"] = localStorage.getItem('userEmail');
        this.razorPayOptions["image"] = "assets/img/notLogo.png"
        this.razorPayOptions["prefill.name"] = localStorage.getItem('gName');
        // this.razorPayOptions["prefill.method"] = this.paymentSelected;
        var rzp = new Razorpay(this.razorPayOptions);
        rzp.open();
        console.log('opened');
      } else {
        this.commonService.showError(res.message);
      }
    }, error => {
      this.commonService.showError(error);
    });
  }

  razorpayResponseHandler (response) {
    console.log(response);
    // return;
    this.transactionId = response.razorpay_payment_id;
    const payload = {
      paymentMode: 'RAZOR_PAY',
      status: 'ACTIVE',
      trackId: response.razorpay_payment_id,
      // razorpayOrderId: response.razorpay_order_id,
      // razorpayPaymentId: response.razorpay_payment_id,
      // razorpaySignature: response.razorpay_signature,
      amount: this.totalAmount
    };
    console.log('orderPlacePayload', payload);
    this.cartService.savePaymentData(payload).subscribe(res => {
      if (res && res.status === 200) {
        sessionStorage.setItem('GT-id', response.razorpay_payment_id);
        this.router.navigate(['page/wallet/success'], { queryParams: { id: response.razorpay_payment_id, amount: this.totalAmount } });
      } else {
        this.commonService.showError(res.message);
      }
    }, error => {
      this.commonService.showError(error);
    });
  }

  // redirectLogic() {
  //   if (this.result === 1) {
  //     this.router.navigate(['/cart']);
  //   } else {
  //     this.router.navigate(['/']);
  //   }
  // }

}
