import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute, NavigationExtras} from '@angular/router';
import { take } from 'rxjs/operators';
import { app_strings } from 'src/app/shared/_constant/app_strings';
declare var clevertap: any;

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.scss']
})
export class SuccessComponent implements OnInit {
  successObj;
  orderId;
  amount;

  constructor(private router: Router, private route: ActivatedRoute, private cd: ChangeDetectorRef) { }

  ngOnInit(): void {
    // const id = sessionStorage.getItem('GT-id');
    // if (!id) {
    //   this.router.navigate(['page/wallet']);
    //   return;
    // }
    // sessionStorage.removeItem('GT-id');
    // this.orderId = this.route.snapshot.queryParams.id;
    // this.amount = this.route.snapshot.queryParams.amount;
    // if (!this.orderId || !this.amount) {
    //     this.router.navigate(['page/wallet'], {replaceUrl: true});
    //   }
    // setTimeout(() => {
    //   this.cd.detectChanges();
    //   document.getElementById('success123').click();
    // }, 1000);
    // this.route.queryParams.subscribe(params => {
    //   if (params) {
    //     // fail logic
    //     this.successObj = params;
    //     this.orderId = this.successObj.tracking_id;
    //     clevertap.event.push(app_strings.CT_WALLET_RECHARGE_SUCCESS);
    //     // console.log('falied', this.failObj);
    //   } else {
    //     // redirect to wallet page
    //     this.router.navigate(['page/wallet'], {replaceUrl: true});
    //   }
    // });
    // console.log('KULDEEP111', this.successObj);
    this.route.queryParams.pipe(take(1)).subscribe(res => {
      console.log('checkITTT', res);
      this.successObj = res;
    });
  }

  navigateWallet() {
    const navigationExtras: NavigationExtras = {
      replaceUrl: true,
      queryParams: { id: 1 }
    };

    this.router.navigate(['page/account-history'], navigationExtras).then(() => {
      window.location.reload();
    });
  }
  // navigateWallet() {
  //   this.router.navigate(['page/account-history'], {replaceUrl: true, queryParams: { id: 1 }});
  // }

}




