import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WalletService } from '../../serviceFile/wallet.service';
import { MatDialog } from '@angular/material/dialog';
import { DaterangepickerComponent } from '../daterangepicker/daterangepicker.component';
import { CommonService } from 'src/app/serviceFile/common.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';
declare var clevertap: any;
import Swal from 'sweetalert2';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { Subscription } from 'rxjs';
import { SharedService } from 'src/app/serviceFile/shared.service';

@Component({
  selector: 'app-wallet-list',
  templateUrl: './wallet-list.component.html',
  styleUrls: ['./wallet-list.component.scss']
})
export class WalletListComponent implements OnInit, OnDestroy {
  toDate = new Date();
  fromDate;
  transactionListArr = [];
  walletBalanceDetails;
  selected;
  userEmail;
  offset = 0;
  limit = 10;
  walletBalanceDate = new Date();
  wallet$: Subscription;
  mockLength = 0;
  walletAmount$: Subscription;
  defaultDate = true;
  @Input() show: boolean;

  constructor(private router: Router, private walletService: WalletService, public dialog: MatDialog,
              private commonService: CommonService, private fireAnalytics: FirebaseAnalyticsCustomService,
              private sharedService: SharedService) { }

  ngOnInit(): void {
    // this.walletAmount$ = this.sharedService.walletData$.subscribe(res => {
    //   this.walletBalanceDetails = res;
    // });
    this.getAllTransaction();
    // this.getWalletBalanceDetail();
    // this.userEmail = localStorage.getItem('userEmail');
  }

  ngOnDestroy() {
    try {
      this.wallet$.unsubscribe();
      // this.walletAmount$.unsubscribe();
    } catch (error) {
      console.log(error);
    }
  }

  // function to navigate to add money
  openAddMoney() {
    this.router.navigate(['page/wallet/addMoney']);
  }

  // function to navigate to auto recharge
  openAutoRecharge() {
    this.router.navigate(['page/wallet/autoRecharge']);
  }

  // function to get all transaction
  getAllTransaction(toDate?: Date) {
    const tr = new Promise((res, rej) => {
      const last7date = new Date(new Date().setDate(new Date().getDate() - 7)).toISOString();
      const payload = {
      fromDate: this.fromDate ? this.fromDate.toISOString() : last7date,
      toDate: toDate ? toDate.toISOString() : new Date().toISOString(),
      offSet: this.offset,
      limit: this.limit
    };
      // if (payload.fromDate) {}
      this.commonService.showSpinner();
      this.wallet$ = this.walletService.getTransactionList(payload, this.defaultDate).subscribe(response => {
      if (response.status === 200) {
        this.commonService.hideSpinner();
        if (this.offset === 0) {
          this.mockLength = 0;
          this.transactionListArr = [];
        }
        const list = [] = response.data;
        this.mockLength = list.length;
        if (list.length) {
          let trackedIndex = 0;
          list.forEach((element, i) => {
          // this.transactionListArr.push(element);
          if (i > trackedIndex || i === 0) {
            const currentDate = new Date(element.updatedAt).getDate();
            const currentMonth = new Date(element.updatedAt).getMonth() + 1;
            const currrentYear = new Date(element.updatedAt).getFullYear();
            const groupedEvent = [];
            for (let index = i; index < list.length; index++) {
              const cd = new Date(list[index].updatedAt).getDate();
              const cm = new Date(list[index].updatedAt).getMonth() + 1;
              const cy = new Date(list[index].updatedAt).getFullYear();
              if (cd === currentDate && cm === currentMonth && cy === currrentYear) {
                groupedEvent.push(list[index]);
                trackedIndex = index;
              } else {
                // trackedIndex = index;
                break;
              }
            }
            if (groupedEvent.length) {
              this.transactionListArr.push({
                date: element.updatedAt,
                events: groupedEvent
              });
            }
          }
        });
        }
        res(this.transactionListArr);
        // this.transactionListArr.push(response.data);
        console.log('transactionListArr', this.transactionListArr);
      } else {
        this.commonService.hideSpinner();
      }
    }, error => {
      this.commonService.hideSpinner();
    });
    });
    return tr;
  }

  // function to get wallet balance details
  getWalletBalanceDetail() {
    this.walletService.getAutoRechargeDetail().subscribe(response => {
      if (response.status === 200) {
        this.walletBalanceDetails = response.data.walletAmount;
        // console.log('walletBalanceDetails', this.walletBalanceDetails);
        try {
          clevertap.event.push(app_strings.CT_WALLET_CHECKED, {
            'walletAmount': this.walletBalanceDetails.walletAmount,
            'walletStatus': new Date(),
            "platform": localStorage.getItem('deviceType')
          });
          this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.WALLET_AMOUNT_CHECKED, {
            walletAmount: this.walletBalanceDetails.walletAmount,
            walletStatus: new Date()
          });
        } catch (error) {
          console.log(error);
        }
      }
    });
  }

  // function to open date range picker
  openDatepicker(sendEmail?:boolean): void {
    const dialogRef = this.dialog.open(DaterangepickerComponent, {
      width: 'auto',
      height: 'auto',
      data: {startDate: this.fromDate, endDate: this.toDate}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.defaultDate = false;
        this.fromDate = result.begin;
        this.toDate = result.end;
        // const fromDate = result.begin;
        // const toDate = result.end;
        this.offset = 0;
        this.getAllTransaction(this.toDate).then(res => {
          if (sendEmail) {
            this.sendEmailConfirmPp();
          }
        });
        // if (sendEmail) {
        //   setTimeout(() => {
        //     this.sendEmailConfirmPp();
        //   }, 1000);
        // }
      }
    });
  }

  // function to send transactions to email
  sendEmailConfirmPp() {
    if (!this.fromDate) {
      this.openDatepicker(true);
      return;
    }
    if (!this.transactionListArr.length) {
      this.commonService.showWarning('No transaction found');
      return;
    }
    // shwo add email popup
    Swal.fire({
      title: 'Enter Your Email ID',
      input: 'email',
      inputAttributes: {
        autocapitalize: 'off'
      },
      showCancelButton: true,
      confirmButtonText: 'Submit',
      showLoaderOnConfirm: true,
      // inputValidator: (value) => {
      //   return !value && 'Please enter your email id';
      // },
      allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
      if (result.isConfirmed) {
        if (!result.value) {
          Swal.fire({
            title: `Email cannot be empty`
          });
        } else if (!this.validateEmail(result.value)) {
          Swal.fire({
            title: `Invalid email`
          })
        } else {
          // Swal.fire({
          //   title: `${result.value}`
          // })
          this.confirmSendEmailFinal(result.value);
        }
      }
    });
  }

  confirmSendEmailFinal(emails: string) {
    this.commonService.confirmPopup('You want to get transaction list on email !', 'warning').then(el => {
      if (el.value) {
        let payload = {
          // email: this.userEmail,
          email: emails,
          transactions: JSON.stringify(this.transactionListArr),
          fromDate: this.fromDate.toISOString(),
          toDate: this.toDate.toISOString()
        };
        this.walletService.sendEmail(payload).subscribe(response => {
          if (response && response.status === 200) {
            this.commonService.showSuccess(response.message);
          } else {
            this.commonService.showError(response.message);
          }
        }, error => {
          this.commonService.showError(error);
        });
      }
    });
  }

 validateEmail(email) {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

  checkInfoToast() {
    this.commonService.showInfo('hi just checking');
  }

  // function for pagination infinte scroll
  onScroll() {
    // console.log('transactionScroll', this.show);
    if (this.show) {
      if (this.mockLength < 10 || this.mockLength % 2 !== 0) {
        return;
      }
      console.log('scrolled');
      this.offset += 10;
      this.getAllTransaction();
    }
  }

  downloadPDF() {
    if (!this.transactionListArr.length) {
      this.commonService.showWarning('No transaction found');
      return;
    }
    const obj = {
      fromDate: this.fromDate ? this.fromDate.toISOString() : new Date().toString(),
      toDate: this.toDate ? this.toDate.toISOString() : new Date().toString(),
      // transactions: JSON.stringify(this.transactionListArr)
    };
    this.commonService.showSpinner();
    this.walletService.downloadTransactionPDF(obj, this.defaultDate).subscribe(res => {
      if (res && res.status === 200) {
        // console.log('>>>>>>>>', res);
        this.commonService.hideSpinner();
        window.open(res.data.file, '_blank');
      } else {
        this.commonService.hideSpinner();
        this.commonService.showError(res.message);
      }
    }, error => {
      this.commonService.hideSpinner();
      this.commonService.showError(error);
    });
  }

}
