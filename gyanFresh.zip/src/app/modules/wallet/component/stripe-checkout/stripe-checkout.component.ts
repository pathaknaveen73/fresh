import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StripeService, Elements, Element as StripeElement, ElementsOptions, StripeCardComponent, ElementOptions } from 'ngx-stripe';
import { WalletService } from '../../serviceFile/wallet.service';
import { CommonService } from 'src/app/serviceFile/common.service';
declare let $: any;

@Component({
  selector: 'app-stripe-checkout',
  templateUrl: './stripe-checkout.component.html',
  styleUrls: ['./stripe-checkout.component.scss']
})
export class StripeCheckoutComponent implements OnInit {
  @ViewChild(StripeCardComponent) card: StripeCardComponent;
  checkoutData;
  elements: Elements;
  secretIntentKey;
  error: any;
  complete = false;
  // card: StripeElement;

  cardOptions: ElementOptions = {
    style: {
      base: {
        iconColor: '#666EE8',
        color: '#31325F',
        lineHeight: '40px',
        fontWeight: 300,
        fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
        fontSize: '18px',
        '::placeholder': {
          color: '#CFD7E0'
        }
      }
    }
  };

  // optional parameters
  elementsOptions: ElementsOptions = {
    locale: 'auto'
  };

  stripeTest: FormGroup;

  constructor(private router: Router, private fb: FormBuilder, private stripeService: StripeService,
              private walletService: WalletService, private commonService: CommonService) { }

  ngOnInit(): void {
    if (!history.state.data) {
      this.router.navigate(['page/wallet'], { replaceUrl: true });
    } else {
      this.checkoutData = history.state.data;
      console.log('checkoutData', this.checkoutData);
      if (this.checkoutData.amount < 5000) {
        this.checkoutData.amount = 5000;
        this.commonService.showWarning('Minimum recharge amount is ₹ 50');
      }
      this.createPaymentIntent(this.checkoutData);
    }

    this.stripeTest = this.fb.group({
      name: ['']
    });
    // this.stripeService.elements(this.elementsOptions)
    //   .subscribe(elements => {
    //     this.elements = elements;
    //     // Only mount the element the first time
    //     if (!this.card) {
    //       this.card = this.elements.create('card', {
    //         style: {
    //           base: {
    //             iconColor: '#666EE8',
    //             color: '#31325F',
    //             lineHeight: '40px',
    //             fontWeight: 300,
    //             fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
    //             fontSize: '18px',
    //             '::placeholder': {
    //               color: '#CFD7E0'
    //             }
    //           }
    //         }
    //       });
    //       this.card.mount('#card-element');
    //     }
    //   });
  }

  // buy() {
  //   const name = this.stripeTest.get('name').value;
  //   this.stripeService
  //     .createToken(this.card.getCard(), { name })
  //     .subscribe(result => {
  //       if (result.token) {
  //         // Use the token to create a charge or a customer
  //         // https://stripe.com/docs/charges
  //         console.log(JSON.stringify(result.token));
  //       } else if (result.error) {
  //         // Error creating the token
  //         console.log(result.error.message);
  //       }
  //     });
  // }

  // function to create payment intent
  createPaymentIntent(data) {
    if (data) {
      this.walletService.createPaymentIntent(data).subscribe(response => {
        if (response.status === 200) {
          this.secretIntentKey = response.data;
          console.log('secretIntentKey', this.secretIntentKey);
        }
      });
    }
  }

  // function to perform charge
  buy() {
    console.log('cardInfo', this.card.stripeCard.nativeElement.className);
    if (this.card.stripeCard.nativeElement.className === 'field StripeElement StripeElement--empty') {
      this.error = {
        message: 'Please enter card details'
      };
      // $('.checkout').delay(40000).hide();
      return;
    }
    if (this.card.stripeCard.nativeElement.className === 'field StripeElement StripeElement--invalid') {
      this.error = {
        message: 'Please enter valid card details'
      };
      return;
    }
    if (this.card.stripeCard.nativeElement.className === 'field StripeElement StripeElement--complete') {
      this.error = undefined;
      this.commonService.showSpinner();
      this.stripeService.handleCardPayment(this.secretIntentKey, this.card.element).subscribe(response => {
        console.log('paymentRes', response);
        if (response && response.paymentIntent.status === 'succeeded') {
          this.commonService.showSuccess('SUCCESS');
          const payload = {
            amount: response.paymentIntent.amount / 100,
            status: 'ACTIVE',
            trackId: this.secretIntentKey
          };
          this.walletService.savePaymentData(payload).subscribe(resp => {
            if (resp.status === 200) {
              this.commonService.hideSpinner();
              this.router.navigate(['page/wallet'], { replaceUrl: true });
            } else {
              this.commonService.showError(resp.message);
            }
          });
        } else {
          this.commonService.showError('PAYMENT FAILED');
          const payload = {
            amount: response.paymentIntent.amount / 100,
            status: 'INACTIVE',
            trackId: this.secretIntentKey
          };
          this.walletService.savePaymentData(payload).subscribe(resp => {
            if (resp.status === 200) {
              this.commonService.hideSpinner();
              this.router.navigate(['page/wallet'], { replaceUrl: true });
            } else {
              this.commonService.showError(resp.message);
            }
          });
        }
      });
    }
    // this.stripeService.confirmCardPayment(this.secretIntentKey, this.card.element).subscribe(response => {
    //   console.log(response);
    // });
  }

  // cardUpdated(result) {
  //   console.log('cardResult', result);
  //   // this.element = result.element;
  //   this.complete = result.card._complete;
  //   this.error = undefined;
  // }

}
