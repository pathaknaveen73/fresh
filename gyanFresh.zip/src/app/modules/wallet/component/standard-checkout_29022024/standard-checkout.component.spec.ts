import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandardCheckoutComponent } from './standard-checkout.component';

describe('StandardCheckoutComponent', () => {
  let component: StandardCheckoutComponent;
  let fixture: ComponentFixture<StandardCheckoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandardCheckoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandardCheckoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
