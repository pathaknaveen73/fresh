import { Component, OnInit } from '@angular/core';
import { WalletService } from '../../serviceFile/wallet.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/serviceFile/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auto-recharge',
  templateUrl: './auto-recharge.component.html',
  styleUrls: ['./auto-recharge.component.scss']
})
export class AutoRechargeComponent implements OnInit {
  autoRechargeDetail;
  addAutoRechargeForm: FormGroup;
  submitted = false;

  constructor(private walletService: WalletService, private fb: FormBuilder, private commonService: CommonService,
              private router: Router) { }

  ngOnInit(): void {
    this.getAutoRechargeDetail();
    this.setFormField();
  }

  // function to get auto recharge details
  getAutoRechargeDetail() {
    this.walletService.getAutoRechargeDetail().subscribe(response => {
      if (response.status === 200) {
        this.autoRechargeDetail = response.data;
        console.log('autoRechargeDetail', this.autoRechargeDetail);
        if (this.autoRechargeDetail && this.autoRechargeDetail.autoRechargeData) {
          this.addAutoRechargeForm.controls.rechargeAmount.setValue(this.autoRechargeDetail.autoRechargeData.rechargeAmount);
          this.addAutoRechargeForm.controls.minBalance.setValue(this.autoRechargeDetail.autoRechargeData.onMinimumBalance);
        }
      }
    });
  }

  // function to set auto rechrge details form field
  setFormField() {
    this.addAutoRechargeForm = this.fb.group({
      rechargeAmount: ['', [Validators.required]],
      minBalance: ['', [Validators.required]]
    });
  }

  // function to get form controls
  get f() { return this.addAutoRechargeForm.controls; }

  // function to submit auto recharge details form data
  submit() {
    this.submitted = true;
    if (!this.addAutoRechargeForm.valid) {
      console.log('invalidAddAutoRechargeForm', this.addAutoRechargeForm.controls);
      return;
    }
    const payload = {
      rechargeAmount: this.addAutoRechargeForm.controls.rechargeAmount.value,
      onMinimumBalance: this.addAutoRechargeForm.controls.minBalance.value
    };
    this.walletService.sendAutoRechargeData(payload).subscribe(response => {
      if (response.status === 200) {
        this.commonService.showSuccess(response.message);
        this.router.navigate(['page/wallet']);
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

}
