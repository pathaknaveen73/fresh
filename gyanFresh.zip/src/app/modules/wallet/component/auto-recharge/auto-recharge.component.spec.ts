import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoRechargeComponent } from './auto-recharge.component';

describe('AutoRechargeComponent', () => {
  let component: AutoRechargeComponent;
  let fixture: ComponentFixture<AutoRechargeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoRechargeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoRechargeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
