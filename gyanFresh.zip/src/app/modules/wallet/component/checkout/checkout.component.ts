import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { WalletService } from '../../serviceFile/wallet.service';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/serviceFile/common.service';

declare let $: any;

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {
  @ViewChild('form') form: ElementRef;

  encRequest: String;
  accessCode: String;
  orderInformation;
  checkoutData;
  customer_identifier;

  constructor(private walletService: WalletService, private router: Router, private commonService: CommonService) { }

  ngOnInit(): void {
    if (!history.state.data) {
      this.router.navigate(['page/wallet'], { replaceUrl: true });
      return;
    }
    this.customer_identifier = localStorage.getItem('user_idGyan');
    this.checkoutData = history.state.data;
    console.log('checkoutData', this.checkoutData);
    if (this.checkoutData.amount < 50) {
      this.checkoutData.amount = 50;
      this.commonService.showWarning('Minimum recharge amount is ₹ 50');
    }
    this.accessCode = 'AVBL93HF17CL15LBLC';
    this.orderInformation = {
      order_id: localStorage.getItem('user_idGyan'),
      currency: 'INR',
      amount: this.checkoutData.amount.toString(),
      // redirect_url: encodeURIComponent(`https://gyanfresh.gyandairy.com/#/page/wallet`),
      redirect_url: encodeURIComponent(`https://gyanfresh.gyandairy.com:3000/api/user/v1/ccavResHandler`),
      billing_name: 'Kuldeep',
      // customer_identifier: localStorage.getItem('user_idGyan')
      // userId: localStorage.getItem('user_idGyan')
      // etc etc
    };
  }

  pay() {
    // this.cartValue contains all the order information which is sent to the server
    // You can use this package to encrypt - https://www.npmjs.com/package/node-ccavenue/
    let paylaod = {
      orderParams: this.orderInformation
    };
    this.walletService.getEnc(paylaod).subscribe((response: any) => {
      this.encRequest = response.data.encryptedOrderData;
      // sessionStorage.setItem('checkoutInit', '1');
      console.log('token enc', this.encRequest);
      // debugger
      setTimeout(_ => this.form.nativeElement.submit());
    }, error => {
      console.log(error);
    });
  }

}
