import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';
import { environment } from 'src/environments/environment';

@Injectable()
export class WalletService {

  constructor(private apiService: ApiService) { }

  // function to get transaction list
  getTransactionList(payload, defaultDate?: boolean) {
    const url = 'getTransactions?fromDate=' + payload.fromDate + '&toDate=' + payload.toDate + '&limit=' + payload.limit + '&offset=' + payload.offSet + '&default=' + defaultDate;
    return this.apiService.getApi(url);
  }

  // function to get auto recharge detail
  getAutoRechargeDetail() {
    const url = 'getAutoRechargeDetail';
    return this.apiService.getApi(url);
  }

  // function to save auto recharge data
  sendAutoRechargeData(payload) {
    const url = 'addAutoRechargeDetail';
    return this.apiService.postApi(url, payload);
  }

  // function to create payment intent for add money
  createPaymentIntent(payload) {
    const url = 'createPaymentIntent';
    return this.apiService.postApi(url, payload);
  }

  // function to load stripe JS
  loadStripeJS() {
    const scriptElement = window.document.createElement('script');
    scriptElement.src = 'https://js.stripe.com/v3/';
  }

  // function to save payment data
  savePaymentData(payload) {
    const url = 'SavePaymentData';
    return this.apiService.postApi(url, payload);
  }

  // function to send email
  sendEmail(payload) {
    const url = 'mailTransactions';
    return this.apiService.postApi(url, payload);
  }

  // function to get enc cc avenue
  getEnc(payload) {
    const url = 'ccavReqHandler';
    return this.apiService.postApi(url, payload);
  }

  // function to recharge through cash collect
  cashCollect(payload) {
    const url = 'reqCashCollection';
    return this.apiService.postApi(url, payload);
  }

  // function to create razopr pay order
  createOrder(payload) {
    const url = 'orders';
    return this.apiService.postApi(url, payload);
  }

  // function to create paytm order prod
  createPaytmOrder(payload) {
    const paytmScript = environment.paytm.script;
    const url = paytmScript === 'paytmProd' ? 'createChecksumhashProd' : 'createChecksumhash';
    return this.apiService.postApi(url, payload);
  }

  // function to create paytm order staging
  createPaytmOrderStaging(payload) {
    const url = 'createChecksumhash';
    return this.apiService.postApi(url, payload);
  }

  // function to download transactions pdf
  downloadTransactionPDF(payload, defaultDate?: boolean) {
    const url = 'downloadTransactionsreport?default=' + defaultDate;
    return this.apiService.postApi(url, payload);
  }

  // function to get available offers listing
  availableOffers() {
    const url = 'userCouponList';
    return this.apiService.getApi(url);
  }

  // function to apply coupon
  applyCoupoon(payload) {
    const url = 'userApplyCoupon';
    return this.apiService.postApi(url, payload);
  }

  // function to remove coupon
  removeCoupon(payload) {
    const url = 'userRemoveCoupon';
    return this.apiService.postApi(url, payload);
  }

  // function generating signature on initiate juspay
  fetchSignedCustomerPayload() {
    const url = 'jusPaySignatureCreate';
    return this.apiService.getApi(url);
  }

  // function generating signature on process juspay
  fetchSignedOrderPayload(payload) {
    const url = 'jusPaySignatureCreate';
    return this.apiService.postApi(url, payload);
  }
}
