import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-account-history',
  templateUrl: './account-history.component.html',
  styleUrls: ['./account-history.component.scss']
})
export class AccountHistoryComponent implements OnInit {
  orderflag = true;
  transactionFlag = false;
  showTab = 0;

  constructor( private route: ActivatedRoute ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.queryParams.id;
    if (id) {
      setTimeout(() => {
        this.orderflag = false;
        this.transactionFlag = true;
        this.showTab = 1;
      }, 1000);
    }
  }

  tabChange(tab) {
    console.log(tab.index);
    if (tab.index) {
      this.orderflag = false;
      this.transactionFlag = true;
    } else {
      this.transactionFlag = false;
      this.orderflag = true;
    }
  }

}
