import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountHistoryRoutingModule } from './account-history-routing.module';
import { AccountHistoryComponent } from './account-history/account-history.component';
import {MatTabsModule} from '@angular/material/tabs';
import { WalletModule } from '../wallet/wallet.module';
import { OrderModule } from '../order/order.module';


@NgModule({
  declarations: [AccountHistoryComponent],
  imports: [
    CommonModule,
    AccountHistoryRoutingModule,
    MatTabsModule,
    WalletModule,
    OrderModule
  ]
})
export class AccountHistoryModule { }
