import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/serviceFile/common.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
declare let $: any;

@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.scss']
})
export class SidemenuComponent implements OnInit, OnDestroy {
  userPrimayLocation;
  allLocation;
  isRef = false;
  isOffer = false;
  showStar = false;
  allSubs$: Subscription[] = [];
  showGSstreak = false;

  constructor(private router: Router, private commonService: CommonService, private sharedService: SharedService) { }

  ngOnInit(): void {
    // const ref = localStorage.getItem('isRef');
    // if (ref && ref === '1') {
    //   this.isRef = true;
    // }
    this.allSubs$.push(this.sharedService.getReferralStatusVal().subscribe(res => {
      if (res && res === '1') {
        this.isRef = true;
      } else {
        this.isRef = false;
      }
    }));
    this.allSubs$.push(this.sharedService.getOfferStatusVal().subscribe(res => {
      if (res && res === '1') {
        this.isOffer = true;
      } else {
        this.isOffer = false;
      }
    }));
    this.allSubs$.push(this.sharedService.starData$.subscribe(res => {
      if (res) {
        if (res && res.status === 'ACTIVE') {
          this.showStar = true;
        } else {
          this.showStar = false;
        }
        // this.walletData = res.value;
      }
    }));
    this.allSubs$.push(this.sharedService.dailyStarBonus$.subscribe(res => {
      this.showGSstreak = res;
    }));
    // $('.owl-carousel').owlCarousel({
    //   nav: true,
    //   loop: true,
    //   margin: 10,
    //   dots: false,
    //   autoplay: true,
    //   responsive: {
    //   0: {
    //   items: 1
    //   },
    //   600: {
    //   items: 3
    //   },
    //   1000: {
    //   items: 4
    //   }
    //   }
    //   });


      $(document).ready(function(){
        $(".helpsupport").click(function(){
          $(".helpsupport ").toggleClass("open");
        });
      });

      // $(".side_navigation").click(function(){
      // $(".side_menu").css("right", "");
      // });




    $('.side_menu .closebtn,.overlay').click(function(){
      $('html').removeClass('sidePanel');
      $('.side_menu').css({'width': '0', 'visibility': 'hidden'});
      });
    $('.sidenav_menu ul li.menu').click(function(){
        $('html').removeClass('sidePanel');
        $('.side_menu').css({'width':'0','visibility':'hidden'});
        })


    $(document).ready(function () {
          sidemenu();
        });
    window.onresize = function() {
          sidemenu();
        }
    function sidemenu(){
          if ($(window).width() < 767) {
            $('.side_navigation').click(function(){
              $('.side_menu').show();
              $('.side_menu').css({'width': '300px', 'visibility': 'visible'});
              if ($('.side_menu').css('display') == 'block'){
              $('html').addClass('sidePanel');
              }
              });
          }
          if($(window).width() > 767){
            $('.side_navigation').click(function(){
              $('.side_menu').show();
              $('.side_menu').css({'width': '500px', 'visibility': 'visible'});
              if ($('.side_menu').css('display') == 'block'){
              $('html').addClass('sidePanel');
              }
              });
          }
        }



    // const location = JSON.parse(localStorage.getItem('userLocation'));
    // this.userPrimayLocation = location.find(element => element && element.default === 'PRIMARY');
    // console.log('location', this.userPrimayLocation);
    this.sharedService.getUserLocation().subscribe(userLocation => {
      this.allLocation = userLocation;
      this.allLocation.forEach(element => {
        if (element.default === 'PRIMARY') {
          this.userPrimayLocation = element;
        }
      });
      // console.log('userPrimaryLocation', this.userPrimayLocation);
    });
  }

  ngOnDestroy(): void {
      try {
        this.allSubs$.forEach(subscription => subscription.unsubscribe());
      } catch (error) {
        console.log('error in unsubscribing subscriptions');
      }
  }

  logout() {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userLocation');
    this.router.navigate(['/login']);
  }

  // function to navigate to address
  navigateToAddress() {
    this.router.navigate(['page/address']);
    $('html').removeClass('sidePanel');
    $('.side_menu').css({'width':'0','visibility':'hidden'});
  }

  // function to navigate
  goto(data, params?) {
    if (data) {
      if (params) {
        this.router.navigate([data], { queryParams: params });
      } else {
        this.router.navigate([data]);
      }
    }
    $('html').removeClass('sidePanel');
    $('.side_menu').css({'width':'0','visibility':'hidden'});
  }

}
