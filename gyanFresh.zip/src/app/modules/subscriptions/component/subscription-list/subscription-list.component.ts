import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SubscriptionService } from '../../serviceFile/subscription.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import Swal from 'sweetalert2';
import { Subscription } from 'rxjs';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
declare let  $: any;

declare var clevertap: any;

@Component({
  selector: 'app-subscription-list',
  templateUrl: './subscription-list.component.html',
  styleUrls: ['./subscription-list.component.scss']
})
export class SubscriptionListComponent implements OnInit, OnDestroy {
  subscriptionListArr = [];
  checkAllPauseFlag: boolean;
  routeSubs: Subscription;
  type;
  orderSubs: Subscription;
  orderArr;
  lowBalanceFlag = false;
  gyanStarArr;
  totalObj;

  constructor(private router: Router, private subscriptionService: SubscriptionService, private commonService: CommonService,
              private route: ActivatedRoute, private fireAnalytics: FirebaseAnalyticsCustomService,
              private sharedService: SharedService) { }

  ngOnInit(): void {
    this.routeSubs = this.route.queryParams.subscribe(params => {
      if (params && params.type) {
        this.type = params.type
        this.getOrder();
      }
    })
    // this.subscriptionList();
  }

  ngOnDestroy() {
    this.routeSubs.unsubscribe();
    if (this.orderArr) {
      this.orderSubs.unsubscribe();
    }
  }

  getOrder() {
    const endPoint = this.type === 'TOM' ? 'tommorowOrders' : 'upcomingMonthOrders'
    if (this.type === 'TOM') {
      clevertap.event.push(app_strings.CUSTOME.TOMORROW_ORDER, {
        "platform": localStorage.getItem('deviceType')
      });
      this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.TOMORROW_ORDER);
    } else {
      clevertap.event.push(app_strings.CUSTOME.FUTURE_ORDER, {
        "platform": localStorage.getItem('deviceType')
      });
      this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.FUTURE_ORDER);
    }
    this.orderSubs = this.subscriptionService.getOrders(endPoint).subscribe(res => {
      if (res && res.status === 200) {
        this.orderArr = [];
        this.orderArr = res.data;
        this.totalObj = res.response;
        this.gyanStarArr = [];
        this.gyanStarArr = res.gyanOrderOrCategory;
        this.lowBalanceFlag = res.response.isLowBalance;
        // let quantity = 0;
        this.orderArr.forEach(element => {
          let quantity = 0;
          element.productInfo = JSON.parse(element.productInfo);
          if (element.subscriptionDaysType === 'ONCE' || element.subscriptionDaysType === 'DAILY' || element.subscriptionDaysType === 'ALTERNATE_DAYS') {
            quantity = element.weeklyData[0].qty;
            element.totalQuantity = quantity;
            return;
          }
          element.weeklyData.forEach(element2 => {
            if (element2.status === 'ACTIVE') {
              quantity = quantity + element2.qty;
            }
          });
          element.totalQuantity = quantity;

        });
        console.log('list', this.orderArr);
      }
    })
  }

  toggleLogic(type: string) {
    if (this.type === type) {
      return;
    }
    this.type = type;
    this.getOrder();
  }

  openSubscriptionView(item, type) {
    // this.router.navigate(['page/subscription/list/' + id]);
    const subsType = item.subscriptionDaysType === 'ONCE' ? 1 : 2;
    if (subsType === 1) {
      this.router.navigate(['/page/product/list/' + item._id + '/once'],
    { queryParams: { data: JSON.stringify(item), type: subsType, fromType: type } });
    } else {
      this.router.navigate(['/page/product/list/' + item._id + '/editSubs'],
    { queryParams: { data: JSON.stringify(item), type: subsType, fromType: type } });
    }
  }
  // function to get subscription list
  subscriptionList() {
    this.subscriptionService.getSubscriptionList().subscribe(response => {
      this.subscriptionListArr = undefined;
      if (response.status === 200 && response.data && response.data.length > 0) {
        this.subscriptionListArr = response.data;
        let quantity = 0;
        this.subscriptionListArr.forEach(element => {
          element.productInfo = JSON.parse(element.productInfo);
          if (element.subscriptionDaysType === 'DAILY') {
            element.totalQuantity = element.weeklyData[0].qty;
            return;
          } else {
            element.weeklyData.forEach(element2 => {
              if (element2.status === 'ACTIVE') {
                quantity = quantity + element2.qty;
              }
            });
          }
          element.totalQuantity = quantity;
        });
        if (this.subscriptionListArr && this.subscriptionListArr.some(element => element.status === 'INITIATED')) {
          this.checkAllPauseFlag = false;
        } else {
          this.checkAllPauseFlag = true;
        }
        debugger
        console.log('subscriptionListArr', this.subscriptionListArr);
      }
    });
  }
  // function to pause subscription
  // pauseSubscription() {
  //   const payload = {
  //     status: 'PAUSED'
  //   };
  //   this.subscriptionService.pauseSubscription(payload).subscribe(response => {
  //     if (response.status === 200) {
  //       this.commonService.showSuccess('All Subscription have been paused');
  //       this.subscriptionList();
  //     }
  //   });
  // }
  // function to delete subscription
  deleteSubscription(subscription) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to delete this subscription!',
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        const payload = {};
        this.subscriptionService.deleteSubscription(payload, subscription._id).subscribe(response => {
      if (response.status === 200) {
        this.commonService.showSuccess('Subscription deleted');
        this.getOrder();
        this.sharedService.getCartData();
        this.sharedService.fetchBalance();
      }
    });
        // Swal.fire(
        //   'Deleted!',
        //   'Your imaginary file has been deleted.',
        //   'success'
        // )
      // For more information about handling dismissals please visit
      // https://sweetalert2.github.io/#handling-dismissals
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        // Swal.fire(
        //   'Cancelled',
        //   'Your imaginary file is safe :)',
        //   'error'
        // )
      }
    })

  }
  // function to resume subscription
  // resumeSubscription() {
  //   const payload = {
  //     status: 'INITIATED'
  //   };
  //   this.subscriptionService.pauseSubscription(payload).subscribe(response => {
  //     if (response.status === 200) {
  //       this.commonService.showSuccess('All Subscription have been resumed');
  //       this.subscriptionList();
  //     }
  //   });
  // }

  // function to open product list
  openProductList() {
    this.router.navigate(['page/product/list']);
  }

  // function to request pause subscription
  pauseSubscription1(type, id?, index?: number) {
    Swal.fire({
      title: 'Are you sure?',
      text: `You want to pause ${type === 'all' ? 'all subscriptions' : 'this subscription'} ?`,
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        if (type === 'all') {
          const payload = {
            status: 'PAUSED'
          };
          this.subscriptionService.pauseSubscription(payload).subscribe(response => {
            if (response.status === 200) {
              this.commonService.showSuccess('All Subscriptions has been paused');
              this.subscriptionList();
            }
          });
        } else {
          const payload = {
            status: 'SINGLE_PAUSED'
          };
          this.subscriptionService.pauseSingleSubscription(payload, id).subscribe(response => {
            if (response.status === 200) {
              this.commonService.showSuccess('This Subscription has been paused');
              // this.subscriptionList();
              this.orderArr[index].status = 'SINGLE_PAUSED';
              this.sharedService.getCartData();
            }
          });
        }
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        if (type === 'single') {
          const flag = $('#subCheck' + index).is(':checked');
          $('#subCheck' + index).prop('checked', !flag);
        }
      }
    });
  }

  // function to request pause subscription
  resumeSubscription1(type, id?, index?: number) {
    Swal.fire({
      title: 'Are you sure?',
      text: `You want to resume ${type === 'all' ? 'all subscriptions' : 'this subscription'} ?`,
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        if (type === 'all') {
          const payload = {
            status: 'INITIATED'
          };
          this.subscriptionService.pauseSubscription(payload).subscribe(response => {
            if (response.status === 200) {
              this.commonService.showSuccess('All Subscriptions has been resumed');
              this.subscriptionList();
            }
          });
        } else {
          const payload = {
            status: 'INITIATED'
          };
          this.subscriptionService.pauseSingleSubscription(payload, id).subscribe(response => {
            if (response.status === 200) {
              this.commonService.showSuccess('This Subscription has been resumed');
              // this.subscriptionList();
              this.orderArr[index].status = 'INITIATED';
              this.sharedService.getCartData();
            }
          });
        }
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        if (type === 'single') {
          const flag = $('#subCheck' + index).is(':checked');
          $('#subCheck' + index).prop('checked', !flag);
        }
      }
    });
  }

  // function to delete gyan order
  deleteGyanOrder(subscription) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to delete this order!',
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        const payload = {};
        this.subscriptionService.deleteGyan(payload, subscription._id).subscribe(response => {
      if (response.status === 200) {
        this.commonService.showSuccess('Order deleted');
        this.getOrder();
        this.sharedService.getCartData();
        this.sharedService.fetchBalance();
      }
    });
        // Swal.fire(
        //   'Deleted!',
        //   'Your imaginary file has been deleted.',
        //   'success'
        // )
      // For more information about handling dismissals please visit
      // https://sweetalert2.github.io/#handling-dismissals
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        // Swal.fire(
        //   'Cancelled',
        //   'Your imaginary file is safe :)',
        //   'error'
        // )
      }
    })

  }

}
