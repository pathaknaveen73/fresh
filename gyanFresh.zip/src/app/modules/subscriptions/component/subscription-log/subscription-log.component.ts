import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SubscriptionService } from '../../serviceFile/subscription.service';

@Component({
  selector: 'app-subscription-log',
  templateUrl: './subscription-log.component.html',
  styleUrls: ['./subscription-log.component.scss']
})
export class SubscriptionLogComponent implements OnInit {
  id;
  subscriptionLogArr;
  // today = new Date();
  backDates = new Date();
  todayDate = new Date().getDate();
  todayMonth = new Date().getMonth();
  todayYear = new Date().getFullYear();

  constructor(private route: ActivatedRoute, private subService: SubscriptionService) {
    this.backDates.setDate(this.backDates.getDate() - 2);
    // this.yesterday.setDate(this.yesterday.getDate() - 1);
   }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.getSubscriptionLog(this.id);
  }

  // function to get subscription log
  getSubscriptionLog(id) {
    const payload = {
      _id: id
    };
    this.subService.getSubscriptionLog(payload).subscribe(response => {
      if (response.status === 200) {
        this.subscriptionLogArr = response.data;
        this.subscriptionLogArr.forEach((element, i) => {
          if (!element.updatedValues.length) {
            this.subscriptionLogArr.splice(i, 1);
          }
          element.updatedDate = new Date(element.updatedAt).getDate();
          element.formattedDate = new Date(element.updatedAt);
          element.updatedMonth = new Date(element.updatedAt).getMonth();
          element.updatedYear = new Date(element.updatedAt).getFullYear();
          // element.updatedValues.forEach(element1 => {
          //   switch (element1) {
          //     case 'FROM_DATE':
          //       element1 = 'From Date';
          //       break;

          //       case 'SUBSCRIPTION_DAYS_TYPE':
          //       element1 = 'Subscription Type';
          //       break;

          //       case 'QTY':
          //       element1 = 'Quantity';
          //       break;

          //       case 'STATUS':
          //       element1 = 'Status';
          //       break;

          //     default:
          //       break;
          //   }
          // });
        });
        console.log('subscriptionLogArr', this.subscriptionLogArr);
      }
    });
  }

}
