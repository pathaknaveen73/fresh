import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscriptionLogComponent } from './subscription-log.component';

describe('SubscriptionLogComponent', () => {
  let component: SubscriptionLogComponent;
  let fixture: ComponentFixture<SubscriptionLogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubscriptionLogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubscriptionLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
