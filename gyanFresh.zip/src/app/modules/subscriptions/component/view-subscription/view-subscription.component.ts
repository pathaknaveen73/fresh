import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SubscriptionService } from '../../serviceFile/subscription.service';

@Component({
  selector: 'app-view-subscription',
  templateUrl: './view-subscription.component.html',
  styleUrls: ['./view-subscription.component.scss']
})
export class ViewSubscriptionComponent implements OnInit {
  id;
  subscriptionDetail;

  constructor(private router: Router, private route: ActivatedRoute, private subService: SubscriptionService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.getSubscriptionDetail(this.id);
  }

  // function to get subscription detail
  getSubscriptionDetail(id) {
    const payload = {
      _id: id
    };
    this.subService.getSubscriptionDetail(payload).subscribe(response => {
      if (response.status === 200) {
        this.subscriptionDetail = response.data;
        this.subscriptionDetail.productInfo = JSON.parse(this.subscriptionDetail.productInfo);
        let quantity = 0;
        this.subscriptionDetail.weeklyData.forEach((element) => {
          if (element.status === 'ACTIVE') {
            quantity = quantity + element.qty;
          }
          element.timeFrame = element.startTime + ' - ' + element.endTime;
          switch (element.day) {
            case '0':
              element.dayText = 'Sunday';
              break;
            case '1':
              element.dayText = 'Monday';
              break;
            case '2':
              element.dayText = 'Tuesday';
              break;
            case '3':
              element.dayText = 'Wednesday';
              break;
            case '4':
              element.dayText = 'Thursday';
              break;
            case '5':
              element.dayText = 'Friday';
              break;
            case '6':
              element.dayText = 'Saturday';
              break;
          }
          this.subscriptionDetail.totalQuantity = quantity;
        });
        this.subscriptionDetail.weeklyData.sort(function(a, b) {
          const keyA = Number(a.day);
          const keyB = Number(b.day);
          // Compare the 2 values
          if (keyA < keyB) return -1;
          if (keyA > keyB) return 1;
          return 0;
        });
        console.log('subscriptionDetailArr', this.subscriptionDetail);
      }
    });
  }
  // function to open susbcription log
  openSubscriptionLog(id) {
    this.router.navigate(['page/subscription/list/' + id + '/log']);
  }
  // function to open edit subscription
  openEditSubscription(id) {
    this.router.navigate(['page/subscription/list/' + id + '/edit']);
  }

}
