import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SubscriptionService } from '../../serviceFile/subscription.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-subscription',
  templateUrl: './edit-subscription.component.html',
  styleUrls: ['./edit-subscription.component.scss']
})
export class EditSubscriptionComponent implements OnInit {
  id;
  subscriptionDetail;
  editSubscriptionForm: FormGroup;
  submitted = false;
  dayForm: FormArray;
  dayArr;
  noneDaySelected = false;
  setWeeklyData = [];
  timeSlotsArr;
  selectedTimeSlot = [];
  setWeeklyQuanityForm = [];
  setStatusForm = [];
  updatedValueArr = [];

  constructor(private router: Router, private subService: SubscriptionService, private route: ActivatedRoute, private commonService: CommonService, private fb: FormBuilder) {
    this.dayArr = [
      { label: 'Sunday', value: 0 },
      { label: 'Monday', value: 1 },
      { label: 'Tuesday', value: 2 },
      { label: 'Wednesday', value: 3 },
      { label: 'Thursday', value: 4 },
      { label: 'Friday', value: 5 },
      { label: 'Saturday', value: 6 }
    ];
   }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.getSubscriptionDetail(this.id);
    // this.getTimeSlots();
    this.setFormField();
  }

  // function to get subscription detail
  getSubscriptionDetail(id) {
    const payload = {
      _id: id
    };
    this.subService.getSubscriptionDetail(payload).subscribe(response => {
      if (response.status === 200) {
        this.subscriptionDetail = response.data;
        this.subscriptionDetail.productInfo = JSON.parse(this.subscriptionDetail.productInfo);
        let quantity = 0;
        this.subscriptionDetail.weeklyData.forEach((element) => {
          if (element.status === 'ACTIVE') {
            quantity = quantity + element.qty;
          }
          element.timeFrame = element.startTime + ' - ' + element.endTime;
          switch (element.day) {
            case '0':
              element.dayText = 'Sunday';
              break;
            case '1':
              element.dayText = 'Monday';
              break;
            case '2':
              element.dayText = 'Tuesday';
              break;
            case '3':
              element.dayText = 'Wednesday';
              break;
            case '4':
              element.dayText = 'Thursday';
              break;
            case '5':
              element.dayText = 'Friday';
              break;
            case '6':
              element.dayText = 'Saturday';
              break;
          }
          this.subscriptionDetail.totalQuantity = quantity;
        });
        this.subscriptionDetail.weeklyData.sort(function(a, b) {
          const keyA = Number(a.day);
          const keyB = Number(b.day);
          // Compare the 2 values
          if (keyA < keyB) return -1;
          if (keyA > keyB) return 1;
          return 0;
        });
        this.subscriptionDetail.weeklyData.forEach((element, i) => {
          this.setWeeklyQuanityForm[i] = element.qty;
          this.setStatusForm[i] = element.status;
        });
        console.log('subscriptionDetailArr', this.subscriptionDetail);
        console.log('weeklyQuntity', this.setWeeklyQuanityForm);
        console.log('setStatusForm', this.setStatusForm);
        this.setStatusUpdate();
        this.getTimeSlots();
      }
    });
  }
  // function to cancel update and go back
  navigateBack(id) {
    this.router.navigate(['page/subscription/list/' + id], { replaceUrl: true });
  }
  // get form control
  get f() { return this.editSubscriptionForm.controls; }
  // set form field
  setFormField() {
    this.editSubscriptionForm = this.fb.group({
      dayForm: this.fb.array([])
    });
    this.addDayForm();
  }
  // function to create form array
  createDayForm(): FormGroup {
    return this.fb.group({
      day: ['', [Validators.required]],
      dummyDay: [0],
      // startTime: ['', [Validators.required]],
      // endTime: ['', [Validators.required]],
      qty: [1, [Validators.required]],
      status: ['', [Validators.required]],
      timeFrame: ['', [Validators.required]]
    });
  }
  // function to add day form
  addDayForm() {
    this.dayForm = this.editSubscriptionForm.get('dayForm') as FormArray;
    for (let i = 0; i < 7; i++) {
      this.dayForm.push(this.createDayForm());
      this.editSubscriptionForm.get('dayForm')['controls'][i].controls.day.setValue(this.dayArr[i]);
    }
  }
  // function to submit subscribe form
  submitEditSubscriptionForm() {
    this.submitted = true;
    if (!this.editSubscriptionForm.valid) {
      console.log('notValidSubscribeForm', this.editSubscriptionForm.controls);
      return;
    }
    this.noneDaySelected = this.editSubscriptionForm.get('dayForm')['controls'].every(element => element.value.status === 'INACTIVE');
    if (this.noneDaySelected) {
      console.log('notValidSubscribeForm', this.editSubscriptionForm.controls);
      return;
    }
    this.setWeeklyData = [];
    this.updatedValueArr = [];
    this.editSubscriptionForm.get('dayForm')['controls'].forEach(element => {
      this.setWeeklyData.push(
        {
          day: element.value.day.value,
          startTime: element.value.timeFrame.from,
          endTime: element.value.timeFrame.to,
          qty: element.value.qty,
          status: element.value.status,
          _id: element.value._id
        }
      );
    });
    console.log('weeklyData', this.setWeeklyData);
    let updatedValStatus = false;
    for (let i = 0; i < this.subscriptionDetail.weeklyData.length; i++) {
        if (this.subscriptionDetail.weeklyData[i].status !== this.setWeeklyData[i].status) {
          this.updatedValueArr.push('STATUS');
          updatedValStatus = true;
          break;
        }
    }
    let updatedValQuantity = false;
    for (let i = 0; i < this.subscriptionDetail.weeklyData.length; i++) {
        if (this.subscriptionDetail.weeklyData[i].qty !== this.setWeeklyData[i].qty) {
          this.updatedValueArr.push('QTY');
          updatedValQuantity = true;
          break;
        }
    }
    let updatedValTimeSlot = false;
    for (let i = 0; i < this.subscriptionDetail.weeklyData.length; i++) {
        if (this.subscriptionDetail.weeklyData[i].startTime !== this.setWeeklyData[i].startTime) {
          this.updatedValueArr.push('TIMESLOT');
          updatedValTimeSlot = true;
          break;
        }
    }
    console.log('updatedValue', this.updatedValueArr);
    if (this.updatedValueArr.length === 0) {
      Swal.fire({
        title: 'No changes detected',
        text: 'There were no changes made to this subscription!',
        icon: 'warning',
        showCancelButton: false,
        allowOutsideClick: false,
        confirmButtonText: 'Ok',
        cancelButtonText: 'No, keep it'
      }).then((result) => {
        if (result.value) {
          console.log('ok pressed');
          this.router.navigate(['page/subscription'], { replaceUrl: true });
        } else if (result.dismiss === Swal.DismissReason.cancel) {
        }
      });
    } else {
      const payload = {
        weeklyData: this.setWeeklyData,
        updatedValues: this.updatedValueArr
      };
      this.subService.updateSubscription(payload, this.id).subscribe(response => {
        if (response.status === 200) {
          this.commonService.showSuccess('Subscription updated successfully');
          this.router.navigate(['page/subscription'], { replaceUrl: true });
        } else {
          this.commonService.showError(response.message);
        }
      });
    }

  }
  // function to get time slots
  getTimeSlots() {
    this.subService.getTimeSlot().subscribe(response => {
      this.timeSlotsArr = response && response.data ? response.data : '';
      this.timeSlotsArr.forEach(element => {
        element.timeFrame = element.from + ' - ' + element.to;
      });
      this.subscriptionDetail.weeklyData.forEach((element, i) => {
        this.timeSlotsArr.forEach((element2) => {
          if ( element.timeFrame == element2.timeFrame ) {
            this.selectedTimeSlot[i] = element2;
          }
        });
      });
      console.log('timeSlots', this.timeSlotsArr);
      console.log('selectedTimeSlot', this.selectedTimeSlot);
    });
  }
  // function to increase quantity
  increaseValue(value, i) {
    const newVal = value + 1;
    // this.addCartForm.controls.productQuantity.setValue(newVal);
    this.editSubscriptionForm.get('dayForm')['controls'][i].controls.qty.setValue(newVal);

  }
  // function to decrease quantity
  decreaseValue(value, i) {
    if (value <= 1) {
      return;
    }
    const newVal = value - 1;
    // this.addCartForm.controls.productQuantity.setValue(newVal);
    this.editSubscriptionForm.get('dayForm')['controls'][i].controls.qty.setValue(newVal);
  }
  // function to update day status
  updateDayStatus(i) {
    let statusVal = this.editSubscriptionForm.get('dayForm')['controls'][i].controls.status.value;
    let newStatusVal;
    if (statusVal === 'ACTIVE') {
      newStatusVal = 'INACTIVE';
    } else {
      newStatusVal = 'ACTIVE';
    }
    this.editSubscriptionForm.get('dayForm')['controls'][i].controls.status.setValue(newStatusVal);
  }
  // function to update the status form filed
  setStatusUpdate() {
    for (let i = 0; i < 7; i++) {
      this.editSubscriptionForm.get('dayForm')['controls'][i].controls.status.setValue(this.setStatusForm[i]);
    }
  }

}
