import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SubscriptionListComponent } from './component/subscription-list/subscription-list.component';
// import { ViewSubscriptionComponent } from './component/view-subscription/view-subscription.component';
// import { EditSubscriptionComponent } from './component/edit-subscription/edit-subscription.component';
import { SubscriptionLogComponent } from './component/subscription-log/subscription-log.component';
import { Routes, RouterModule } from '@angular/router';
import { SubscriptionService } from './serviceFile/subscription.service';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import {MatCardModule} from '@angular/material/card';
import {MatDividerModule} from '@angular/material/divider';

export const routes: Routes = [
  { path: 'list', component: SubscriptionListComponent },
  // { path: 'list/:id', component: ViewSubscriptionComponent },
  // { path: 'list/:id/edit', component: EditSubscriptionComponent },
  { path: 'list/:id/log', component: SubscriptionLogComponent },
  { path: '', redirectTo: 'list', pathMatch: 'full' }
];

@NgModule({
  declarations: [SubscriptionListComponent,
    //  ViewSubscriptionComponent,
      // EditSubscriptionComponent,
       SubscriptionLogComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    LazyLoadImageModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatCardModule,
    MatDividerModule
  ],
  providers: [SubscriptionService],
  exports: [SubscriptionListComponent,
    // ViewSubscriptionComponent,
    // EditSubscriptionComponent,
    SubscriptionLogComponent]
})
export class SubscriptionsModule { }
