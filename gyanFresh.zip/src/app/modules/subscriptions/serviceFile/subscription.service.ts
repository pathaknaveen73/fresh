import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class SubscriptionService {

  constructor(private apiService: ApiService) { }

  getSubscriptionList() {
    const url = 'subscriptions';
    return this.apiService.getApi(url);
  }
  pauseSubscription(paylaod) {
    const url = 'pauseSubscription';
    return this.apiService.putApi(url, paylaod);
  }
  deleteSubscription(paylaod, id) {
    const url = 'subscriptionStatus/' + id;
    return this.apiService.putApi(url, paylaod);
  }
  getSubscriptionDetail(payload) {
    const url = 'subscriptionDetail/' + payload._id;
    return this.apiService.getApi(url);
  }
  getSubscriptionLog(payload) {
    const url = 'subscriptionLog/' + payload._id;
    return this.apiService.getApi(url);
  }
  updateSubscription(payload, id) {
    const url = 'subscriptionDetail/' + id;
    return this.apiService.putApi(url, payload);
  }
  getTimeSlot() {
    const url = 'timeSlots';
    return this.apiService.getApi(url);
  }
  pauseSingleSubscription(paylaod, id) {
    const url = 'pauseSingleSubscription/' + id;
    return this.apiService.putApi(url, paylaod);
  }
  getOrders(endPoint) {
    const url = `${endPoint}`;
    return this.apiService.getApi(url);
  }
  deleteGyan(paylaod, id) {
    const url = 'deleteGyanStarOrderFromCart/' + id;
    return this.apiService.putApi(url, paylaod);
  }
}
