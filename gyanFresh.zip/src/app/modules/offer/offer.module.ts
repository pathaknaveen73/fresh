import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OfferListComponent } from './component/offer-list/offer-list.component';
import { OfferDetailComponent } from './component/offer-detail/offer-detail.component';
import { Routes, RouterModule } from '@angular/router';
import { OfferService } from './serviceFile/offer.service';
import { LazyLoadImageModule } from 'ng-lazyload-image';

export const routes: Routes = [
  { path: '', component: OfferListComponent, pathMatch: 'full' },
  { path: ':id', component: OfferDetailComponent }
];

@NgModule({
  declarations: [OfferListComponent, OfferDetailComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    LazyLoadImageModule
  ],
  providers: [OfferService],
  exports: [OfferListComponent, OfferDetailComponent]
})
export class OfferModule { }
