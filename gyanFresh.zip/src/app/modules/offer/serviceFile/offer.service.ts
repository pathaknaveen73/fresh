import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class OfferService {

  constructor(private apiService: ApiService) { }

  // function to fetch offers list
  getOffers() {
    const url = 'offerList';
    return this.apiService.getApi(url);
  }

  // function to fetch offers list
  getForYouOffers() {
    const url = 'offersForYou';
    return this.apiService.getApi(url);
  }

  // function to get offer detail
  getOfferDetail(offerID) {
    const url = 'offerDetail/' + offerID;
    return this.apiService.getApi(url);
  }

  // function to add offer product to cart
  addToCart(payload) {
    const url = 'cartItems';
    return this.apiService.postApi(url, payload);
  }

  // function to get auto recharge detail
  getWalletBalance() {
    const url = 'getAutoRechargeDetail';
    return this.apiService.getApi(url);
  }
}
