import { Component, OnInit } from '@angular/core';
import { OfferService } from '../../serviceFile/offer.service';
import { Router } from '@angular/router';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';

declare let clevertap: any;

@Component({
  selector: 'app-offer-list',
  templateUrl: './offer-list.component.html',
  styleUrls: ['./offer-list.component.scss']
})
export class OfferListComponent implements OnInit {
  offerListArr;
  forYouOfferListArr;

  constructor(private offerService: OfferService, private router: Router, private sharedService: SharedService,
              private commonService: CommonService, private fireAnalytics: FirebaseAnalyticsCustomService) { }

  ngOnInit(): void {
    this.getOffersList();
    this.getForYouOfferList();
  }

  // function to get offers list
  getOffersList() {
    this.offerService.getOffers().subscribe(response => {
      if (response.status === 200) {
        this.offerListArr = response.data;
        console.log('offerListArr', this.offerListArr);
      }
    });
  }

  // function to get offers list
  getForYouOfferList() {
    this.offerService.getForYouOffers().subscribe(response => {
      if (response.status === 200) {
        this.forYouOfferListArr = response.data;
        console.log('offerListArr', this.forYouOfferListArr);
      }
    });
  }

  // function to open offer detail
  openOfferDetail(offerId) {
    this.router.navigate(['page/offers/' + offerId]);
  }

  // function to add to basket
  addToCart(item) {
    // this.router.navigate(['/page/product/list/' + item._id + '/buyOnce']);
    console.log('item', item);
    // return;
    const payload = {
      qty: '1',
      productId: item.item._id,
      productType: 'OFFER',
      offerId: item._id
    };
    this.offerService.addToCart(payload).subscribe(response => {
      if (response.status === 200) {
        // this.sharedService.getCartItems();
        this.commonService.showSuccess('Item added to basket');
        this.router.navigate(['page/cart']);
        // this.addedToCartFlag = true;
      }
    });
  }

  offerTabClick(type: number) {
    if (type === 1) {
      // clevertap.event.push(app_strings.CUSTOME.GENERAL_OFFER, {
      //   "platform": localStorage.getItem('deviceType')
      // });
      this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.GENERAL_OFFERS);
    } else {
      // clevertap.event.push(app_strings.CUSTOME.MY_OFFER, {
      //   "platform": localStorage.getItem('deviceType')
      // });
      this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.MY_OFFER);
    }
  }

}
