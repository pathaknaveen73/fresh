import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OfferService } from '../../serviceFile/offer.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { BuyOnceService } from 'src/app/serviceFile/buyOnce.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';

declare let $: any;
declare var clevertap: any;

@Component({
  selector: 'app-offer-detail',
  templateUrl: './offer-detail.component.html',
  styleUrls: ['./offer-detail.component.scss']
})
export class OfferDetailComponent implements OnInit {
  id;
  offerDetailArr;
  walletNeededBal;
  walletAvailableBal;

  constructor(private route: ActivatedRoute, private router: Router, private offerService: OfferService,
              private commonService: CommonService, private buyService: BuyOnceService, private fireAnalytics: FirebaseAnalyticsCustomService) { }

  ngOnInit(): void {
    // clevertap.event.push(app_strings.OFFER_CHECK, {
    //   "platform": localStorage.getItem('deviceType')
    // });
    this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.OFFER_CHECKED);
    this.id = this.route.snapshot.paramMap.get('id');
    this.offerDetail(this.id);
    this.getWalletBalance();
  }

  getWalletBalance() {
    this.commonService.showSpinner();
    this.offerService.getWalletBalance().subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.hideSpinner();
        this.walletAvailableBal = res.data.walletAmount.walletAmount;
      }
    }, error => {
      this.commonService.hideSpinner();
      this.commonService.showError(error);
    });
  }

  // function to get offer detail
  offerDetail(id) {
    this.offerService.getOfferDetail(id).subscribe(response => {
      if (response.status === 200) {
        const dataArr = [];
        dataArr.push(response.data);
        this.offerDetailArr = dataArr;
        console.log('offerDetailArr', this.offerDetailArr);
      }
    });
  }

  // function to add offer product in cart
  addToCart(item) {
    // this.router.navigate(['/page/product/list/' + item._id + '/buyOnce']);
    console.log('item', item);
    // return;
    const payload = {
      qty: '1',
      productId: item.item._id,
      productType: 'OFFER',
      offerId: item._id
    };
    this.offerService.addToCart(payload).subscribe(response => {
      if (response.status === 200) {
        // this.sharedService.getCartItems();
        this.commonService.showSuccess('Item added to basket');
        this.router.navigate(['page/cart']);
        // this.addedToCartFlag = true;
      }
    });
  }

  // function to open product detail
  openProductDetail(item) {
    // this.router.navigateByUrl('/page/product/list/' + item.item._id);
    this.router.navigate(['/page/product/list/detail'], { queryParams: { id: item.item._id } });
  }

  // buyOnce(item) {
  //   this.commonService.showSpinner();
  //   this.buyService.setFormField(item, 1, new Date(), { editFlag: true, editVal: [] }, 'offer', item);
  // }

  buyOnce(item) {
    if (this.walletAvailableBal < item.price) {
      this.walletNeededBal = item.item.price - this.walletAvailableBal;
      $('#myModal1').modal('show');
    } else {
      this.commonService.showSpinner();
      // this.buyService.setFormField(item, 1, new Date(), { editFlag: false, editVal: [] }, productType: 'offer', offerTypeVal: item.offerType);
      this.buyService.setFormField(item, 1, new Date(),
      { editFlag: false, editVal: [], alreadySubscribe: false }, 'offer', item)
      .then(res => {
        $('#buyOnceModal').modal('show');
        this.offerDetail(this.id);
      });
    }
  }

  closeLessBalModal() {
    $('#myModal1').modal('hide');
  }

  // function to navigate to stripe checkout if wallet bal is below order total amount
  navigateToAddMoney() {
    $('#myModal1').modal('hide');
    const payload = {
      amount: this.walletNeededBal,
      currency: 'inr'
    };
    this.router.navigate(['page/wallet/addMoney'], { queryParams: { amount: this.walletNeededBal } });
  }

}
