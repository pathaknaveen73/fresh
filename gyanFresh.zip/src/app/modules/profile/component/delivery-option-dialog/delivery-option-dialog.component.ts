import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ProfileService } from '../../serviceFile/profile.service';
import { CommonService } from 'src/app/serviceFile/common.service';

@Component({
  selector: 'app-delivery-option-dialog',
  templateUrl: './delivery-option-dialog.component.html',
  styleUrls: ['./delivery-option-dialog.component.scss']
})
export class DeliveryOptionDialogComponent implements OnInit {
  deliveryOptionSelected;
  option;
  deliveryOptionSelectedCompareOnly;

  constructor(public dialogRef: MatDialogRef<DeliveryOptionDialogComponent>, @Inject(MAT_DIALOG_DATA) public data,
              private profileService: ProfileService, private commonService: CommonService) { }

  ngOnInit(): void {
    this.getDeliveryOption();
  }

  // function to get delivery option
  getDeliveryOption() {
    this.profileService.getDeliveryOption().subscribe(response => {
      if (response.status === 200) {
        this.option = response.data;
        this.option.options.forEach(element => {
          if (element.id === this.option.deliveryOption.deliveryOption) {
            this.deliveryOptionSelected = element.id;
            this.deliveryOptionSelectedCompareOnly = element.id;
          }
        });
        console.log('options', this.option);
      }
    });
  }

  // function to submit delivery option
  submit() {
    if (this.deliveryOptionSelectedCompareOnly === this.deliveryOptionSelected) {
      this.dialogRef.close();
    } else {
      const payload = {
        deliveryOption: this.deliveryOptionSelected
      };
      this.profileService.editDeliveryOptions(payload).subscribe(response => {
        if (response.status === 200) {
          this.commonService.showSuccess('Updated Successfully');
          this.dialogRef.close();
        }
      });
    }
  }

}
