import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryOptionDialogComponent } from './delivery-option-dialog.component';

describe('DeliveryOptionDialogComponent', () => {
  let component: DeliveryOptionDialogComponent;
  let fixture: ComponentFixture<DeliveryOptionDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryOptionDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryOptionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
