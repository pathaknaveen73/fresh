import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProfileService } from '../../serviceFile/profile.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import Swal from 'sweetalert2';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';

declare let clevertap: any;

@Component({
  selector: 'app-deactivate-account',
  templateUrl: './deactivate-account.component.html',
  styleUrls: ['./deactivate-account.component.scss']
})
export class DeactivateAccountComponent implements OnInit {
  deactivateAccountForm: FormGroup;
  submitted = false;
  today = new Date();

  constructor(private router: Router, private profileService: ProfileService, private commonService: CommonService,
              private fb: FormBuilder, private fireAnalytics: FirebaseAnalyticsCustomService) {
                this.today.setDate(this.today.getDate() + 1);
               }

  ngOnInit(): void {
    this.setFormField();
  }

  // function to set deactivate account form field
  setFormField() {
    this.deactivateAccountForm = this.fb.group({
      date: ['', Validators.required]
    });
  }

  // function to get form controls
  get f() { return this.deactivateAccountForm.controls; }

  // function to submit deactivate account form
  submit() {
    this.submitted = true;
    if (!this.deactivateAccountForm.valid) {
      console.log('invalidDeactivateForm', this.deactivateAccountForm.controls);
      return;
    }
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to deactivate your account !',
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        const payload = {
          status: 'INACTIVE',
          inactiveDate: this.deactivateAccountForm.controls.date.value.toISOString()
        };
        this.profileService.deactivateProfile(payload).subscribe(response => {
          if (response.status === 200) {
            // clevertap.event.push(app_strings.CUSTOME.DEACTIVATE_ACCOUNT, {
            //   "platform": localStorage.getItem('deviceType')
            // });
            this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.DEACTIVATE_ACCOUNT);
            this.commonService.showSuccess(response.message);
            // this.router.navigate(['page/profile']);
            // localStorage.removeItem('userToken');
            // localStorage.removeItem('userLocation');
            // localStorage.removeItem('userInfo');
            // localStorage.removeItem('gyannFCMdeviceId');
            localStorage.clear();
            this.router.navigate(['/login']);
          } else {
            this.commonService.showError(response.message);
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
      }
    });
  }

}
