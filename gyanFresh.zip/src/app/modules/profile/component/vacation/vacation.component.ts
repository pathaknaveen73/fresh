import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { CommonService } from 'src/app/serviceFile/common.service';
import { ProfileService } from '../../serviceFile/profile.service';

@Component({
  selector: 'app-vacation',
  templateUrl: './vacation.component.html',
  styleUrls: ['./vacation.component.scss']
})
export class VacationComponent implements OnInit {
  startDate = new FormControl(['', [Validators.required]]);
  endDate = new FormControl(['', [Validators.required]]);
  today = new Date().toISOString();
  submitted = false;
  vacationData;

  constructor(private cs: CommonService, private profileService: ProfileService, private router: Router) { }

  ngOnInit(): void {
    this.getVacation();
  }

  submit() {
    this.submitted = true;
    if (this.startDate.errors || this.endDate.errors || this.startDate.value === null || this.endDate.value === null) {
      console.log('error', this.startDate, this.endDate);
      this.cs.showError('Please select start / end date');
      return;
    }
    const obj = {
      vaccationStartDate: this.startDate.value,
      vaccationEndDate: this.endDate.value
    };
    // debugger
    this.profileService.setVacation(obj).pipe(take(1)).subscribe(res => {
      if (res && res.status === 200) {
        this.cs.showSuccess(res.message);
        // this.getVacation();
        this.router.navigate(['/page/profile']);
      } else {
        this.cs.showError(res.message);
      }
    }, err => {
      console.log(err);
    });
  }

  getVacation() {
    this.profileService.getVacation().pipe(take(1)).subscribe(res => {
      if (res && res.status === 200) {
        console.log('getVacation', res.data);
        if (res.data && res.data.vaccationStartDate) {
          this.vacationData = res.data;
          this.startDate.setValue(res.data.vaccationStartDate);
          this.endDate.setValue(res.data.vaccationEndDate);
        }
      }
    });
  }

  clearVacation() {
    this.profileService.resetVacation({}).pipe(take(1)).subscribe(res => {
      if (res && res.status === 200) {
        console.log('clearVacation', res.data);
        this.cs.showSuccess(res.message);
        this.startDate.setValue(null);
        this.endDate.setValue(null);
        this.vacationData = '';
      }
    });
  }

}
