import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProfileService } from '../../serviceFile/profile.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import Swal from 'sweetalert2';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { MatDialog } from '@angular/material/dialog';
import { DeliveryOptionDialogComponent } from '../delivery-option-dialog/delivery-option-dialog.component';

declare let clevertap: any;

@Component({
  selector: 'app-profile-list',
  templateUrl: './profile-list.component.html',
  styleUrls: ['./profile-list.component.scss']
})
export class ProfileListComponent implements OnInit {
  userInfo;
  allLocation;
  userPrimayLocation;
  imageSelected = false;

  constructor(private router: Router, private profileService: ProfileService, private commonService: CommonService,
              private sharedService: SharedService, private dialog: MatDialog) { }

  ngOnInit(): void {
    // to fetch user profile
    this.sharedService.getUserProfile();

    // to get user profile data
    this.sharedService.getUserProfileInfo().subscribe(profileData => {
      this.userInfo = profileData;
      this.allLocation = profileData['location'];
      this.allLocation.forEach(element => {
        if (element.default === 'PRIMARY') {
          this.userPrimayLocation = element;
        }
      });
      if (this.userInfo && this.userInfo.image) {
        this.imageSelected = true;
        // this.userInfo.profileCompleteness = 90;
      }
    });
    clevertap.event.push('Profile checked', {
      "platform": localStorage.getItem('deviceType')
    });
  }

  // function to navigate to contact us page
  contactUs() {
    this.router.navigate(['page/profile/contact']);
  }
  // function to navigate to edit profile
  editProfile() {
    this.router.navigate(['page/profile/edit']);
  }
  // function to delete account
  deleteAccount() {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to delete your account, this cannot be undone !',
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        const payload = {
          status: 'DELETED',
          inactiveDate: new Date().toISOString()
        };
        this.profileService.deleteProfile(payload).subscribe(response => {
          if (response.status === 200) {
            this.commonService.showSuccess(response.message);
            // localStorage.removeItem('userToken');
            // localStorage.removeItem('userLocation');
            // localStorage.removeItem('userInfo');
            // localStorage.removeItem('gyannFCMdeviceId');
            localStorage.clear();
            this.router.navigate(['/login']);
          } else {
            this.commonService.showError(response.message);
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
      }
    });
  }
  // function to deactivate account
  deactivateAccount() {
    // Swal.fire({
    //   title: 'Are you sure?',
    //   text: 'You want to deactivate your account !',
    //   icon: 'warning',
    //   showCancelButton: true,
    //   allowOutsideClick: false,
    //   confirmButtonText: 'Yes',
    //   cancelButtonText: 'No'
    // }).then((result) => {
    //   if (result.value) {
    //     const payload = {
    //       status: 'INACTIVE',
    //       inactiveDate: new Date().toISOString()
    //     };
    //     this.profileService.deactivateProfile(payload).subscribe(response => {
    //       if (response.status === 200) {
    //         this.commonService.showSuccess(response.message);
    //       } else {
    //         this.commonService.showError(response.message);
    //       }
    //     });
    //   } else if (result.dismiss === Swal.DismissReason.cancel) {
    //   }
    // });
    this.router.navigate(['page/profile/deactivateAccount']);
  }

  // function on delivery options
  deliveryOptions() {
    const dialogRef = this.dialog.open(DeliveryOptionDialogComponent, {
      width: '600px',
      height: 'auto',
      disableClose: true,
      data: {type: 'noLocation'}
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed', result);
      if (result !== undefined) {
        // console.log('result', result);
      }
    });
  }

}
