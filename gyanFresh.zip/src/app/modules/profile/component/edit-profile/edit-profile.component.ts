import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/serviceFile/common.service';
import { ProfileService } from '../../serviceFile/profile.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { trigger, transition, query, style, animate, group, state } from '@angular/animations';
import { Subscription } from 'rxjs';
declare let $: any;
declare var clevertap: any;

interface INCOME {
  range: string;
  value: number;
  min: number;
  max: number;
}

// const left = [
//   query(':enter, :leave', style({ position: 'fixed', width: '100%' }), { optional: true }),
//   group([
//     query(':enter', [style({ transform: 'translateX(-100%)' }), animate('.3s ease-out', style({ transform: 'translateX(0%)' }))], {
//       optional: true,
//     }),
//     query(':leave', [style({ transform: 'translateX(0%)' }), animate('.3s ease-out', style({ transform: 'translateX(100%)' }))], {
//       optional: true,
//     }),
//   ]),
// ];

// const right = [
//   query(':enter, :leave', style({ position: 'fixed', width: '100%' }), { optional: true }),
//   group([
//     query(':enter', [style({ transform: 'translateX(100%)' }), animate('.3s ease-out', style({ transform: 'translateX(0%)' }))], {
//       optional: true,
//     }),
//     query(':leave', [style({ transform: 'translateX(0%)' }), animate('.3s ease-out', style({ transform: 'translateX(-100%)' }))], {
//       optional: true,
//     }),
//   ]),
// ];

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss'],
  animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'translateX(100%)' }))
      ])
    ]),
    trigger('myInsertRemoveTrigger', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('100ms', style({ opacity: 1 })),
      ]),
      transition(':leave', [
        animate('100ms', style({ opacity: 0 }))
      ])
    ]),
  ]
})

export class EditProfileComponent implements OnInit, OnDestroy {
  userInfo;
  editProfileForm: FormGroup;
  submitted = false;
  imageUrl;
  imageSelected = false;
  removetext = true;
  userfullname;
  genders = ['MALE', 'FEMALE', 'OTHER'];
  today = new Date();
  selectedDOB;
  selectedGender;
  counter = 1;
  incomeArr: INCOME[] = [
    { range: 'less than 50k', value: 0, min: 0, max: 50000 },
    { range: '50k - 200k', value: 1, min: 50001, max: 200000 },
    { range: '200k - 500k', value: 2, min: 200001, max: 500000 },
    { range: 'above 500k', value: 3, min: 500001, max: 1000000 }
  ];
  submitted2 = false;
  profile$: Subscription;
  dummyIncome = new FormControl('');

  constructor(private router: Router, private fb: FormBuilder, private commonServie: CommonService,
              private profileService: ProfileService, private sharedService: SharedService) { }

  ngOnInit(): void {
    // to fetch user profile
    this.setFormField();
    this.sharedService.getUserProfile();

    // to get user profile data
    this.sharedService.getUserProfileInfo().subscribe(profileData => {
      console.log('checkProfile>>>>', profileData);
      this.userInfo = profileData;
      // this.userfullname = this.userInfo.fullName;
      // if (this.userInfo && this.userInfo.DOB) {
      //   this.selectedDOB = new Date(this.userInfo.DOB);
      //   // this.selectedDOB.setHours(18, 30);
      //   console.log('dateDOB', this.selectedDOB.toISOString());
      // }
      // if (this.userInfo && this.userInfo.gender) {
      //   this.selectedGender = this.userInfo.gender;
      // }
      if (this.userInfo && this.userInfo.image) {
        this.imageSelected = true;
        this.imageUrl = this.userInfo.image;
      }
      this.f.fullName.setValue(this.userInfo.fullName);
      if (this.userInfo) {
        if (this.userInfo.profileUpdateDetails.dob) {
          this.addValidators('DOB');
          this.f.DOB.setValue(new Date(this.userInfo.DOB));
        }
        if (this.userInfo.profileUpdateDetails.email) {
          this.addEmailValidator();
          this.f.email.setValue(this.userInfo.email);
        }
        if (this.userInfo.profileUpdateDetails.familySize) {
          this.addValidators('familySize');
          this.f.familySize.setValue(this.userInfo.familySize);
        }
        if (this.userInfo.profileUpdateDetails.foodPreference) {
          this.addValidators('foodPreference');
          this.f.foodPreference.setValue(this.userInfo.foodPreference);
        }
        if (this.userInfo.profileUpdateDetails.gender) {
          this.addValidators('gender');
          this.f.gender.setValue(this.userInfo.gender);
        }
        if (this.userInfo.profileUpdateDetails.maritalStatus) {
          this.addValidators('maritalStatus');
          this.f.maritalStatus.setValue(this.userInfo.maritalStatus);
        }
        if (this.userInfo.profileUpdateDetails.profession) {
          this.addValidators('profession');
          this.f.profession.setValue(this.userInfo.profession);
        }
        if (this.userInfo.profileUpdateDetails.profileInfo) {
          this.addValidators('profileInfo');
          this.f.profileInfo.setValue(this.userInfo.profileInfo);
        }
        if (this.userInfo.profileUpdateDetails.incomeBracket) {
          this.addValidators('incomeBracket');
          const val = this.userInfo.incomeBracket;
          const newVal = this.incomeArr.filter(x => x.min === Number(val.range.min));
          this.dummyIncome.setValue(newVal[0].value);
          this.f.incomeBracket.setValue(JSON.stringify(val));
        }
      }
    });
  }

  ngOnDestroy() {
    try {
      this.profile$.unsubscribe();
    } catch (error) {
      console.log(error);
    }
  }

  // function to set edit profile form
  setFormField() {
    this.editProfileForm = this.fb.group({
      photoToSend: [''],
      mobile: [''],
      fullName: ['', [Validators.required, Validators.pattern(/^[a-zA-Z][a-zA-Z ]*$/)]],
      email: [''],
      gender: [''],
      DOB: [''],
      // 2nd form
      foodPreference: [''],
      maritalStatus: [''],
      familySize: [''],
      profession: [''],
      incomeBracket: [''],
      profileInfo: ['']
    });
  }

  // function to get form controls
  get f() { return this.editProfileForm.controls; }
  checkError(controls: string[]) {
    let error = false;
    for (let i = 0; i < controls.length; i++) {
      if (this.editProfileForm.controls[`${controls[i]}`].errors) {
        error = true;
        break;
      } else {
        error = false;
      }
    }
    return error;
  }

  addEmailValidator() {
    this.f.email.setValidators([Validators.required, Validators.pattern(/^[A-Z0-9_-]+([\.-][A-Z0-9_-]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,4})+$/i)]);
    this.f.email.updateValueAndValidity();
  }

  addValidators(controls: string) {
    this.f[`${controls}`].setValidators([Validators.required]);
    this.f[`${controls}`].updateValueAndValidity();
  }

  removeValidators(controls: string) {
    this.f[`${controls}`].clearValidators();
    this.f[`${controls}`].updateValueAndValidity();
  }

  // function to submit edit profile form
  submitAndNext(val?: number) {
    this.submitted = true;
    if (this.checkError(['fullName', 'DOB', 'gender', 'email']) ) {
      console.log('InvalidEditProfileForm', this.editProfileForm.controls);
      return;
    }
    if (val) {
      this.counter++;
      return;
    } else {
      const formData = new FormData();
      const p = this.editProfileForm.value;
      for (let key in p) {
      if (p.hasOwnProperty(key)) {
        if (key === 'photoToSend') {
          formData.append('files', p[key]);
        } else if (key === 'DOB' && formData.get(key)) {
          formData.append(key, new Date(p[key]).toISOString());
        } else {
          formData.append(key, p[key]);
        }
      }
  }
      // formData.append('files', this.editProfileForm.controls.photoToSend.value);
      // formData.append('fullName', this.editProfileForm.controls.fullName.value);
      // formData.append('gender', this.editProfileForm.controls.gender.value);
      // formData.append('DOB', this.editProfileForm.controls.DOB.value ? new Date(this.editProfileForm.controls.DOB.value).toISOString() : '');
      if (!formData.get('files')) {
      formData.delete('files');
    }
      if (formData.get('files') == '10') {
      formData.delete('files');
      formData.append('files', '');
    }
      formData.delete('mobile');
      this.finalSubmit(formData, 1);
    }
  }

  submit() {
    this.submitted2 = true;
    if (this.checkError(['foodPreference', 'maritalStatus', 'familySize', 'profession', 'incomeBracket', 'profileInfo'])) {
      console.log('invalid2ndForm', this.f);
      return;
    }
    const p = this.editProfileForm.value;
    const formData = new FormData();
    for (let key in p) {
      if (p.hasOwnProperty(key)) {
        if (key === 'photoToSend') {
          formData.append('files', p[key]);
        } else if (key === 'DOB' && formData.get(key)) {
          formData.append(key, new Date(p[key]).toISOString());
        } else {
          formData.append(key, p[key]);
        }
      }
  }
    if (!formData.get('files')) {
    formData.delete('files');
  }
    if (formData.get('files') == '10') {
    formData.delete('files');
    formData.append('files', '');
  }
    formData.delete('mobile');
    this.finalSubmit(formData);
  }

  finalSubmit(data: FormData, val?) {
    this.commonServie.showSpinner();
    console.log('checkformDAta', data);
    this.profileService.editProfile(data).subscribe(response => {
      if (response.status === 200) {
        this.commonServie.hideSpinner();
        if (val) {
          this.commonServie.showSuccess('Profile Saved Sucessfully');
        } else {
          this.commonServie.showSuccess('Profile Updated Sucessfully');
        }
        if (val) {
          this.counter++;
        } else {
          this.sharedService.fetchUserHome();
          try {
            clevertap.profile.push({
              "Site": {
                "Identity": localStorage.getItem('user_idGyan'),  // String or number
                // "Gender": response.data.gender,
                // "DOB": response.data.DOB ? new Date(response.data.DOB) : '',
                // "Email": "jack@gmail.com", // Email address of the user
             // update some custom profile property fields
                // "Plan-type":"Gold",
                // "Account status": response.data.status,
                "Name": response.data.fullName
              }
             });
            clevertap.event.push('Profile edited', {
              "platform": localStorage.getItem('deviceType')
            });
          } catch (error) {
            console.log(error);
          }
          this.router.navigate(['page/profile'], {replaceUrl: true});
        }
      } else {
        this.commonServie.showError(response.message);
      }
    });
  }

  incomeChange(e) {
    const val = e.value;
    console.log(val);
    if (typeof(val) === 'number') {
      const newVal = {
        range: {
          min: this.incomeArr[val].min,
          max: this.incomeArr[val].max
        }
      }
      this.f.incomeBracket.setValue(JSON.stringify(newVal));
    } else {
      this.f.incomeBracket.setValue('');
    }
  }

  // function on image select
  onImageSelect(event) {
    if (event.target.files.length > 0) {
      this.editProfileForm.get('photoToSend').setValue(event.target.files[0]);
      let reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (_event) => {
        this.imageUrl = reader.result;
        this.imageSelected = true;
        this.removetext = true;
      };
    }
  }

  // function to remove photo
  removePhoto() {
    // value 10 means to remove photo and send blank image
    this.editProfileForm.controls.photoToSend.setValue(10);
    this.imageSelected = false;
    this.imageUrl = undefined;
    this.removetext = false;
  }

  changeDate() {
    console.log('checkDateSelect', this.f.DOB.value);
    const formatDate = new Date(this.f.DOB.value._d).toISOString();
    this.f.DOB.setValue(formatDate);
  }

}
