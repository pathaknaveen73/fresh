import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProfileService } from '../../serviceFile/profile.service';
import { CommonService } from 'src/app/serviceFile/common.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss']
})
export class ContactUsComponent implements OnInit {
  contactUsForm: FormGroup;
  submitted = false;
  adminProfileDetails;
  phone = localStorage.getItem('gPhone');
  name = localStorage.getItem('gName');

  constructor(private router: Router, private fb: FormBuilder, private profileService: ProfileService,
              private commonService: CommonService) { }

  ngOnInit(): void {
    this.setFormField();
    this.getAdminProfileDetails();
  }

  // function to set contact us form field
  setFormField() {
    this.contactUsForm = this.fb.group({
      mobile: [this.phone, [Validators.required, Validators.pattern(/^[1-9]\d{9}$/)]],
      fullName: [this.name, [Validators.required, Validators.pattern(/^[a-zA-Z][a-zA-Z ]*$/)]],
      // tslint:disable-next-line: max-line-length
      email: ['', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]],
      message: ['', [Validators.required]]
    });
  }

  // function to get form controls
  get f() { return this.contactUsForm.controls; }

  // function to submit contact us form
  submit() {
    this.submitted = true;
    if (!this.contactUsForm.valid) {
      console.log('invalidContactUsForm', this.contactUsForm.controls);
      return;
    }
    const payload = {
      message: this.contactUsForm.controls.message.value,
      fullName: this.contactUsForm.controls.fullName.value,
      email: this.contactUsForm.controls.email.value,
      phone: this.contactUsForm.controls.mobile.value
    };
    this.profileService.contactUs(payload).subscribe(response => {
      if (response.status === 200) {
        this.commonService.showSuccess(response.message);
        this.router.navigate(['page/profile']);
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

  // function to accept number only
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // function to get admin profile details
  getAdminProfileDetails() {
    this.profileService.getAdminProfileDetails().subscribe(response => {
      if (response.status === 200) {
        this.adminProfileDetails = response.data;
      }
    });
  }

}
