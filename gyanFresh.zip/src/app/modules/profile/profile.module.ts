import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileListComponent } from './component/profile-list/profile-list.component';
import { Routes, RouterModule } from '@angular/router';
import { ContactUsComponent } from './component/contact-us/contact-us.component';
import { EditProfileComponent } from './component/edit-profile/edit-profile.component';
import { ProfileService } from './serviceFile/profile.service';
import { DeactivateAccountComponent } from './component/deactivate-account/deactivate-account.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {LazyLoadImageModule} from 'ng-lazyload-image';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { DeliveryOptionDialogComponent } from './component/delivery-option-dialog/delivery-option-dialog.component';
import {MatRadioModule} from '@angular/material/radio';
import { MatDialogModule } from '@angular/material/dialog';
import { MomentUtcDateAdapter } from 'src/app/MomentUtcDateAdapter';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { DateAdapter } from '@angular/material/core';
import {MatSelectModule} from '@angular/material/select';
import { VacationComponent } from './component/vacation/vacation.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';

export const routes: Routes = [
  { path: '', component: ProfileListComponent, pathMatch: 'full' },
  { path: 'contact', component: ContactUsComponent },
  { path: 'edit', component: EditProfileComponent },
  { path: 'deactivateAccount', component: DeactivateAccountComponent},
  { path: 'schedule-vacation', component: VacationComponent }
];

@NgModule({
  declarations: [ProfileListComponent, ContactUsComponent, EditProfileComponent, DeactivateAccountComponent, DeliveryOptionDialogComponent, VacationComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    LazyLoadImageModule,
    MatDatepickerModule,
    MatRadioModule,
    MatDialogModule,
    MatMomentDateModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule
  ],
  exports: [ProfileListComponent, ContactUsComponent, EditProfileComponent, DeactivateAccountComponent, DeliveryOptionDialogComponent],
  providers: [ProfileService,
  { provide: DateAdapter, useClass: MomentUtcDateAdapter }],
  entryComponents: [DeliveryOptionDialogComponent]
})
export class ProfileModule { }
