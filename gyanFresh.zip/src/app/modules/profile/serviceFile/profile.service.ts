import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class ProfileService {

  constructor(private apiService: ApiService) { }

  // function to delete profile
  deleteProfile(payload) {
    const url = 'accountStatus';
    return this.apiService.putApi(url, payload);
  }

  // function to deactivate account
  deactivateProfile(payload) {
    const url = 'accountStatus';
    return this.apiService.putApi(url, payload);
  }

  // function to edit profile
  editProfile(payload) {
    const url = 'editProfile';
    return this.apiService.postApi(url, payload);
  }

  // function to contact us
  contactUs(payload) {
    const url = 'contactUs';
    return this.apiService.postApi(url, payload);
  }

  // function to get delivery options
  getDeliveryOption() {
    const url = 'deliveryOptions';
    return this.apiService.getApi(url);
  }

  // function to edit delivery options
  editDeliveryOptions(payload) {
    const url = 'deliveryOptions';
    return this.apiService.putApi(url, payload);
  }

  // function to get admin profile details
  getAdminProfileDetails() {
    const url = 'getAdminProfile';
    return this.apiService.getApi(url);
  }

  // get vacation
  getVacation() {
    const url = 'getVaccationDays';
    return this.apiService.getApi(url);
  }

  // set Vacation
  setVacation(obj) {
    const url = 'addVaccationDays';
    return this.apiService.postApi(url, obj);
  }

  // clear Vacation
  resetVacation(obj) {
    const url = 'clearVaccationDays';
    return this.apiService.postApi(url, obj);
  }
}
