import { Component, OnInit } from '@angular/core';
import { NotificationService } from '../../serviceFile/notification.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-notification-list',
  templateUrl: './notification-list.component.html',
  styleUrls: ['./notification-list.component.scss']
})
export class NotificationListComponent implements OnInit {
  messages;

  constructor(private noitifcationService: NotificationService, private commonService: CommonService,
              private sharedService: SharedService, private router: Router) { }

  ngOnInit(): void {
    this.getNotificaitons();
  }

  // function to get notification list
  getNotificaitons() {
    this.noitifcationService.getNotificationList().subscribe(response => {
      if (response.status === 200) {
        this.messages = response.data;
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

  // notification redirect
  redirectNotification(data, orderId, subsciptionId, messageId) {
    if (data === 'ORDER_PLACED_ONCE' || data === 'ORDER_STATUS_CHANGED' || data === 'ORDER_PLACED') {
      const payload = {
        read: 'READ'
      };
      this.noitifcationService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
          // this.router.navigate(['page/orders/viewOrder/' + orderId]);
          // this.router.navigate(['page/orders']);
          this.router.navigate(['page/orders/viewPastOrder/' + orderId]);
        }
      });
    } else if (data === 'SUBSCRIPTION_ADDED' || data === 'SUBSCRIPTION_UPDATED') {
      const payload = {
        read: 'READ'
      };
      this.noitifcationService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
          // this.router.navigate(['page/subscription/list/' + subsciptionId]);
          this.getSubscriptionByid(subsciptionId);
        }
      });
    } else if (data === 'REFERAL_BONUS') {
      const payload = {
        read: 'READ'
      };
      this.noitifcationService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
          this.router.navigate(['page/wallet']);
        }
      });
    } else if (data === 'MANUAL_NOTIFICATION') {
      const payload = {
        read: 'READ'
      };
      this.noitifcationService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
          this.router.navigate(['page/notifications']);
        }
      });
    } else if (data === 'OFFER_ADDED') {
      const payload = {
        read: 'READ'
      };
      this.noitifcationService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
          this.router.navigate(['page/offers']);
        }
      });
    } else {
      const payload = {
        read: 'READ'
      };
      this.noitifcationService.sendReadReceipt(payload, messageId).subscribe(response => {
        if (response.status === 200) {
          this.sharedService.getNotifications();
        }
      });
    }
  }

  getSubscriptionByid(_id) {
    const payload = {
      id: _id
    };
    this.commonService.showSpinner();
    this.noitifcationService.getSubscriptionDetail(payload).subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.hideSpinner();
        console.log('subsDetail', res);
        const item = res.data;
        item.productInfo = JSON.parse(item.productInfo);
        const subsType = item.subscriptionDaysType === 'ONCE' ? 1 : 2;
          if (subsType === 1) {
            this.router.navigate(['/page/product/list/' + item._id + '/once'],
          { queryParams: { data: JSON.stringify(item), type: subsType, fromType: 'TOM' } });
          } else {
            this.router.navigate(['/page/product/list/' + item._id + '/editSubs'],
          { queryParams: { data: JSON.stringify(item), type: subsType, fromType: 'TOM' } });
          }
      } else {
        this.commonService.showError(res.message);
        this.commonService.hideSpinner();
      }
    }, error => {
      this.commonService.hideSpinner();
      this.commonService.showError(error);
    });
  }

}
