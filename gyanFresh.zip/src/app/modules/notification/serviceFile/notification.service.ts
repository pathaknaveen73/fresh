import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class NotificationService {

  constructor(private apiService: ApiService) { }

  // function to get notification list
  getNotificationList() {
    const url = 'getNotificationList';
    return this.apiService.getApi(url);
  }

  // function to send read notification receipt
  sendReadReceipt(payload, id) {
    const url = 'readNotification/' + id;
    return this.apiService.putApi(url, payload);
  }

  // function to get subscription detail by ID
  getSubscriptionDetail(payload) {
    const url = 'subscriptionDetail/' + payload.id;
    return this.apiService.getApi(url);
  }
}
