import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationListComponent } from './component/notification-list/notification-list.component';
import { Routes, RouterModule } from '@angular/router';
import { NotificationService } from './serviceFile/notification.service';
import { DateAgoPipe } from 'src/app/shared/pipes/date-ago.pipe';

export const routes: Routes = [
  { path: '', component: NotificationListComponent, pathMatch: 'full' }
];

@NgModule({
  declarations: [NotificationListComponent, DateAgoPipe],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [NotificationListComponent],
  providers: [NotificationService]
})
export class NotificationModule { }
