import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-skeleton-product',
  templateUrl: './skeleton-product.component.html',
  styleUrls: ['./skeleton-product.component.scss']
})
export class SkeletonProductComponent implements OnInit {
  @Input() count: number;
  skeletonProducts = [];
  constructor() { }

  ngOnInit(): void {
    for (let i = 1; i <= this.count; i++) {
      this.skeletonProducts.push(i);
    }
  }

}
