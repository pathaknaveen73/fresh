import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { SkeletonProductComponent } from './skeleton-product/skeleton-product.component';



@NgModule({
  declarations: [SkeletonProductComponent],
  imports: [
    CommonModule,
    NgxSkeletonLoaderModule
  ],
  exports: [
    SkeletonProductComponent
  ]
})
export class SkeletonModule { }
