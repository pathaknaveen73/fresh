import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { CommonService } from 'src/app/serviceFile/common.service';
import { StarService } from '../../serviceFile/star.service';

@Component({
  selector: 'app-progress-tracker',
  templateUrl: './progress-tracker.component.html',
  styleUrls: ['./progress-tracker.component.scss']
})
export class ProgressTrackerComponent implements OnInit {
  streakList = [];
  currentStreak;
  streakDate;
  isStreakStartedToday = false;

  constructor(private starService: StarService, private commonService: CommonService) { }

  ngOnInit(): void {
    this.getStreakList();
  }

  getStreakList() {
    this.starService.getGyanstarProgressList().pipe(take(1)).subscribe(res => {
      if (res && res.status === 200) {
        console.log('streakList', res.data);
        this.streakList = res.data;
        this.currentStreak = res.response.totalStreak;
        this.streakDate = res.response.firstStreakDate;
        this.isStreakStartedToday = this.getFormattedDate(new Date()) === this.getFormattedDate(this.streakDate);
      }
    });
  }

  getFormattedDate(date) {
    if (!date) {
      return '-';
    }
    const newDate = new Date(date).toISOString().split('T')[0].split('-');
    const formattedDate = `${newDate[0]}${newDate[1]}${newDate[2]}`;
    return formattedDate;
  }

  claimBonus(data) {
    const obj = {
      currentStreakId: data._id,
      previousStreakId: data.previousStreakId,
      stars: data.point
    };
    this.starService.claimStar(obj).pipe(take(1)).subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.showSuccess(res.message);
        this.getStreakList();
      }
    });

  }

}
