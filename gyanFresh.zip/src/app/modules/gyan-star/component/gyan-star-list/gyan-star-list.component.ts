import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { of, Subscription } from 'rxjs';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { StarService } from '../../serviceFile/star.service';
import { MatDialog } from '@angular/material/dialog';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';
import { groupBy, mergeMap, reduce, map, toArray } from 'rxjs/operators';
declare let $: any;
declare let clevertap: any;

@Component({
  selector: 'app-gyan-star-list',
  templateUrl: './gyan-star-list.component.html',
  styleUrls: ['./gyan-star-list.component.scss']
})
export class GyanStarListComponent implements OnInit, OnDestroy {
  gyanStarListArr;
  gyanStarWallet;
  gyanStarTransactionListArr = [];
  limit = 50;
  offset = 0;
  starWallet$: Subscription;
  gyanStarCoversionValue$: Subscription;
  gyanValue = { gyan: 0, rupee: 0 };

  constructor(private router: Router, private starService: StarService, private sharedService: SharedService,
              public dialog: MatDialog) { }

  ngOnInit(): void {
    /* filter datepicker start here */
  // $('#dp').datepicker({ isRTL: true });
  // $('#filteropen').on('click', function () {
  //   $('#dp').focus();
  // });
 /* filter datepicker end here */
    this.starWallet$ = this.sharedService.walletData$.subscribe(res => {
      if (res) {
        this.gyanStarWallet = res.walletStar;
      }
    });
    // this.gyanStarList();
    this.gyanStarConversionValue();
    try {
      clevertap.event.push('Gyan Star checked', {
        "platform": localStorage.getItem('deviceType')
      });
    } catch (error) {
      console.log(error);
    }
  }

  ngOnDestroy() {
    try {
      this.starWallet$.unsubscribe();
      this.gyanStarCoversionValue$.unsubscribe();
    } catch (error) {
      console.log(error);
    }
  }

  gyanStarConversionValue() {
    this.gyanStarCoversionValue$ = this.starService.getGyanstarConversionValue().subscribe(res => {
      if (res && res.status === 200) {
        this.gyanValue.gyan = res.data[0].gyanStar;
        this.gyanValue.rupee = res.data[0].rupees;
      }
    });
  }

  // function to navigate to redeem gyan star
  openRedeemStar() {
    this.router.navigate(['page/gyanStar/redeemStar']);
  }

  // function to get gyan star list
  gyanStarList() {
    this.starService.getGyanStarList().subscribe(response => {
      if (response.status === 200) {
        this.gyanStarListArr = response.data.gyanstarList;
        // this.gyanStarWallet = response.data.myGyanstar.walletStar;
        console.log('gyanStarWallet', this.gyanStarWallet);
      }
    });
  }

  // function to get gyan star transaction history list
  gyanStarTransactionList() {
    try {
      clevertap.event.push('Gyan Star history checked', {
        "platform": localStorage.getItem('deviceType')
      });
    } catch (error) {
      console.log(error);
    }
    let payload = {
      limit: this.limit,
      offset: this.offset
    };
    this.starService.getGyanTransactionList(payload).subscribe(response => {
      if (response.status === 200) {
        // this.gyanStarTransactionListArr = response.data;
        // console.log('gyanStarWalletHistory', this.gyanStarTransactionListArr);
        this.groupByDate(response.data);
      }
    });
  }

  groupByDate(data) {
    of(...data).pipe(
      groupBy((p: any) => p.createdAt.split('T')[0]),
      mergeMap(group$ =>
        group$.pipe(reduce((acc, cur) => [...acc, cur], [`${group$.key}`]))
      ),
      map(arr => ({ date: new Date(arr[0]).toISOString(), games: arr.slice(1) })),
      toArray()
    ).subscribe(p => {
      // this.gyanStarTransactionListArr.push(p);
      this.gyanStarTransactionListArr = p.map(element => element);
      console.log(this.gyanStarTransactionListArr);
    });
  }

  openDialog() {
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '1000px',
      height: 'auto',
      disableClose: false,
      data: {type: 'gyanStar'},
      autoFocus: false
    });
  }

}
