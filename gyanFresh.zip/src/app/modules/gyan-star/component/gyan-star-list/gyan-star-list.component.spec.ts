import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GyanStarListComponent } from './gyan-star-list.component';

describe('GyanStarListComponent', () => {
  let component: GyanStarListComponent;
  let fixture: ComponentFixture<GyanStarListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GyanStarListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GyanStarListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
