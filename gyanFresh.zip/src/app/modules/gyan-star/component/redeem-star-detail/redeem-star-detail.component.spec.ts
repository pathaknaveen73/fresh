import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RedeemStarDetailComponent } from './redeem-star-detail.component';

describe('RedeemStarDetailComponent', () => {
  let component: RedeemStarDetailComponent;
  let fixture: ComponentFixture<RedeemStarDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RedeemStarDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RedeemStarDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
