import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { StarService } from '../../serviceFile/star.service';

declare let $: any;

@Component({
  selector: 'app-redeem-star-detail',
  templateUrl: './redeem-star-detail.component.html',
  styleUrls: ['./redeem-star-detail.component.scss']
})
export class RedeemStarDetailComponent implements OnInit, OnDestroy {
  id;
  productDetailObj;
  similarProductArr;
  currentTime;
  croneTime;
  dateFrom: any;

  constructor(private route: ActivatedRoute, private starService: StarService, private router: Router,
              private sharedService: SharedService, private commonService: CommonService) { }

  ngOnInit(): void {
    // this.sharedService.setSearchBoxParam('gyanProduct');
    this.id = this.route.snapshot.paramMap.get('id');
    this.productDetail(this.id);
  }

  // function to get product detail
  productDetail(id) {
    this.starService.getProductDetail(id).subscribe(response => {
      if (response.status === 200) {
        this.productDetailObj = response.data;
        console.log('productDetails', this.productDetailObj);
      }
    });
  }

  // function to add star product in cart
  addToCart(item) {
    // console.log('item', item);
    const payload1 = {
      qty: '1',
      productId: this.id,
      productType: 'REGULAR',
      offerId: ''
    };
    // this.starService.addToCart(payload).subscribe(response => {
    //   if (response.status === 200) {
    //     // this.sharedService.getCartItems();
    //     this.commonService.showSuccess('Item added to basket');
    //     this.router.navigate(['page/cart']);
    //     // this.addedToCartFlag = true;
    //   }
    // });
    const userPrimaryLocation = this.sharedService.getPrimaryLocation();
    const gfs = this.sharedService.getGfdId();
    this.currentTime = { HH: new Date().getHours(), MM: new Date().getMinutes() };
    this.croneTime = JSON.parse(localStorage.getItem('crone'));
    this.croneTime.hour += 5;
    this.croneTime.minute += 30;
    this.dateFrom = new Date();
    this.dateFrom.setDate(this.dateFrom.getDate() + 1);
    this.croneLogic();
    const payload = {
      allproduct: [{
        productId: item._id,
        qty: 1,
        productDetails: item._id,
        productPrice: item.price,
        gyanStar: item.gyanStar.star,
        productType: 'GYANSTAR',
        offer: {
          offerTypeValue: {
            fixValue: '',
            percentageValue: '',
            otherProductName: '',
            otherProductImage: '',
            otherProductThumb: '',
            otherProductDesc: '',
            rechargeBonusType: '',
            rechargeBonusTypeValue: '',
            rechargeMinimumValue: '',
            rechargeMaximumBonusAmt: ''
          }
        }
      }],
      allProductCount: 1,
      deliveryDate: this.getRequiredDateFormat(this.dateFrom),
      startTime: '11:00 AM',
      endTime: '11:30 AM',
      deliveryType: 'DELIVERY',
      deliveryOption: 'Hand to Hand',
      gfsId: gfs,
      deliveryCharges: 0,
      discount: '',
      subtotal: item.gyanStar.star,
      totalGyanStars: item.gyanStar.star,
      flatNo: userPrimaryLocation && userPrimaryLocation.flatNo ? userPrimaryLocation.flatNo : '',
      landMark: userPrimaryLocation && userPrimaryLocation.landMark ? userPrimaryLocation.landMark : '',
      area: userPrimaryLocation.area._id,
      city: userPrimaryLocation.city._id,
      zipcode: userPrimaryLocation && userPrimaryLocation.zipcode ? userPrimaryLocation.zipcode : '',
      coordinates: userPrimaryLocation.coordinates
    };
    console.log('request>>>', payload);
    // return;
    this.starService.addToCart(payload).subscribe(response => {
      if (response.status === 200) {
        // this.sharedService.getCartItems();
        // this.commonService.showSuccess('Item added to basket');
        // this.router.navigate(['page/cart']);
        // this.addedToCartFlag = true;
        $('#buyOnceModal').modal('show');
        this.sharedService.getCartData();
        this.sharedService.fetchBalance();
      } else {
        this.commonService.showError(response.message);
      }
    }, error => {
      this.commonService.showError(error);
    });
  }

  // function on destroy of the component
  ngOnDestroy(): void {
    // console.log('REDEEM STAR DESTROYED');
    // this.sharedService.setSearchBoxParam('regularProduct');
  }

  croneLogic() {
    // debugger
    if (this.croneTime.minute >= 60) {
      this.croneTime.hour += 1;
      this.croneTime.minute = this.croneTime.minute - 60;
      if (this.currentTime.HH >= this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.dateFrom.setDate(this.dateFrom.getDate() + 1);
      }
    } else {
      if (this.currentTime.HH > this.croneTime.hour) {
        this.dateFrom.setDate(this.dateFrom.getDate() + 1);
      } else if (this.currentTime.HH === this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.dateFrom.setDate(this.dateFrom.getDate() + 1);
      }
    }
    // if (this.editFlag && this.dayType === 'TOM') {
    //   // do something
    // } else if (this.editFlag && this.dayType === 'REST') {
    //   // do something
    // } else {

    // }
    // let total_days = (Math.round((this.dateFrom.getTime() - new Date().getTime()) / (60 * 60 * 1000 * 24)));
  }

  getRequiredDateFormat(date: Date) {
    let dd: any = date.getDate();
    let mm: any = date.getMonth() + 1;
    const yyyy = date.getFullYear();
    if (dd < 10) {
      dd = '0' + dd;
    }
    if (mm < 10) {
      mm = '0' + mm;
    }
    return `${yyyy}-${mm}-${dd}T00:00:00.000Z`;
  }

}
