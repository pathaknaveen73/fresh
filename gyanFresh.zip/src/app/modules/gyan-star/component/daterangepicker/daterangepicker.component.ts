import { Component, OnInit, Inject, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-daterangepicker',
  templateUrl: './daterangepicker.component.html',
  styleUrls: ['./daterangepicker.component.scss']
})
export class DaterangepickerComponent implements OnInit {
  @Input() max: Date | null;
  tomorrow = new Date();
  dateFrom;
  dateTo;

  constructor(public dialogRef: MatDialogRef<DaterangepickerComponent>,
              @Inject(MAT_DIALOG_DATA) public data) {
      this.dateTo = new Date();
    }

  ngOnInit(): void {
    if (this.data) {
      this.dateFrom = this.data.startDate;
      this.dateTo = this.data.endDate;
      console.log(this.data);
    }
  }

  onSubmit() {
    const date = {
      begin: this.dateFrom,
      end: this.dateTo
    };
    this.dialogRef.close(date);
  }
  closeDialog() {
    this.dialogRef.close();
  }

}
