import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RedeemStarComponent } from './redeem-star.component';

describe('RedeemStarComponent', () => {
  let component: RedeemStarComponent;
  let fixture: ComponentFixture<RedeemStarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RedeemStarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RedeemStarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
