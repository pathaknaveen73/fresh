import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GyanStarListComponent } from './component/gyan-star-list/gyan-star-list.component';
import { RedeemStarComponent } from './component/redeem-star/redeem-star.component';
import { Routes, RouterModule } from '@angular/router';
import { StarService } from './serviceFile/star.service';
import {LazyLoadImageModule} from 'ng-lazyload-image';
import { RedeemStarDetailComponent } from './component/redeem-star-detail/redeem-star-detail.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { TransactionListComponent } from './component/transaction-list/transaction-list.component';
import { DaterangepickerComponent } from './component/daterangepicker/daterangepicker.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MatMomentDateModule } from '@angular/material-moment-adapter';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { FormsModule } from '@angular/forms';
import { ProgressTrackerComponent } from './component/progress-tracker/progress-tracker.component';

export const routes: Routes = [
  { path: '', component: GyanStarListComponent, pathMatch: 'full' },
  { path: 'redeemStar', component: RedeemStarComponent },
  { path: 'redeemStar/:id', component: RedeemStarDetailComponent },
  { path: 'transactions', component: TransactionListComponent },
  { path: 'tracker', component: ProgressTrackerComponent }
];

@NgModule({
  declarations: [GyanStarListComponent, RedeemStarComponent, RedeemStarDetailComponent, TransactionListComponent, DaterangepickerComponent, ProgressTrackerComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    LazyLoadImageModule,
    CarouselModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatFormFieldModule,
    MatInputModule,
    InfiniteScrollModule,
    FormsModule
  ],
  exports: [GyanStarListComponent, RedeemStarComponent, RedeemStarDetailComponent],
  providers: [StarService, {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}],
  entryComponents: [DaterangepickerComponent]
})
export class GyanStarModule { }
