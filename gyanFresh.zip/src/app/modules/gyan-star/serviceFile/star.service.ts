import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class StarService {

  constructor(private apiService: ApiService) { }

  // function to get gyan star list
  getGyanStarList() {
    const url = 'gyanstarList';
    return this.apiService.getApi(url);
  }

  // function to get product categories
  getProductCat(payload) {
    const url = 'categories?offset=' + payload.offset + '&limit=' + payload.limit;
    return this.apiService.getApi(url);
  }

  // function to get gyan star product variant list
  getGyanStarProduct(payload) {
    const url = 'gyanstarProducts/' + payload.productId;
    return this.apiService.getApi(url);
  }

  // function to add gyan product to cart
  addToCart(payload) {
    const url = 'buyOnceGyanStar';
    return this.apiService.postApi(url, payload);
  }

  // function to get gya star product details
  getProductDetail(payload) {
    const url = 'productDetail/' + payload;
    return this.apiService.getApi(url);
  }

  // function to get gyan transaction list
  getGyanTransactionList(payload) {
    const url = 'getGyanStarTransactions?limit=' + payload.limit + '&offset=' + payload.offset;
    return this.apiService.getApi(url);
  }

  // function to get new gyan star transaction list
  getTransactionList(payload) {
    const url = 'getGyanStarTransaction';
    return this.apiService.postApiAdmin(url, payload);
  }

  // function to get gyanStarConverstionValue
  getGyanstarConversionValue() {
    const url = 'getGyanStarConversionValue';
    return this.apiService.getApi(url);
  }

  // function to get gyan progress
  getGyanstarProgressList() {
    const url = 'getUserStreakList';
    return this.apiService.getApi(url);
  }

  // function to claim streak star
  claimStar(payload) {
    const url = 'claimStreakBonus';
    return this.apiService.postApi(url, payload);
  }
}
