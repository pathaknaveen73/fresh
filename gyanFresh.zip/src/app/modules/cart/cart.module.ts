import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { CartListComponent } from './component/cart-list/cart-list.component';
import { CartService } from './serviceFile/cart.service';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import { CartSummaryComponent } from './component/cart-summary/cart-summary.component';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ScheduleCalendarComponent } from './component/schedule-calendar/schedule-calendar.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MatMomentDateModule } from '@angular/material-moment-adapter';

export const routes: Routes = [
  { path: '', component: CartListComponent, pathMatch: 'full' },
  { path: 'scheduleCalendar', component: ScheduleCalendarComponent },
  { path: 'summary', component: CartSummaryComponent }
];

@NgModule({
  declarations: [CartListComponent, CartSummaryComponent, ScheduleCalendarComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    LazyLoadImageModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatMomentDateModule
  ],
  exports: [CartListComponent, CartSummaryComponent, ScheduleCalendarComponent],
  providers: [CartService, {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}]
})
export class CartModule { }
