import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class CartService {

  constructor(private apiService: ApiService) { }

  // funtion to get cart items
  getCartItems() {
    const url = 'cartItems';
    return this.apiService.getApi(url);
  }

  // function to delete cart items
  deleteCartItem(payload) {
    const url = 'cartItems/' + payload.id;
    return this.apiService.deleteApi(url);
  }

  // function to get nearest GFS
  getNearbyGFS() {
    const url = 'myNearbyGfs';
    return this.apiService.getApi(url);
  }

  // function to get all addresses
  getAllAddress() {
    const url = 'allAddress';
    return this.apiService.getApi(url);
  }

  // function to get time slots
  getTimeSlot() {
    const url = 'timeSlots';
    return this.apiService.getApi(url);
  }

  // function to edit cart quantity
  editCartQuantity(id, payload) {
    const url = 'cartItems/' + id;
    return this.apiService.putApi(url, payload);
  }

  // function to get delivery options
  getDeliveryOption() {
    const url = 'deliveryOptions';
    return this.apiService.getApi(url);
  }

  // function on buy once order place
  buyOnce(payload) {
    const url = 'buyOnce';
    return this.apiService.postApi(url, payload);
  }

  // function to get wallet balance detail
  getAutoRechargeDetail() {
    const url = 'getAutoRechargeDetail';
    return this.apiService. getApi(url);
  }
}
