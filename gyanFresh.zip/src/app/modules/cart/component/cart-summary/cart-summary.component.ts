import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from '../../serviceFile/cart.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { app_strings } from 'src/app/shared/_constant/app_strings';
declare let $: any;
declare var clevertap: any;
@Component({
  selector: 'app-cart-summary',
  templateUrl: './cart-summary.component.html',
  styleUrls: ['./cart-summary.component.scss']
})
export class CartSummaryComponent implements OnInit {
  deliveryTypeArr = [{ label: 'Delivery', value: 'DELIVERY' }]; // { label: 'Self Pickup', value: 'PICKUP' }
  selectedDeliveryType;
  cartSummaryForm: FormGroup;
  submitted = false;
  allLocation;
  userPrimaryLocation;
  GFSlistArr;
  deliveryFlag = true;
  selectedGFS;
  calendarData;
  cartArr;
  totalItem = 0;
  totalAmount = 0;
  totalDiscount = 0;
  confirmOrderbtFlag = true;
  allProduct = [];
  totalGyanStar = 0;
  deliveryOption;
  finalOrderPlaceFlag = false;
  primaryGFSid;
  walletBalanceDetails;

  constructor(private router: Router, private cartService: CartService, private commonService: CommonService,
              private fb: FormBuilder, private sharedService: SharedService, public dialog: MatDialog) { }

  ngOnInit(): void {
    if (!history.state.data) {
      this.router.navigate(['page/cart']);
    }
    this.calendarData = history.state.data;
    this.getCartItems();
    this.getAllAddress();
    this.getDeliveryOption();
    // this.getWalletBalanceDetail();
    this.setFormField();
    this.nearbyGFS();
    this.selectedDeliveryType = this.deliveryTypeArr[0].value;
  }

  // to get user all address and watch for user primary address
  getAllAddress() {
    this.cartService.getAllAddress().subscribe(response => {
      if (response.status === 200) {
        this.allLocation = response.data.location;
        this.allLocation.forEach(element => {
          if (element.default === 'PRIMARY') {
            this.userPrimaryLocation = element;
          }
        });
      }
      console.log('userPrimaryLocation', this.userPrimaryLocation);
    });
  }

  // function to get cart items
  getCartItems() {
    this.cartService.getCartItems().subscribe(response => {
      if (response.status === 200) {
        this.totalItem = 0;
        this.totalAmount = 0;
        this.totalGyanStar = 0;
        this.cartArr = response.data.cartItems;
        this.walletBalanceDetails = response.data.walletAmount;
        this.cartArr.forEach((element, i) => {
          this.totalItem = element.qty + this.totalItem;
          if (element.productType !== 'GYANSTAR') {
            this.totalAmount = (element.productId.price * element.qty) + this.totalAmount;
            if (element.productType === 'OFFER') {
              if (element.offerId.offerType === 'FIX') {
                // this.totalAmount = ((element.productId.price - element.offerId.offerTypeValue.fixValue) * element.qty) + this.totalAmount;
                this.totalDiscount += Number(element.offerId.offerTypeValue.fixValue) * element.qty;
                console.log('discountFix', this.totalDiscount);
              } else if (element.offerId.offerType === 'PERCENTAGE') {
                // this.totalAmount = ((element.productId.price - ((element.productId.price * element.offerId.offerTypeValue.percentageValue) / 100)) * element.qty) + this.totalAmount;
                this.totalDiscount += Number(((element.productId.price * element.offerId.offerTypeValue.percentageValue) / 100)) * element.qty;
                console.log('discountPercent', (element.productId.price * element.offerId.offerTypeValue.percentageValue) / 100);
              }
            }
          }
          // if (element.productType === 'OFFER' && element.offerId.offerType === 'PERCENTAGE') {
          //   this.totalDiscount = (element.qty * element.productId.price) * element.offerId.offerTypeValue.percentageValue / 100;
          // }
          if (element.productType === 'GYANSTAR') {
            this.totalGyanStar = (element.qty * element.productId.gyanStar.star) + this.totalGyanStar;
          }
          // this.setPerItemQty[i] = element.qty;
        });
        console.log('cartArr', this.cartArr);
        // this.addQtyForm(this.cartArr.length);
      }
    });
  }

  // function to get nearby GFS
  nearbyGFS() {
    this.cartService.getNearbyGFS().subscribe(response => {
      if (response.status === 200) {
        this.GFSlistArr = response.data.nearbyGfs;
        this.selectedGFS = this.GFSlistArr[0]._id;
        this.primaryGFSid = response.data.primaryGfs.gfsId._id;
        this.cartSummaryForm.controls.gfs.setValue(this.primaryGFSid);
        console.log('GFSlistArr', this.GFSlistArr);
      }
    });
  }

  // function on selectDeliveryType
  onSelectDeliveryType(data) {
    // console.log('kuldeep111', data);
    if (data === 'PICKUP') {
      this.nearbyGFS();
      this.deliveryFlag = false;
    } else {
      this.deliveryFlag = true;
      this.cartSummaryForm.controls.gfs.setValue(this.primaryGFSid);
    }
  }

  // function to set cart summary form field
  setFormField() {
    this.cartSummaryForm = this.fb.group({
      deliveryType: ['', [Validators.required]],
      gfs: ['']
    });
  }

  // function on submit cart summary form
  submit() {
    if (!this.userPrimaryLocation.zipcode) {
      this.openDialog();
      return;
    }
    if (this.walletBalanceDetails.walletAmount < (this.totalAmount - this.totalDiscount)) {
      $('#myModal1').modal('show');
      return;
    }
    this.finalOrderPlaceFlag = true;
    this.submitted = true;
    this.confirmOrderbtFlag = false;
    console.log('cartSummaryForm', this.cartSummaryForm.controls);
    this.cartArr.forEach(element => {
      if (element.productType === 'REGULAR') {
        clevertap.event.push(app_strings.CT_ORDER_SUCCESS, {
          'Product Name': element.productId.itemName,
          'Product Price': element.productId.price,
          'Category Name': element.productId.categoryId.categoryName,
          'Product Type': element.productType,
          'Product Quantity': element.qty,
          "platform": localStorage.getItem('deviceType')
        });
        this.allProduct.push({
          productId: element.productId._id,
          qty: element.qty,
          productDetails: JSON.stringify(element.productId),
          productPrice: element.productId.price,
          gyanStar: 0,
          productType: 'REGULAR',
          offer: {
            offerId: null,
            offerType: 'NONE',
            offerTypeValue: {
              fixValue: '',
              percentageValue : '',
              otherProductName : '',
              otherProductImage : '',
              otherProductThumb : '',
              otherProductDesc : '',
              rechargeBonusType: '',
              rechargeBonusTypeValue: '',
              rechargeMinimumValue : '',
              rechargeMaximumBonusAmt: ''
            }
          }
        });
      }
      if (element.productType === 'OFFER') {
        clevertap.event.push(app_strings.CT_ORDER_SUCCESS, {
          'Product Name': element.productId.itemName,
          'Product Price': element.productId.price,
          'Category Name': element.productId.categoryId.categoryName,
          'Product Type': element.productType,
          'Product Quantity': element.qty,
          "platform": localStorage.getItem('deviceType')
        });
        this.allProduct.push({
          productId: element.productId._id,
          qty: element.qty,
          productDetails: JSON.stringify(element.productId),
          productPrice: element.productId.price,
          gyanStar: 0,
          productType: 'OFFER',
          offer: {
            offerId: element.offerId._id,
            offerType: element.offerId.offerType,
            offerTypeValue: element.offerId.offerTypeValue
          }
        });
      }
      if (element.productType === 'GYANSTAR') {
        clevertap.event.push(app_strings.CT_ORDER_SUCCESS, {
          'Product Name': element.productId.itemName,
          'Product Price': element.productId.gyanStar.star,
          'Category Name': element.productId.categoryId.categoryName,
          'Product Type': 'GYANSTAR',
          'Product Quantity': element.qty,
          "platform": localStorage.getItem('deviceType')
        });
        this.allProduct.push({
          productId: element.productId._id,
          qty: element.qty,
          productDetails: JSON.stringify(element.productId),
          productPrice: element.productId.price,
          gyanStar: element.productId.gyanStar.star,
          productType: 'GYANSTAR',
          offer: {
            offerId: null,
            offerType: 'NONE',
            offerTypeValue: {
              fixValue: '',
              percentageValue : '',
              otherProductName : '',
              otherProductImage : '',
              otherProductThumb : '',
              otherProductDesc : '',
              rechargeBonusType: '',
              rechargeBonusTypeValue: '',
              rechargeMinimumValue : '',
              rechargeMaximumBonusAmt: ''
            }
          }
        });
      }
      if (element.productType === 'FREE') {
        clevertap.event.push(app_strings.CT_ORDER_SUCCESS, {
          'Product Name': element.productId.itemName,
          'Product Price': element.productId.price,
          'Category Name': element.productId.categoryId.categoryName,
          'Product Type': 'FREE',
          'Product Quantity': element.qty,
          "platform": localStorage.getItem('deviceType')
        });
        this.allProduct.push({
          productId: element.productId._id,
          qty: element.qty,
          productDetails: JSON.stringify(element.productId),
          productPrice: element.productId.price,
          gyanStar: 0,
          productType: 'FREE',
          offer: {
            offerId: null,
            offerType: 'NONE',
            offerTypeValue: {
              fixValue: '',
              percentageValue : '',
              otherProductName : '',
              otherProductImage : '',
              otherProductThumb : '',
              otherProductDesc : '',
              rechargeBonusType: '',
              rechargeBonusTypeValue: '',
              rechargeMinimumValue : '',
              rechargeMaximumBonusAmt: ''
            }
          }
        });
      }
    });
    // console.log('allProduct', this.allProduct);
    const payload = {
      allproduct: this.allProduct,
      allProductCount: this.totalItem,
      deliveryDate: this.calendarData.deliveryDate,
      startTime: this.calendarData.startTime,
      endTime: this.calendarData.endTime,
      deliveryType: this.cartSummaryForm.controls.deliveryType.value,
      deliveryOption: this.deliveryOption,
      gfsId: this.cartSummaryForm.controls.gfs.value,
      tax: [],
      deliveryCharges: 0,
      offerId: '',
      discount: this.totalDiscount,
      subtotal: this.totalAmount,
      GrandTotal: this.totalAmount - this.totalDiscount,
      totalGyanStars: this.totalGyanStar,
      flatNo: this.userPrimaryLocation.flatNo,
      landMark: this.userPrimaryLocation.landMark ? this.userPrimaryLocation.landMark : '',
      area: this.userPrimaryLocation.area._id,
      city: this.userPrimaryLocation.city._id,
      zipcode: this.userPrimaryLocation.zipcode,
      coordinates: this.userPrimaryLocation.coordinates
    };
    console.log('summaryPayload', payload);
    // return;
    this.cartService.buyOnce(payload).subscribe(response => {
      if (response.status === 200) {
        $('#myModal').modal('show');
        // clevertap.event.push(app_strings.CT_ORDER_SUCCESS, {
        //   ''
        // });
        // this.sharedService.getCartItems();
        // this.router.navigate(['page/cart'], {replaceUrl: true});
      } else {
        this.commonService.showError(response.message);
        this.finalOrderPlaceFlag = false;
      }
    });
  }

  // function to change address
  changeAddress() {
    this.router.navigate(['page/address'], {state: {data: 'summary'}});
  }

  // function to get delivery option
  getDeliveryOption() {
    this.cartService.getDeliveryOption().subscribe(response => {
      if (response.status === 200) {
        const option = response.data;
        option.options.forEach(element => {
          if (element.id === option.deliveryOption.deliveryOption) {
            this.deliveryOption = element.value;
          }
        });
      }
    });
  }

  // function to navigate back to cart once order placed
  orderPlaced() {
    $('#myModal').modal('hide');
    this.router.navigate(['page/orders'], {replaceUrl: true});
  }

  // function to open products section
  openProducts() {
    this.router.navigate(['page/product'], {replaceUrl: true});
  }

  // function to open golabl dialog
  openDialog() {
    // console.log('tableData', selectedMerchant);
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '400px',
      height: 'auto',
      disableClose: true,
      data: {type: 'noZipcode'}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result !== undefined) {
        this.router.navigate(['page/address'], {replaceUrl: true});
        // console.log('result', result);
        // this.activateAreaForm = false;
        // this.activateCustomerForm = true;
      }
    });
  }

  // function to get wallet balance details
  // getWalletBalanceDetail() {
  //   this.cartService.getAutoRechargeDetail().subscribe(response => {
  //     if (response.status === 200) {
  //       this.walletBalanceDetails = response.data.walletAmount;
  //       console.log('walletBalanceDetails', this.walletBalanceDetails);
  //     }
  //   });
  // }

  // function to navigate to stripe checkout if wallet bal is below order total amount
  navigateToAddMoney() {
    $('#myModal1').modal('hide');
    const payload = {
      amount: (this.totalAmount - this.totalDiscount) - this.walletBalanceDetails.walletAmount,
      currency: 'inr'
    };
    this.router.navigate(['page/wallet/checkout'], {state: {data: payload}});
  }

  // function to close less wallet balance dialog
  closeLessBalModal() {
    $('#myModal1').modal('hide');
  }

}
