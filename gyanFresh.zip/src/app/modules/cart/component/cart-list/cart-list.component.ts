import { Component, OnInit } from '@angular/core';
import { CartService } from '../../serviceFile/cart.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { SharedService } from 'src/app/serviceFile/shared.service';

@Component({
  selector: 'app-cart-list',
  templateUrl: './cart-list.component.html',
  styleUrls: ['./cart-list.component.scss']
})
export class CartListComponent implements OnInit {
  cartArr;
  totalItem = 0;
  totalAmount = 0;
  setPerItemQty = [];

  constructor(private cartService: CartService, private commonService: CommonService, private router: Router,
              private sharedService: SharedService) { }

  ngOnInit(): void {
    this.getCartItems();
  }

  getCartItems() {
    this.cartService.getCartItems().subscribe(response => {
      if (response.status === 200) {
        this.totalItem = 0;
        this.totalAmount = 0;
        this.cartArr = response.data.cartItems;
        this.cartArr.forEach((element, i) => {
          this.totalItem = element.qty + this.totalItem;
          if (element.productType !== 'GYANSTAR') {
            if (element.productType === 'OFFER') {
              if (element.offerId.offerType === 'FIX') {
                this.totalAmount = ((element.productId.price - element.offerId.offerTypeValue.fixValue) * element.qty) + this.totalAmount;
              } else if (element.offerId.offerType === 'PERCENTAGE') {
                this.totalAmount = ((element.productId.price - ((element.productId.price * element.offerId.offerTypeValue.percentageValue) / 100)) * element.qty) + this.totalAmount;
              } else {
                this.totalAmount = (element.productId.price * element.qty) + this.totalAmount;
              }
            }
            if (element.productType === 'REGULAR') {
              this.totalAmount = (element.productId.price * element.qty) + this.totalAmount;
            }
          }
          this.setPerItemQty[i] = element.qty;
        });
        console.log('cartArr', this.cartArr);
        // this.addQtyForm(this.cartArr.length);
      }
    });
  }
  deleteItem(item) {

    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to delete this product from your cart!',
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        const payload = {
          id: item
        };
        this.cartService.deleteCartItem(payload).subscribe(response => {
          if (response.status === 200) {
            this.commonService.showSuccess('Item deleted from cart');
            // this.getCartItems();
            // this.sharedService.getCartItems();
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
      }
    });
  }
  editItem(item) {
    // console.log('cartNavigate', item);
    // this.router.navigate(['/page/product/list/' + item._id + '/buyOnce']);
    this.router.navigate(['page/product/editCart/' + item._id], {state: {data: item}});
  }

  // function to navigae to basket summary
  openCartSummary() {
    this.router.navigate(['page/cart/summary']);
  }

  // function to select date time
  openScheduleCalendar() {
    this.router.navigate(['page/cart/scheduleCalendar']);
  }

  // function on increase quantity
  increaseValue(value, id, i) {
    const newVal = value + 1;
    // this.changeCartQuantityForm.controls.productQuantity.setValue(newVal);
    const payload = {
      qty: newVal
    };
    this.cartService.editCartQuantity(id, payload).subscribe(response => {
      if (response.status === 200) {
        this.setPerItemQty[i] = response.data.qty;
        this.getCartItems();
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

  // function on decrease quantity
  decreaseValue(value, id, i) {
    if (value <= 1) {
      return;
    }
    const newVal = value - 1;
    // this.changeCartQuantityForm.controls.productQuantity.setValue(newVal);
    const payload = {
      qty: newVal
    };
    this.cartService.editCartQuantity(id, payload).subscribe(response => {
      if (response.status === 200) {
        this.setPerItemQty[i] = response.data.qty;
        this.getCartItems();
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

  // function to open products section
  openProducts() {
    this.router.navigate(['page/product']);
  }

  // function to open product detail
  openProductDetail(item) {
    this.router.navigateByUrl('/page/product/list/' + item.productId._id);
  }

}
