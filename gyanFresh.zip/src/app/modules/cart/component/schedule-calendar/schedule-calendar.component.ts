import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/app/serviceFile/common.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { CartService } from '../../serviceFile/cart.service';

@Component({
  selector: 'app-schedule-calendar',
  templateUrl: './schedule-calendar.component.html',
  styleUrls: ['./schedule-calendar.component.scss']
})
export class ScheduleCalendarComponent implements OnInit {
  today = new Date();
  timeSlotsArr;
  scheduleCalendarForm: FormGroup;
  submitted: boolean = false;
  currentTime = { HH: new Date().getHours(), MM: new Date().getMinutes() };
  croneTime = JSON.parse(localStorage.getItem('crone'));

  constructor(private cartService: CartService, private fb: FormBuilder, private route: ActivatedRoute, private router: Router,
              private commonService: CommonService, private sharedService: SharedService) {
                this.today.setDate(this.today.getDate() + 1);
                this.croneTime.hour += 5;
                this.croneTime.minute += 30;
                this.croneLogic();
              }

  ngOnInit(): void {
    this.getTimeSlots();
    this.setFormField();
  }

  // function to get time slots
  getTimeSlots() {
    this.cartService.getTimeSlot().subscribe(response => {
      this.timeSlotsArr = response && response.data ? response.data : '';
      this.timeSlotsArr.forEach(element => {
        element.timeFrame = element.from + ' - ' + element.to;
      });
      this.selectSlot(this.timeSlotsArr[0]);
      console.log('timeSlots', this.timeSlotsArr);
    });
  }

  // function to get schedule calendar form controls
  get f() { return this.scheduleCalendarForm.controls; }

  // function to set form field
  setFormField() {
    this.scheduleCalendarForm = this.fb.group({
      date: [this.today, Validators.required],
      timeFrame: ['', Validators.required],
      selectedSlot: ['']
    });
  }

  // function to submit schedule calendar form
  submitScheduleCalendarForm() {
    this.submitted = true;
    if (!this.scheduleCalendarForm.valid) {
      console.log('notValidCartForm', this.scheduleCalendarForm.controls);
      return;
    }
    // const isoDate = this.scheduleCalendarForm.controls.date.value.toISOString();
    const payload = {
      deliveryDate: this.scheduleCalendarForm.controls.date.value.toISOString(),
      startTime: this.scheduleCalendarForm.controls.selectedSlot.value.from,
      endTime: this.scheduleCalendarForm.controls.selectedSlot.value.to
    };
    // console.log('data', payload);
    this.router.navigate(['page/cart/summary'], {state: {data: payload}});
  }

  // function on select time slot
  selectSlot(slot) {
    // console.log('selectedSlot', slot);
    this.scheduleCalendarForm.controls.selectedSlot.setValue(slot);
    this.scheduleCalendarForm.controls.timeFrame.clearValidators();
    this.scheduleCalendarForm.controls.timeFrame.updateValueAndValidity();
  }

  // function on increase quantity
  increaseValue(value) {
    const newVal = value + 1;
    this.scheduleCalendarForm.controls.productQuantity.setValue(newVal);
  }

  // function on decrease quantity
  decreaseValue(value) {
    if (value <= 1) {
      return;
    }
    const newVal = value - 1;
    this.scheduleCalendarForm.controls.productQuantity.setValue(newVal);
  }

  croneLogic() {
    if (this.croneTime.minute >= 60) {
      this.croneTime.hour += 1;
      this.croneTime.minute = this.croneTime.minute - 60;
      if (this.currentTime.HH >= this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.today.setDate(this.today.getDate() + 1);
      }
    } else {
      if (this.currentTime.HH > this.croneTime.hour) {
        this.today.setDate(this.today.getDate() + 1);
      } else if (this.currentTime.HH === this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.today.setDate(this.today.getDate() + 1);
      }
    }
  }

}
