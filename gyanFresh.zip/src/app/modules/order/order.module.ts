import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderListComponent } from './component/order-list/order-list.component';
import { ViewOrderComponent } from './component/view-order/view-order.component';
import { TrackOrderComponent } from './component/track-order/track-order.component';
import { RaiseDisputeComponent } from './component/raise-dispute/raise-dispute.component';
import { Routes, RouterModule } from '@angular/router';
import { ViewPastOrderComponent } from './component/view-past-order/view-past-order.component';
import { OrderService } from './serviceFile/order.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { AgmCoreModule } from '@agm/core';
import { AgmDirectionModule } from 'agm-direction';

export const routes: Routes = [
  { path: '', component: OrderListComponent, pathMatch: 'full' },
  { path: 'viewOrder/:id', component: ViewOrderComponent },
  // { path: 'trackOrder/:id', component: TrackOrderComponent },
  { path: 'raiseDispute/:id', component: RaiseDisputeComponent },
  { path: 'viewPastOrder/:id', component: ViewPastOrderComponent }
];

@NgModule({
  declarations: [OrderListComponent, ViewOrderComponent, TrackOrderComponent, RaiseDisputeComponent, ViewPastOrderComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    InfiniteScrollModule,
    AgmCoreModule.forRoot({
      // apiKey: 'AIzaSyCZHzbs0bTeJENvol3oxzFc-oW5otJUiy8'      // working trueFan api for geocoding only
      apiKey: 'AIzaSyDAIJ08X0BznyCJXQiD5Dt3cRXWoj8WZd8'
    }),
    AgmDirectionModule
  ],
  exports: [OrderListComponent],
  providers: [OrderService]
})
export class OrderModule { }
