import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderService } from '../../serviceFile/order.service';

@Component({
  selector: 'app-view-order',
  templateUrl: './view-order.component.html',
  styleUrls: ['./view-order.component.scss']
})
export class ViewOrderComponent implements OnInit {
  id;
  orderDetailArr;
  totalAmount = 0;
  totalDiscount = 0;
  grandTotalSemiDelivered = 0;

  constructor(private route: ActivatedRoute, private orderService: OrderService, private router: Router) { }

  ngOnInit(): void {

    this.id = this.route.snapshot.paramMap.get('id');
    this.getOrderDetail(this.id);
  }

  // function to get past order detail
  getOrderDetail(id) {
    this.orderService.getOrderDetail(id).subscribe(response => {
      if (response.status === 200) {
        this.orderDetailArr = response.data;
        this.orderDetailArr[0].allproduct.forEach(element => {
          element.productDetails = JSON.parse(element.productDetails);
          if (element.semiDelivered.qty) {
            if (element.productType !== 'GYANSTAR') {
              this.totalAmount = (element.productDetails.price * element.semiDelivered.qty) + this.totalAmount;
              if (element.productType === 'OFFER') {
                // debugger
                if (element.offer.offerType === 'FIX') {
                  // this.totalAmount = ((element.productDetails.price - element.offerId.offerTypeValue.fixValue) * element.qty) + this.totalAmount;
                  this.totalDiscount += Number(element.offer.offerTypeValue.fixValue) * element.semiDelivered.qty;
                  console.log('discountFix', this.totalDiscount);
                } else if (element.offer.offerType === 'PERCENTAGE') {
                  // this.totalAmount = ((element.productDetails.price - ((element.productDetails.price * element.offerId.offerTypeValue.percentageValue) / 100)) * element.qty) + this.totalAmount;
                  this.totalDiscount += Number(((element.productDetails.price * element.offer.offerTypeValue.percentageValue) / 100)) * element.semiDelivered.qty;
                  // console.log('discountPercent', (element.productDetails.price * element.offerId.offerTypeValue.percentageValue) / 100);
                }
              }
            }
          }
        });
        this.grandTotalSemiDelivered = (this.totalAmount + this.orderDetailArr[0].deliveryCharges) - this.totalDiscount;
        console.log('orderDetailArr', this.orderDetailArr);
      }
    });
  }

  // function to goto Track order
  gotoTrackOrder() {
    this.router.navigate(['page/orders/trackOrder/' + this.orderDetailArr[0]._id], {state: {data: this.orderDetailArr[0]}});
  }

  // function to open dialer
  launchDialer(num: number) {
    const phoneNumber = num.toString();
    // console.log('phoneNumber', typeof(phoneNumber));
    // return;
    // this.callNumber.callNumber(phoneNumber, true)
    // .then(res => console.log('Launched dialer!', res))
    // .catch(err => console.log('Error launching dialer', err));
    document.location.href = 'tel:+91' + phoneNumber;
    }

}
