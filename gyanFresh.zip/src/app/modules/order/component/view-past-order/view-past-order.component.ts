import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { OrderService } from '../../serviceFile/order.service';

declare let clevertap: any;

interface OrderObj {
  grandTotal: number;
  totalItems: number;
  totalMRP: number;
  totalProduts: number;
  deliveryCharge: number;
}
@Component({
  selector: 'app-view-past-order',
  templateUrl: './view-past-order.component.html',
  styleUrls: ['./view-past-order.component.scss']
})
export class ViewPastOrderComponent implements OnInit {
  id;
  orderDetailArr;
  totalAmount = 0;
  totalDiscount = 0;
  grandTotalSemiDelivered = 0;
  orderDetailObj: OrderObj;

  constructor(private route: ActivatedRoute, private orderService: OrderService, private fireAnalytics: FirebaseAnalyticsCustomService) { }

  ngOnInit(): void {

    this.id = this.route.snapshot.paramMap.get('id');
    this.getOrderDetail(this.id);
    try {
      clevertap.event.push(app_strings.CUSTOME.MY_ORDER, {
        "platform": localStorage.getItem('deviceType')
      });
      this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.MY_ORDER);
    } catch (error) {
      console.log(error);
    }
  }

  // function to get past order detail
  getOrderDetail(id) {
    this.orderService.getOrderDetail(id.toString()).subscribe(response => {
      if (response.status === 200) {
        this.orderDetailArr = response.data;
        this.orderDetailObj = response.response;
        this.orderDetailArr.forEach(element1 => {
          element1.orderStatus = element1.orderStatusTrack.orderStaus.pop();
          element1.allproduct.forEach(element => {
          element1.productDetails = JSON.parse(element.productDetails);
          if (element.semiDelivered.qty) {
            if (element.productType !== 'GYANSTAR') {
              this.totalAmount = (element.productDetails.price * (element.qty - element.semiDelivered.qty)) + this.totalAmount;
              if (element.productType === 'OFFER') {
                // debugger
                if (element.offer.offerType === 'FIX') {
                  // this.totalAmount = ((element.productDetails.price - element.offerId.offerTypeValue.fixValue) * element.qty) + this.totalAmount;
                  this.totalDiscount += Number(element.offer.offerTypeValue.fixValue) * (element.qty - element.semiDelivered.qty);
                  console.log('discountFix', this.totalDiscount);
                } else if (element.offer.offerType === 'PERCENTAGE') {
                  // this.totalAmount = ((element.productDetails.price - ((element.productDetails.price * element.offerId.offerTypeValue.percentageValue) / 100)) * element.qty) + this.totalAmount;
                  this.totalDiscount += Number(((element.productDetails.price * element.offer.offerTypeValue.percentageValue) / 100)) * (element.qty - element.semiDelivered.qty);
                  // console.log('discountPercent', (element.productDetails.price * element.offerId.offerTypeValue.percentageValue) / 100);
                }
              }
            }
          }
         });
        });
        this.grandTotalSemiDelivered = (this.totalAmount + this.orderDetailArr[0].deliveryCharges) - this.totalDiscount;
        console.log('orderDetailArr', this.orderDetailArr);
        // this.orderDetailArr[0].orderStatusTrack.orderStaus[3].status = 'CANCELED';
      }
    });
  }

}
