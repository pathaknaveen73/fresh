import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPastOrderComponent } from './view-past-order.component';

describe('ViewPastOrderComponent', () => {
  let component: ViewPastOrderComponent;
  let fixture: ComponentFixture<ViewPastOrderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewPastOrderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPastOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
