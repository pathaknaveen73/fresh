import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrderService } from '../../serviceFile/order.service';
// import { AngularFirestore } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { AngularFireDatabase } from '@angular/fire/database';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-track-order',
  templateUrl: './track-order.component.html',
  styleUrls: ['./track-order.component.scss']
})
export class TrackOrderComponent implements OnInit {
  lat = 28.586493;
  lng = 77.376926;
  orderData;
  deliveryChampionLocation;
  address;
  items$: Observable<any>;
  public origin: any;
  public destination: any;
  zoom: number = 60;
  public renderOptions = {
    suppressMarkers: true,
};
public markerOptions = {
  origin: {
      // icon: 'assets/img/driver_icon.png',
      icon: 'assets/img/delivery_boy.png',
      draggable: false,
  },
  destination: {
      icon: 'assets/img/destinationMarker.png',
      // label: 'MARKER LABEL',
      // opacity: 0.8,
  },
}
  style = [
    {
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#f5f5f5"
        }
      ]
    },
    {
      "elementType": "labels.icon",
      "stylers": [
        {
          "visibility": "off"
        }
      ]
    },
    {
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#616161"
        }
      ]
    },
    {
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#f5f5f5"
        }
      ]
    },
    {
      "featureType": "administrative.land_parcel",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#bdbdbd"
        }
      ]
    },
    {
      "featureType": "poi",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#eeeeee"
        }
      ]
    },
    {
      "featureType": "poi",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#757575"
        }
      ]
    },
    {
      "featureType": "poi.park",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#e5e5e5"
        }
      ]
    },
    {
      "featureType": "poi.park",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#9e9e9e"
        }
      ]
    },
    {
      "featureType": "road",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#ffffff"
        }
      ]
    },
    {
      "featureType": "road.arterial",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#757575"
        }
      ]
    },
    {
      "featureType": "road.highway",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#dadada"
        }
      ]
    },
    {
      "featureType": "road.highway",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#616161"
        }
      ]
    },
    {
      "featureType": "road.local",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#9e9e9e"
        }
      ]
    },
    {
      "featureType": "transit.line",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#e5e5e5"
        }
      ]
    },
    {
      "featureType": "transit.station",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#eeeeee"
        }
      ]
    },
    {
      "featureType": "water",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#c9c9c9"
        }
      ]
    },
    {
      "featureType": "water",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#9e9e9e"
        }
      ]
    }
  ];

  constructor(private router: Router, private orderService: OrderService, private db: AngularFireDatabase,
              private spinner: NgxSpinnerService) {

  }

  ngOnInit(): void {
    if (!history.state.data) {
      this.router.navigate(['page/orders']);
    } else {
      this.orderData = history.state.data;
      this.getDeliveryChampionLocation(this.orderData._id);
      console.log('orderData', this.orderData);
      // this.destination = {lat: 28.5767, lng: 77.3802};   // sector 75 address
      this.destination = {lat : this.orderData.deliveryAdress.coordinates[0], lng : this.orderData.deliveryAdress.coordinates[1]};
      // this.orderService.getDeliveryChampionData(this.orderData.uniqueId).subscribe(re=>console.log(re));
      this.showSpinner();
    }
  }

  // function to goto order
  gotoOrder() {
    this.router.navigate(['page/orders/viewOrder/' + this.orderData._id]);
  }

  // function to get delivery champion location in realtime
  getDeliveryChampionLocation(orderId) {
    // console.log('orderID', orderId);
    // this.items = this.firestore.collection('gyan-fresh-278410/driver_location/123').valueChanges();
    this.db.object('/driver_location/' + orderId).valueChanges().subscribe(data => {
      console.log('CAHMPION', data);
      if (data) {
        this.deliveryChampionLocation = data;
        this.origin = {lat: this.deliveryChampionLocation.latitude, lng: this.deliveryChampionLocation.longitude};
        this.hideSpinner();
        // console.log('deliveryChampionLocation', this.deliveryChampionLocation);
      }
    });
    // this.items = this.db.list('/driver_location/123').valueChanges();
  }

  // getAddress( lat: number, lng: number ) {
  //   console.log('Finding Address');
  //   if (navigator.geolocation) {
  //     let geocoder = new google.maps.Geocoder();
  //     let latlng = new google.maps.LatLng(lat, lng);
  //     let request = { latLng: latlng };
  //     geocoder.geocode({location: latlng}, (results, status) => {
  //       if (status === google.maps.GeocoderStatus.OK) {
  //         let result = results[0];
  //         let rsltAdrComponent = result.address_components;
  //         console.log(rsltAdrComponent);
  //         let resultLength = rsltAdrComponent.length;
  //         if (result != null) {
  //           this.address = rsltAdrComponent[resultLength - 8].short_name;
  //         } else {
  //           alert('No address available!');
  //         }
  //       }
  //     });
  // }
  // }

  mapReady() {
    // this.getAddress(this.lat, this.lng);
  }

  showSpinner() {
    this.spinner.show();
  }

  hideSpinner() {
    this.spinner.hide();
  }


  // [latitude]="deliveryChampionLocation.latitude"
  //               [longitude]="deliveryChampionLocation.longitude"

}
