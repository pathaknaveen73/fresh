import { Component, OnInit } from '@angular/core';
import { OrderService } from '../../serviceFile/order.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/app/serviceFile/common.service';

@Component({
  selector: 'app-raise-dispute',
  templateUrl: './raise-dispute.component.html',
  styleUrls: ['./raise-dispute.component.scss']
})
export class RaiseDisputeComponent implements OnInit {
  raiseDisputeForm: FormGroup;
  submitted = false;
  reasonListArr;
  selectedReason;
  imageSelected = false;
  imageUrl;
  id;

  constructor(private orderService: OrderService, private fb: FormBuilder, private route: ActivatedRoute,
              private router: Router, private commonService: CommonService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.getReasonList();
    this.setFormField();
  }

  // function to set raise dispute form field
  setFormField() {
    this.raiseDisputeForm = this.fb.group({
      selectReason: ['', [Validators.required]],
      message: ['', [Validators.required]],
      photo: [''],
      photoToSend: ['']
    });
  }

  // function to get form controls
  get f() { return this.raiseDisputeForm.controls; }

  // function to get reason list
  getReasonList() {
    this.orderService.getDisputReason().subscribe(response => {
      if (response.status === 200) {
        this.reasonListArr = response.data;
        this.selectedReason = this.reasonListArr[0]._id;
        console.log('reasonListArr', this.reasonListArr);
      }
    });
  }

  // function to submit raise dispute form
  submit() {
    this.submitted = true;
    if (!this.raiseDisputeForm.valid) {
      console.log('invalidRaiseDisputeForm', this.raiseDisputeForm.controls);
      return;
    }
    const val = {
      suggestion: this.raiseDisputeForm.controls.selectSuggestion.value,
      description: this.raiseDisputeForm.controls.message.value,
      orderId: this.id
    };
    const fd = new FormData();

    for (let property in val) {
      fd.append(property, val[property]);
    };
    if (this.imageUrl) {
      fd.append('files', this.raiseDisputeForm.controls.photoToSend.value);
    }
    if (!fd.get('files')) {
      fd.delete('files');
    }
    if (fd.get('files') == '10') {
      fd.delete('files');
    }
    return;
    this.commonService.showSpinner();
    this.orderService.sendRaiseDispute(fd).subscribe(response => {
        if (response.status === 200) {
          this.commonService.hideSpinner();
          this.commonService.showSuccess('Dispute Submitted');
          this.router.navigate(['page/orders']);
        } else {
          this.commonService.showError(response.message);
        }
      });
  }

  // function on image select
  onImageSelect(event) {
    if (event.target.files.length > 0) {
      this.raiseDisputeForm.get('photoToSend').setValue(event.target.files[0]);
      let reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (_event) => {
        this.imageUrl = reader.result;
        this.imageSelected = true;
        // $('#companyLogo').attr('src', imgURL);
      };
    }
  }

  // function to remove photo
  removePhoto() {
    // value 10 means to remove photo and send blank image
    this.raiseDisputeForm.controls.photoToSend.setValue(10);
    this.imageSelected = false;
    this.imageUrl = undefined;
  }

}
