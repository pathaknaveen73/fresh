import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrderService } from '../../serviceFile/order.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { BuyOnceService } from 'src/app/serviceFile/buyOnce.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';

// declare let clevertap: any;

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.scss']
})
export class OrderListComponent implements OnInit {
  currentOrderArr;
  pastOrderArr;
  limit = 10;
  offset = 0;
  isCurrentActive = false;
  @Input() show: boolean;

  constructor(private router: Router, private orderService: OrderService, private commonService: CommonService,
              private buyService: BuyOnceService) { }

  ngOnInit(): void {
    // this.currentOrder();
    // clevertap.event.push(app_strings.CUSTOME.MY_ORDER, {
    //   "platform": localStorage.getItem('deviceType')
    // });
    this.pastOrder()
  }

  // function to navigate to view current order
  openViewOrder(id) {
    this.router.navigate(['page/orders/viewOrder/' + id]);
  }
  // function to navigate to raise dispute
  openRaiseDispute(orderId) {
    this.router.navigate(['page/orders/raiseDispute/' + orderId]);
  }
  // function to navigate to track order
  openTrackOrder(item) {
    this.router.navigate(['page/orders/trackOrder/' + item._id], {state: {data: item}});
  }
  // function to navigate to view past order
  openPastOrder(id) {
    this.router.navigate(['page/orders/viewPastOrder/' + id]);
    // this.router.navigate(['page/orders/viewOrder/' + id]);
  }

  // function on current order toggle
  currentOrder() {
    console.log('current order list');
    this.orderService.getActiveOrder().subscribe(response => {
      if (response.status === 200) {
        this.currentOrderArr = response.data;
        console.log('currentOrderArr', this.currentOrderArr);
      }
    });
  }

  // function on past order toggle
  pastOrder() {
    console.log('past order list');
    const payload = {
      offset: this.offset,
      limit: this.limit
    };
    this.orderService.getPastOrder(payload).subscribe(response => {
      if (response.status === 200) {
        this.pastOrderArr = response.data;
        console.log('pastOrder', this.pastOrderArr);
      }
    });
  }

  // function on scroll
  onScroll() {
    // console.log('scrolledOrder', this.show);
    if (this.show) {
      this.offset += 10;
      const payload = {
      offset: this.offset,
      limit: this.limit
    };
      this.orderService.getPastOrder(payload).subscribe(response => {
      if (response.status === 200) {
        if (response.data && response.data.length > 0) {
          const orderArr = response.data;
          orderArr.forEach(element => {
            this.pastOrderArr.push(element);
          });
          console.log('updated+10pastOrder', this.pastOrderArr);
        }

      }
    });
    }
  }

  repeatOrderBuyOnce(item) {
    let itemObj;
    item.allproduct.forEach(element => {
      if (element.productType !== 'FREE') {
        itemObj = JSON.parse(element.productDetails)
        return;
      }
    });
    this.commonService.showSpinner();
    this.buyService.setFormField(itemObj, 1, new Date(),
      { editFlag: false, editVal: [] });
  }

  // function to toggle tab b/w current and past order
  // toggleOrders() {

  // }

}
