import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';
import { HttpClient } from '@angular/common/http';
import { AngularFireDatabase } from '@angular/fire/database';
import { map } from 'rxjs/operators';

@Injectable()
export class OrderService {

  constructor(private apiService: ApiService, private httpClient: HttpClient, private db: AngularFireDatabase) { }

  // function to get active order list
  getActiveOrder() {
    const url = 'myActiveOrders';
    return this.apiService.getApi(url);
  }

  // function to get past order list
  getPastOrder(payload) {
    const url = 'getMyPastOrdersUpdated?offset=' + payload.offset + '&limit=' + payload.limit; // old api: myPastOrders
    return this.apiService.getApi(url);
  }

  // function to get order detail
  getOrderDetail(id) {
    const url = 'orderDetailsUpdated/' + id;    // old api: orderDetails
    return this.apiService.getApi(url);
  }

  // function to get disput reason list
  getDisputReason() {
    const url = 'disputeResion';
    return this.apiService.getApi(url);
  }

  // function to send raise dispute data
  sendRaiseDispute(payload) {
    const url = 'raiseDispute';
    return this.apiService.postApi(url, payload);
  }

  // function to get delivery champion location in realtime
  getDeliveryChampionData(id) {
    // const url = 'https://gyan-fresh-278410.firebaseio.com/gyan-fresh-278410/driver_location/' + id;
    // return this.httpClient.get(url);
    return this.db.list('/driver_location/' + id).snapshotChanges().pipe(
      map((products: any[]) => products.map(prod => {
        const payload = prod.payload.val();
        const key = prod.key;
        return <any>{ key, ...payload };
      })),
    );
  }
}
