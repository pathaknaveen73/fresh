import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class AddressService {

  constructor(private apiService: ApiService) { }

  // function to get all addresses
  getAllAddress() {
    const url = 'allAddress';
    return this.apiService.getApi(url);
  }
  // function to get all city
  getCity() {
    const url = 'townsAreas';
    return this.apiService.getApi(url);
  }
  // function to add new address
  addNewAddress(payload) {
    const url = 'addAddress';
    return this.apiService.postApi(url, payload);
  }
  // function to change primary address
  changePrimaryAddress(payload) {
    const url = 'primaryAddress';
    return this.apiService.putApi(url, payload);
  }
  // function to update the address
  editAddress(payload, id) {
    const url = 'editAddress/' + id;
    return this.apiService.putApi(url, payload);
  }
  // function to delete a address
  deleteAddress(id) {
    const url = 'deleteAddress/' + id;
    return this.apiService.deleteApi(url);
  }
}
