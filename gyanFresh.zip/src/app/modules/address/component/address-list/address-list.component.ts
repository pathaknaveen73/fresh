import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AddressService } from '../../serviceFile/address.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
import Swal from 'sweetalert2';
import {Location} from '@angular/common';

@Component({
  selector: 'app-address-list',
  templateUrl: './address-list.component.html',
  styleUrls: ['./address-list.component.scss']
})
export class AddressListComponent implements OnInit {
  addressArr;
  data;
  fromCartSummaryFlag = false;

  constructor(private router: Router, private addressService: AddressService, private commonService: CommonService,
              private sharedService: SharedService, private route: ActivatedRoute, private location: Location) { }

  ngOnInit(): void {
    // const reload = localStorage.getItem('gyanReload');
    // if (reload && reload === '1') {
    //   localStorage.removeItem('gyanReload');
    //   window.location.reload();
    // }
    if (history.state.data) {
      // this.router.navigate(['page/cart']);
      if (history.state.data === 'summary') {
        this.fromCartSummaryFlag = true;
        console.log(history.state.data);
      }
    }
    this.getAllAddress();
  }

  // function to navigate to add address
  addAddress(address?) {
    this.commonService.showInfo('Please contact customer care to add/edit new address');
    return;
    const title = [];
    this.addressArr.forEach(element => {
      title.push({
        title: element.addressTitle,
        text: element.addressTitle.split('-')[0],
        number: Number(element.addressTitle.split('-')[1])
      });
    });
    if (address) {
      this.router.navigate(['page/address/newAddress'], {queryParams: {data: JSON.stringify(address), title: JSON.stringify(title), id: address._id}});
    } else {
      this.router.navigate(['page/address/newAddress'], { queryParams: { title: JSON.stringify(title) } });
    }
  }
  // function to get all address
  getAllAddress() {
    this.addressService.getAllAddress().subscribe(response => {
      if (response.status === 200) {
        this.addressArr = response.data.location;
        // console.log('addressArr', this.addressArr);
      }
    });
  }
  // function to change primary address
  changePrimaryAdddress(data, i) {
    console.log(data);
    if (data.default === 'PRIMARY') {
      return;
    }
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to change your primary address !',
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        const payload = {
          addressId: data._id
        };
        this.addressService.changePrimaryAddress(payload).subscribe(response => {
          if (response.status === 200) {
            this.commonService.showSuccess('Primary address has been changed');
            this.sharedService.getAllLocation();
            this.sharedService.nearbyGFS();
            if (this.fromCartSummaryFlag) {
              this.location.back();
            } else {
              this.getAllAddress();
            }
          } else {
            this.commonService.showError(response.message);
            this.getAllAddress();
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        this.getAllAddress();
      }
    });
  }
  // function to navigate to edit address
  openEditAddress(address) {
    this.router.navigate(['page/address/edit/' + address._id], {state: {data: address}});
  }
  // function to delete a address
  openDeleteAddress(data, id) {
    this.commonService.showInfo('Please contact customer care to add/edit new address');
    return;
    if (data === 'PRIMARY') {
      Swal.fire({
        title: 'This is primary address',
        text: 'Primary address cannot be deleted !',
        icon: 'error',
        showCancelButton: false,
        allowOutsideClick: false,
        confirmButtonText: 'Ok',
        cancelButtonText: 'No'
      });
      return;
    } else {
      Swal.fire({
        title: 'Are you sure?',
        text: 'You want to delete this address !',
        icon: 'warning',
        showCancelButton: true,
        allowOutsideClick: false,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No'
      }).then((result) => {
        if (result.value) {
          this.addressService.deleteAddress(id).subscribe(response => {
            if (response.status === 200) {
              this.commonService.showSuccess(response.message);
              this.getAllAddress();
            } else {
              this.commonService.showError(response.message);
            }
          });
        } else if (result.dismiss === Swal.DismissReason.cancel) {
        }
      });
    }
  }

}
