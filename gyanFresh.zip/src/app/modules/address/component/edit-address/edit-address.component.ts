import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AddressService } from '../../serviceFile/address.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { MatDialog } from '@angular/material/dialog';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';

@Component({
  selector: 'app-edit-address',
  templateUrl: './edit-address.component.html',
  styleUrls: ['./edit-address.component.scss']
})
export class EditAddressComponent implements OnInit {
  addAddressForm: FormGroup;
  submitted = false;
  cityListArr = [];
  selectedCity;
  selectedAreaArr;
  areaListArr = [];
  selectedArea;
  data;
  id;
  addressType = [{ label: 'Individual House', value: 'OWN_HOUSE' }, { label: 'Apartment', value: 'APARTMENT' }];
  selectedAddressType;
  apiKey = 'AIzaSyDAIJ08X0BznyCJXQiD5Dt3cRXWoj8WZd8';
  mapApiUrl = 'https://maps.googleapis.com/maps/api/geocode/json?';

  constructor(private fb: FormBuilder, private router: Router, private addressService: AddressService, private commonService: CommonService,
    private route: ActivatedRoute, public dialog: MatDialog) { }

  ngOnInit(): void {
    if (!history.state.data) {
      this.router.navigate(['page/address']);
    }
    this.data = history.state.data;
    console.log('urlParameter', this.data);
    this.id = this.route.snapshot.paramMap.get('id');
    this.getAllCity();
    this.setFormField();
  }

  // function to set add address form field
  setFormField() {
    this.addAddressForm = this.fb.group({
      flat: [this.data && this.data.flatNo ? this.data.flatNo : '', [Validators.required]],
      landmark: [this.data && this.data.landMark ? this.data.landMark : ''],
      city: [this.data && this.data.city ? this.data.city._id : '', [Validators.required]],
      area: [this.data && this.data.area ? this.data.area._id : '', [Validators.required]],
      zipcode: [this.data && this.data.zipcode ? this.data.zipcode : '', [Validators.required, Validators.pattern(/^[1-9][0-9]{5}$/)]],
      title: [this.data && this.data.addressTitle ? this.data.addressTitle : '', [Validators.required]],
      lat: [this.data && this.data.coordinates ? this.data.coordinates[0] : ''],
      long: [this.data && this.data.coordinates ? this.data.coordinates[1] : ''],
      addressType: [this.data && this.data.addressType ? this.data.addressType : '', [Validators.required]]
    });
  }
  // function to get form controls
  get f() { return this.addAddressForm.controls; }
  // function to submit address form
  submitAddressForm() {
    this.submitted = true;
    if (!this.addAddressForm.valid) {
      console.log('notValidAddressForm', this.addAddressForm.controls);
      return;
    }
    this.openDialog();
  }
  // function to get all city
  getAllCity() {
    this.addressService.getCity().subscribe(response => {
      const dataArr = response && response.data ? response.data : [];
      dataArr.forEach(element => {
        this.cityListArr.push({
          id: element._id, cityName: element.location.townName,
          areaArr: this.getArea(element.area)
        });
      });
      this.selectedCity = this.cityListArr[0];
      console.log('KULDEEEEEP', this.selectedCity);
      // this.selectedAreaArr = this.cityListArr.filter(element => this.data.city._id === element.id);
      this.cityListArr.forEach(element => {
        if (this.data && this.data.city._id === element.id) {
          this.selectedAreaArr = element.areaArr;
        }
      });
      // this.selectedArea = this.selectedCity.areaArr[0].id;
    });
    console.log('cityList', this.cityListArr);
    // this.selectedCity = this.cityListArr[1];
  }
  // function to get area
  getArea(element) {
    let data = [];
    element.forEach(abc => {
      data.push({ id: abc._id, areaName: abc.location.areaName });
      this.areaListArr.push(abc);
    });
    // console.log('areaArr', this.areaListArr);
    return data;
  }
  // function on a particular city selected from dropdown
  onSelectCity(val) {
    console.log('selectedCity', val);
    this.cityListArr.forEach(element => {
      if (val === element.id) {
        this.selectedAreaArr = element.areaArr;
      }
    });
    this.addAddressForm.controls.area.setValue('');
    this.addAddressForm.controls.area.updateValueAndValidity();
  }
  // function on selecting an area
  onSelectArea(val) {
    console.log('selectedArea', val);
    // this.selectedArea = val;
    // this.addAddressForm.controls.area.setValue(val);
    // this.addAddressForm.controls.area.updateValueAndValidity();
  }

  // function to detect current user location
  findMe() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        console.log(position);
        this.addAddressForm.controls.lat.setValue(position.coords.latitude);
        this.addAddressForm.controls.long.setValue(position.coords.longitude);
        this.getUserAddress(position.coords.latitude, position.coords.longitude);
        // this.locate();
      });
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  }

  // function to get user formatted address using lat, long
  getUserAddress(lat, long) {
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = () => {
      if (xhttp.readyState === 4 && xhttp.status === 200) {
        const address = JSON.parse(xhttp.responseText);
        this.addAddressForm.controls.flat.setValue(address.results[0].formatted_address);
        console.log('formattedUserAddress', address.results[0].formatted_address);
      }
    };
    xhttp.open('GET', this.mapApiUrl + 'latlng=' + lat + ',' + long + '&key=' + this.apiKey, true);
    xhttp.send();
  }

  getGeocodeOnManualInputAddress() {
    const userAdd = this.addAddressForm.controls.flat.value;
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = () => {
      if (xhttp.readyState === 4 && xhttp.status === 200) {
        const latLng = JSON.parse(xhttp.responseText);
        console.log('adddress', latLng.results[0].geometry.location);
        this.addAddressForm.controls.lat.setValue(latLng.results[0].geometry.location.lat);
        this.addAddressForm.controls.long.setValue(latLng.results[0].geometry.location.lng);
      }
    };
    xhttp.open('GET', this.mapApiUrl + 'address=' + userAdd + '&components=country:IN&key=' + this.apiKey, true);
    xhttp.send();
  }

  enableToCheckLatLng() {
    this.getGeocodeOnManualInputAddress();
  }

  // function to open golabl dialog
  openDialog() {
    // console.log('tableData', selectedMerchant);
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '600px',
      height: 'auto',
      disableClose: true,
      data: { type: 'checkAdd' }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result !== undefined) {
        const payload = {
          city: this.addAddressForm.controls.city.value,
          area: this.addAddressForm.controls.area &&
            this.addAddressForm.controls.area.value ? this.addAddressForm.controls.area.value : '',
          addressTitle: this.addAddressForm.controls.title &&
            this.addAddressForm.controls.title.value ? this.addAddressForm.controls.title.value : '',
          flatNo: this.addAddressForm.controls.flat &&
            this.addAddressForm.controls.flat.value ? this.addAddressForm.controls.flat.value : '',
          landMark: this.addAddressForm.controls.landmark &&
            this.addAddressForm.controls.landmark.value ? this.addAddressForm.controls.landmark.value : '',
          zipcode: this.addAddressForm.controls.zipcode &&
            this.addAddressForm.controls.zipcode.value ? this.addAddressForm.controls.zipcode.value : '',
          coordinates: [this.addAddressForm.controls.lat.value, this.addAddressForm.controls.long.value],
          addressType: this.addAddressForm.controls.addressType.value ? this.addAddressForm.controls.addressType.value : ''
        };
        this.addressService.editAddress(payload, this.id).subscribe(response => {
          if (response.status === 200) {
            this.commonService.showSuccess(response.message);
            this.router.navigate(['page/address'], { replaceUrl: true });
          } else {
            this.commonService.showError(response.message);
          }
        });
      }
    });
  }

}
