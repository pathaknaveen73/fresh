import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AddressService } from '../../serviceFile/address.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { MatDialog } from '@angular/material/dialog';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';
import { MapsAPILoader } from '@agm/core';
// import { google } from '@agm/core/services/google-maps-types';
// import { google } from 'google-maps';
// declare let google: google;

@Component({
  selector: 'app-add-address',
  templateUrl: './add-address.component.html',
  styleUrls: ['./add-address.component.scss']
})
export class AddAddressComponent implements OnInit {
  addAddressForm: FormGroup;
  submitted = false;
  cityListArr = [];
  selectedCity;
  selectedAreaArr;
  areaListArr = [];
  selectedArea;
  lat;
  lng;
  address;
  addressType = [ { label: 'Individual House', value: 'OWN_HOUSE' }, { label: 'Apartment', value: 'APARTMENT' } ];
  selectedAddressType;
  // ku = new google;
  apiKey = 'AIzaSyDAIJ08X0BznyCJXQiD5Dt3cRXWoj8WZd8';
  mapApiUrl = 'https://maps.googleapis.com/maps/api/geocode/json?';
  title = [];
  largestNo = 0;
  editData;
  id;
  editFlag = false;
  first = false;

  constructor(private fb: FormBuilder, private router: Router, private addressService: AddressService, private commonService: CommonService, public dialog: MatDialog,
    private apiloader: MapsAPILoader, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.getAllCity();
    // this.setFormField();
    this.route.queryParams.subscribe(param => {
      if (param.title) {
        this.title = JSON.parse(param.title);
        console.log('title', this.title);
        this.title.forEach(element => {
          if (element.number && element.number > this.largestNo) {
            this.largestNo = element.number
          }
        });
        this.setFormField();
        if (param.id) {
          this.editData = JSON.parse(param.data);
          this.id = param.id;
          this.editFlag = true;
          console.log('editData', this.editData)
          const { addressTitle, addressType, flatNo, landMark, city, coordinates } = this.editData;
          this.addAddressForm.patchValue({
            flat: flatNo,
            landmark: landMark,
            city: city._id,
            title: addressTitle,
            lat: coordinates[0],
            long: coordinates[1],
            addressType: addressType
          })
          this.title.forEach((element, index, object) => {
            if(addressTitle === element.title) {
              object.splice(index, 1);
            }
          });
        }
        if (param.first) {
          this.first = true;
        }
      }
    });
  }

  // function to set add address form field
  setFormField() {
    this.addAddressForm = this.fb.group({
      flat: ['', [Validators.required]],
      landmark: [''],
      city: ['', [Validators.required]],
      // area: ['', [Validators.required]],
      // zipcode: ['', [Validators.required, Validators.pattern(/^[1-9][0-9]{5}$/)]],
      title: [this.editFlag ? '': `Home-${this.largestNo+1}`, [Validators.required]],
      lat: [''],
      long: [''],
      addressType: ['OWN_HOUSE', [Validators.required]]
    });
  }
  // function to get form controls
  get f() { return this.addAddressForm.controls; }
  // function to submit address form
  submitAddressForm() {
    this.submitted = true;
    if (!this.addAddressForm.valid) {
      console.log('notValidAddressForm', this.addAddressForm.controls);
      return;
    }
    // this.openDialog();
    const title: any = this.addAddressForm.controls.title.value;
    // this.title.forEach(element => {
    //   if (title.toLowerCase() === element.title.toLowerCase()) {
    //     this.commonService.showWarning('This address type already exist');
    //     return;
    //   }
    // });
    for (let i = 0; i < this.title.length; i++) {
      if (title.toLowerCase() === this.title[i].title.toLowerCase()) {
        this.commonService.showWarning('This address type already exist');
        return;
      }
    }
    const payload = {
      city: this.addAddressForm.controls.city.value,
      // area: this.addAddressForm.controls.area &&
      //   this.addAddressForm.controls.area.value ? this.addAddressForm.controls.area.value : '',
      addressTitle: this.addAddressForm.controls.title &&
        this.addAddressForm.controls.title.value ? this.addAddressForm.controls.title.value : '',
      flatNo: this.addAddressForm.controls.flat &&
        this.addAddressForm.controls.flat.value ? this.addAddressForm.controls.flat.value : '',
      landMark: this.addAddressForm.controls.landmark &&
        this.addAddressForm.controls.landmark.value ? this.addAddressForm.controls.landmark.value : '',
      // zipcode: this.addAddressForm.controls.zipcode &&
      //   this.addAddressForm.controls.zipcode.value ? this.addAddressForm.controls.zipcode.value : '',
      lognitude: this.addAddressForm.controls.long.value ? this.addAddressForm.controls.long.value : 0,
      lattitude: this.addAddressForm.controls.lat.value ? this.addAddressForm.controls.lat.value : 0,
      addressType: this.addAddressForm.controls.addressType.value ? this.addAddressForm.controls.addressType.value : ''
    };
    console.log('checkPayload', payload);
    if (this.editFlag) {
      this.addressService.editAddress(payload, this.id).subscribe(response => {
        if (response.status === 200) {
          this.commonService.showSuccess(response.message);
          this.router.navigate(['page/address'], { replaceUrl: true });
        } else {
          this.commonService.showError(response.message);
        }
      });
    } else {
      this.addressService.addNewAddress(payload).subscribe(response => {
        if (response.status === 200) {
          this.commonService.showSuccess(response.message);
          localStorage.setItem('isAdd', '1');
          if (this.first) {
            localStorage.setItem('gyanReload', '1');
            this.router.navigate(['page/home'], { replaceUrl: true });
            return;
          }
          this.router.navigate(['page/address'], { replaceUrl: true });
        } else {
          this.commonService.showError(response.message);
        }
      });
    }
  }
  // function to get all city
  getAllCity() {
    this.addressService.getCity().subscribe(response => {
      this.cityListArr = response.data;
      this.selectedCity = this.cityListArr[0]._id;
      // const dataArr = response && response.data ? response.data : [];
      // dataArr.forEach(element => {
      //   this.cityListArr.push({
      //     id: element._id, cityName: element.location.townName,
      //     areaArr: this.getArea(element.area)
      //   });
      // });
      // this.selectedCity = this.cityListArr[0];
      // console.log('KULDEEEEEP', this.selectedCity);
      // this.selectedAreaArr = this.selectedCity.areaArr;
      // this.selectedArea = this.selectedCity.areaArr[0].id;
    });
    console.log('cityList', this.cityListArr);
    // this.selectedCity = this.cityListArr[1];
  }
  // function to get area
  getArea(element) {
    let data = [];
    element.forEach(abc => {
      data.push({ id: abc._id, areaName: abc.location.areaName });
      this.areaListArr.push(abc);
    });
    // console.log('areaArr', this.areaListArr);
    return data;
  }
  // function on a particular city selected from dropdown
  onSelectCity(val) {
    console.log('selectedCity', val);
    this.selectedAreaArr = val.areaArr;
    this.addAddressForm.controls.area.setValue('');
    this.addAddressForm.controls.area.updateValueAndValidity();
  }
  // function on selecting an area
  onSelectArea(val) {
    console.log('selectedArea', val);
    this.selectedArea = val;
    this.addAddressForm.controls.area.setValue(val);
    this.addAddressForm.controls.area.updateValueAndValidity();
  }
  // function to detect current user location
  findMe() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        console.log(position);
        this.addAddressForm.controls.lat.setValue(position.coords.latitude);
        this.addAddressForm.controls.long.setValue(position.coords.longitude);
        this.getUserAddress(position.coords.latitude, position.coords.longitude);
        // this.locate();
      });
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  }

  // function to get user formatted address using lat, long
  getUserAddress(lat, long) {
    // const xhttp = new XMLHttpRequest();
    // xhttp.onreadystatechange = () => {
    //   if (xhttp.readyState === 4 && xhttp.status === 200) {
    //     const address = JSON.parse(xhttp.responseText);
    //     this.addAddressForm.controls.flat.setValue(address.results[0].formatted_address);
    //     console.log('formattedUserAddress', address.results[0].formatted_address);
    //   }
    // };
    // xhttp.open('GET', this.mapApiUrl + 'latlng=' + lat + ',' + long + '&key=' + this.apiKey, true);
    // xhttp.send();

    this.apiloader.load().then(() => {
      let geocoder = new google.maps.Geocoder;
      let latlng = {
          lat: lat,
          lng: long
      };
      geocoder.geocode({
          'location': latlng
      }, (results) => {
          if (results[0]) {
              this.addAddressForm.controls.flat.setValue(results[0].formatted_address);
              console.log(results[0].formatted_address);
          } else {
              console.log('Not found');
          }
      });
  });
  }

  getGeocodeOnManualInputAddress() {
    const userAdd = this.addAddressForm.controls.flat.value;
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = () => {
      if (xhttp.readyState === 4 && xhttp.status === 200) {
        const latLng = JSON.parse(xhttp.responseText);
        console.log('adddress', latLng.results[0].geometry.location);
        this.addAddressForm.controls.lat.setValue(latLng.results[0].geometry.location.lat);
        this.addAddressForm.controls.long.setValue(latLng.results[0].geometry.location.lng);
      }
    };
    xhttp.open('GET', this.mapApiUrl + 'address=' + userAdd + '&components=country:IN&key=' + this.apiKey, true);
    xhttp.send();
  }

  enableToCheckLatLng() {
    this.getGeocodeOnManualInputAddress();
  }

  // function to open golabl dialog
  openDialog() {
    // console.log('tableData', selectedMerchant);
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '600px',
      height: 'auto',
      disableClose: true,
      data: {type: 'checkAdd'}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result !== undefined) {

      }
    });
  }

  // function to open golabl dialog for change address
  openDialog2() {
    // console.log('tableData', selectedMerchant);
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '600px',
      height: '450px',
      disableClose: true,
      data: {type: 'ADDRESS'}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result !== undefined) {
        // this.activateAddressForm = false;
        // this.activateCustomerForm = true;
        if (result && result.address !== '') {
          this.addAddressForm.controls.flat.setValue(result.address);
          this.addAddressForm.controls.lat.setValue(result.lat);
          this.addAddressForm.controls.long.setValue(result.lng);
        }
      }
    });
  }

}
