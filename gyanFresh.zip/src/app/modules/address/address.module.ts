import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddressListComponent } from './component/address-list/address-list.component';
import { AddAddressComponent } from './component/add-address/add-address.component';
import { EditAddressComponent } from './component/edit-address/edit-address.component';
import { AddressService } from './serviceFile/address.service';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatSelectModule} from '@angular/material/select';
import {MatRadioModule} from '@angular/material/radio';

export const routes: Routes = [
  { path: '', component: AddressListComponent, pathMatch: 'full' },
  { path: 'edit/:id', component: EditAddressComponent },
  { path: 'newAddress', component: AddAddressComponent }
];


@NgModule({
  declarations: [AddressListComponent, AddAddressComponent, EditAddressComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatRadioModule
  ],
  exports: [AddressListComponent, AddAddressComponent, EditAddressComponent],
  providers: [AddressService]
})
export class AddressModule { }
