import { Component, OnDestroy, OnInit } from '@angular/core';
import { ClipboardService, IClipboardResponse } from 'ngx-clipboard';
import { CommonService } from 'src/app/serviceFile/common.service';
import { HomeService } from 'src/app/modules/home/serviceFile/home.service';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { MatDialog } from '@angular/material/dialog';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';
import { Router } from '@angular/router';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { Subscription } from 'rxjs';

declare let clevertap: any;

@Component({
  selector: 'app-refer-friend',
  templateUrl: './refer-friend.component.html',
  styleUrls: ['./refer-friend.component.scss']
})
export class ReferFriendComponent implements OnInit, OnDestroy {
  referralCode = localStorage.getItem('gyanReferralCode');
  inviteLink = 'https://gyanfresh.gyandairy.com/#/register';
  // inviteText = 'Hi, I\'m using gyan fresh app for online order of dairy products. You can also join by clicking the link ' +
  //   this.inviteLink + ' and get assured gyan star by using my referral code while signing up. Referral. Code: ' + this.referralCode;
  // inviteText = `${this.inviteLink} Use this Referral Code: ${this.referralCode}`;
  // inviteText = `Hey! I use Gyan Fresh to order daily essentials for my day. They have 0 delivery charge and no minimum order value. Items are super fresh and service is extremely reliable. Use my referral code : ${this.referralCode} to get Rs. 50 Bonus. Also get 1 week of free milk as a rewards when you subscribe for milk. ${this.inviteLink}`;
  inviteText = `Hey! I use Gyan Fresh to order daily essentials for my day. They have 0 delivery charge and no minimum order value. Items are super fresh and service is extremely reliable . Use my referral code ${this.referralCode} https://gyandairycustomer.page.link/jdF1`;
  // Hey! I use Gyan Fresh to order daily essentials for my day.They have 0 delivery charge and no minimum order value.Items are super fresh and service is extremely reliable.Use my referral code AHHDBSHFIR to get Rs. 50 Bonus.Also get 1 week of free milk as a rewards when you subscribe for milk.https://gyandairycustomer.page.link/jdF1
    referralAmount = 0;
referralMsg = '';
totalEarning = 0;
showCode = false;
offset = 0;
limit = 10;
redeemedArr = [];
pendingArr = [];
tab = 1;
showRedeemedPanel = false;
homeSubs$: Subscription;
minimumRechargeAmountToGetReferralCode = 0;

constructor(private _clipboardService: ClipboardService, private commonService: CommonService, private homeService: HomeService,
  private fireAnalytics: FirebaseAnalyticsCustomService, public dialog: MatDialog, private router: Router, private sharedService: SharedService) {
  this._clipboardService.configure({ cleanUpAfterCopy: true });
}

ngOnInit(): void {
  const val = localStorage.getItem('isRef');
  if(val === '0') {
  this.router.navigate(['/']);
} else {
  this.checkRechargeAmount();
  this.getReferralAmount();
  this.handleClipboardResponse();
  this.getReferrals();
  this.getHomeData();
  clevertap.event.push('Referral checked', {
    "platform": localStorage.getItem('deviceType')
  });
}
  }

ngOnDestroy(): void {
  try {
    this.homeSubs$.unsubscribe();
  } catch (error) {
    console.log(error);
  }
}

// function to copy invite link to clipboard
handleClipboardResponse() {
  this._clipboardService.copyResponse$.subscribe((res: IClipboardResponse) => {
    if (res.isSuccess) {
      this.commonService.showSuccess('Invite link copied');
      try {
        clevertap.event.push(app_strings.CUSTOME.REFERRAL, {
          "platform": localStorage.getItem('deviceType')
        });
        clevertap.event.push('referal copied', {
          "platform": localStorage.getItem('deviceType')
        });
        this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.REFERRAL);
      } catch (error) {
        console.log(error);
      }
    }
  });

}

// function to check recharge amount for referral code
checkRechargeAmount() {
  const obj = {
    amount: 0
  }
  this.homeService.checkRechargeAmount(obj).subscribe(res => {
    if (res && res.status === 200) {
      const val = res.data.hasrecharged;
      if (val) {
        this.showCode = true;
      } else {
        this.showCode = false;
      }
    }
  })
}

// function to get referral amount
getReferralAmount() {
  this.homeService.getReferralMoney().subscribe(res => {
    this.referralAmount = res.data.toAmount;
    this.referralMsg = res.data.message;
    this.totalEarning = res.data.totalEaring;
  });
}

openDialog() {
  const dialogRef = this.dialog.open(GlobalDialogComponent, {
    width: '600px',
    height: 'auto',
    disableClose: false,
    data: { type: 'howIT' }
  });
}

getReferrals() {
  const obj = {
    limit: this.limit,
    offset: this.offset
  }
  this.homeService.getReferrals(obj).subscribe(res => {
    if (res && res.status === 200) {
      console.log('>>>>>', res.data);
      this.redeemedArr = res.data.redemed;
      this.pendingArr = res.data.pending;
    }
  })
}

onScrollRedeemed() {
  console.log('redeemed scroll');

  if (this.redeemedArr.length > 10 && this.redeemedArr.length % 2 !== 0) {
    this.offset = this.offset + 10;
    this.getReferrals();
  }
}

onScrollPending() {
  console.log('pending scroll');

  if (this.pendingArr.length > 10 && this.pendingArr.length % 2 !== 0) {
    this.offset = this.offset + 10;
    this.getReferrals();
  }
}

// function to get home data
getHomeData() {
  this.sharedService.fetchUserHome();
  this.homeSubs$ = this.sharedService.homeData$.subscribe(response => {
    if (response && response.status === 200) {
      this.minimumRechargeAmountToGetReferralCode = response.data.appVersion.minmumAmoutToshare;
    }
  });
}

}
