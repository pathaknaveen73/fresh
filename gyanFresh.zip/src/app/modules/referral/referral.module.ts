import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReferFriendComponent } from './component/refer-friend/refer-friend.component';
import { Routes, RouterModule } from '@angular/router';
import { ClipboardModule } from 'ngx-clipboard';
import { HomeService } from '../home/serviceFile/home.service';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

export const routes: Routes = [
  { path: '', component: ReferFriendComponent, pathMatch: 'full' }
];

@NgModule({
  declarations: [ReferFriendComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ClipboardModule,
    InfiniteScrollModule
  ],
  exports: [ReferFriendComponent],
  providers: [HomeService]
})
export class ReferralModule { }
