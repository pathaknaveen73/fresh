import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeListComponent } from './component/home-list/home-list.component';
import { Routes, RouterModule } from '@angular/router';
import { HomeService } from './serviceFile/home.service';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { ClipboardModule } from 'ngx-clipboard';
import { SkeletonModule } from '../skeleton/skeleton.module';

export const route: Routes = [
  { path: '', component: HomeListComponent },
  { path: '', redirectTo: '', pathMatch: 'full' }
];


@NgModule({
  declarations: [HomeListComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(route),
    LazyLoadImageModule,
    CarouselModule,
    ClipboardModule,
    SkeletonModule
  ],
  providers: [HomeService]
})
export class HomeModule { }
