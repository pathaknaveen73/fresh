import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { HomeService } from '../../serviceFile/home.service';
import { Router } from '@angular/router';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { CommonService } from 'src/app/serviceFile/common.service';
import { ClipboardService, IClipboardResponse } from 'ngx-clipboard';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { Subscription } from 'rxjs';
import { BuyOnceService } from 'src/app/serviceFile/buyOnce.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
declare let $: any;
declare var clevertap: any;

@Component({
  selector: 'app-home-list',
  templateUrl: './home-list.component.html',
  styleUrls: ['./home-list.component.scss']
})
export class HomeListComponent implements OnInit, OnDestroy {
  // productCategoriesArr;
  // productVariantsArr;
  offerListArr;
  // previousIdVal = 0;
  productCategoryId;
  homeProductVariantLength = 6;
  loadMoreBtnFlag = true;
  loadMoreBtnCount = 1;
  offerArrived = false;
  referralCode = localStorage.getItem('gyanReferralCode');
  inviteLink = 'https://gyanfresh.gyandairy.com/#/register';
  // inviteText = 'Hi, I\'m using gyan fresh app for online order of dairy products. You can also join by clicking the link ' +
  //   this.inviteLink + ' and get assured gyan star by using my referral code while signing up. Referral. Code: ' + this.referralCode;
  // inviteText = `${this.inviteLink} Use this Referral Code: ${this.referralCode}`;
  // inviteText = `Hey! I use Gyan Fresh to order daily essentials for my day. They have 0 delivery charge and no minimum order value. Items are super fresh and service is extremely reliable. Use my referral code : ${this.referralCode} to get Rs. 50 Bonus. Also get 1 week of free milk as a rewards when you subscribe for milk. ${this.inviteLink}`;
  inviteText = `Hey! I use Gyan Fresh to order daily essentials for my day. They have 0 delivery charge and no minimum order value. Items are super fresh and service is extremely reliable . Use my referral code ${this.referralCode} https://gyandairycustomer.page.link/jdF1`;
  customOptions: OwlOptions = {
    loop: false,
    margin: 0,
    center: false,
    nav: true,
    dots: false,
    autoWidth: false,
   // navText: ['<i class="fa fa-angle-left" aria-hidden="true"></i>', '<i class="fa fa-angle-right" aria-hidden="true"></i>'],
    responsive: {
      0: {
        items: 2
      },
      600: {
        items: 2
      },
      1023: {
        items: 4
      },
      1170: {
        items: 4
      }
    }
  };
  productCategoriesArr;
  productVariantsArr;
  productArr;
  offerArr;
  bannerArr;
  previousIdVal;
  selectedVal = '0';
  isDragging: boolean;
  limit = 6;
  offset = 0;
  selectedCat;
  showLoadMore = true;
  walletNeededBal;
  walletAvailableBal;
  isRef = false;
  referralAmount = 0;
  referralMsg = '';
  placeholderImg = app_strings.PLACEHOLDER_IMAGE;
  firstLoad = true;
  bannerOptions: OwlOptions = {
      nav: false,
      loop: true,
      margin: 10,
      dots: true,
      autoplay: true,
      mouseDrag: true,
      responsive: {
        0: {
          items: 1
         },
        600: {
          items: 1
        },
        1000: {
          items: 1
        },
        1200: {
          items: 1
        }
      }
  };
//   bannerOptionsDemo: OwlOptions = {
//     nav: false,
//     loop: false,
//     margin: 10,
//     dots: true,
//     autoplay: false,
//     responsive: {
//       0: {
//         items: 1
//        },
//       600: {
//         items: 1
//       },
//       1000: {
//         items: 1
//       },
//       1200: {
//         items: 1
//       }
//     }
// };
  bannerArrDemo = [];
  productLoadedFlag = false;
  showMoreLoadingFlag = false;
  productVariant$: Subscription;
  showReferralCode = false;
  homeSubs$: Subscription;
  isLowBalance = false;
  wallet$: Subscription;
  minimumRechargeAmountToGetReferralCode = 0;
  constructor(private homeService: HomeService, private router: Router, private commonService: CommonService,
              private _clipboardService: ClipboardService, private buyService: BuyOnceService, private sharedService: SharedService,
              private fireAnalytics: FirebaseAnalyticsCustomService) {
                this._clipboardService.configure({ cleanUpAfterCopy: true });
              }

  ngOnInit(): void {
    const reload = localStorage.getItem('gyanReload');
    if (reload && reload === '1') {
      localStorage.removeItem('gyanReload');
      window.location.reload();
    }
    this.wallet$ = this.sharedService.walletData$.subscribe(res => {
      if (res) {
        this.walletAvailableBal = res.walletAmount;
      }
    });
    for (let i = 1; i < 5; i++) {
      this.bannerArrDemo.push({
        id: i,
        webThumbnail: this.placeholderImg,
        webImage: this.placeholderImg,
        bannerType: 'INFORMATIVE'
      });
    }
    // $('.owl-carousel').owlCarousel({
    //   nav: true,
    //   loop: true,
    //   margin: 10,
    //   dots: false,
    //   autoplay: true,
    //   responsive: {
    //     0: {
    //       items: 1
    //     },
    //     600: {
    //       items: 1
    //     },
    //     800: {
    //       items: 1
    //     },
    //     1000: {
    //       items: 1
    //     },
    //     1200: {
    //       items: 1
    //     }
    //   }
    // });

    // this.productCategroies();
    // this.getOffersList();
    this.handleClipboardResponse();
    this.getHomeData();
    // this.getNewBannerList();
    // this.getWalletBalance();

    // debugger
    clevertap.event.push(app_strings.CT_APP_HOME_VIEW, {
      "platform": localStorage.getItem('deviceType')
    });
    this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.HOME_SCREEN_VIEWED);
  }

  getWalletBalance() {
    this.commonService.showSpinner();
    this.homeService.getWalletBalance().subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.hideSpinner();
        this.walletAvailableBal = res.data.walletAmount.walletAmount;
      }
    }, error => {
      this.commonService.hideSpinner();
      this.commonService.showError(error);
    });
  }

  // function on destroy of the component
  ngOnDestroy(): void {
    try {
      this.productVariant$.unsubscribe();
      this.homeSubs$.unsubscribe();
      this.wallet$.unsubscribe();
    } catch (error) {
      console.log(error);
    }
  }

  // function to get product categories
  // productCategroies() {
  //   const payload = {
  //     offset: 0,
  //     limit: 8
  //   };
  //   this.homeService.getProductCat(payload).subscribe(response => {
  //     this.productCategoriesArr = response.data;
  //     // this.variantLabel = this.productCategoriesArr[0].categoryName;
  //     console.log('productCategoriesArr', this.productCategoriesArr);
  //     this.productCategoryId = this.productCategoriesArr[0]._id;
  //     const productId = this.productCategoriesArr[0]._id;
  //     const offset = 0;
  //     const limit = 6;
  //     const nameOfItem = '';
  //     this.productVariant(productId, offset, limit, nameOfItem);
  //   });
  // }
  // function to get product variants on first load
  // productVariant(id: number, offsetVal: number, limitVal: number, nameOfItem: string) {
  //   const payload = {
  //     productId: id,
  //     offset: offsetVal,
  //     limit: limitVal,
  //     itemName: nameOfItem
  //   };
  //   this.homeService.getProductVariant(payload).subscribe(response => {
  //     this.productVariantsArr = response.data;
  //     $('#homeProductCat0').addClass('active');
  //     console.log('productDetailArr', this.productVariantsArr);
  //   });
  // }
  // function to get product variant on user input
  // getProductVariant(product, i) {
  //   console.log('product', product);
  //   if (this.productVariantsArr.length > 0 && this.productVariantsArr[0].categoryId === product._id) {
  //     return;
  //   }
  //   $('#homeProductCat' + this.previousIdVal).removeClass('active');
  //   $('#homeProductCat' + i).addClass('active');
  //   this.previousIdVal = i;
  //   this.productCategoryId = product._id;
  //   const payload = {
  //     productId: product._id,
  //     offset: 0,
  //     limit: 6,
  //     itemName: ''
  //   };
  //   this.homeService.getProductVariant(payload).subscribe(response => {
  //     if (response.status === 200) {
  //       this.productVariantsArr = response.data;
  //     } else {
  //       this.commonService.showError(response.message);
  //     }
  //   });
  // }

  // function to open product detail
  openProductDetail(item) {
    // console.log('productDetail', item);
    // this.router.navigateByUrl('/page/product/list/' + item._id);
    this.router.navigate(['/page/product/list/detail'], { queryParams: { id: item._id } });
  }

  // function to get offers list
  getOffersList() {
    this.homeService.getOffers().subscribe(response => {
      if (response.status === 200) {
        this.offerListArr = response.data;
        this.offerArrived = true;
        // response.data.forEach(element => {
        //   this.offerListArr.push(element)
        // });
        console.log('offerListArr', this.offerListArr);
      }
    });
  }

  // function to open offer detail
  openOfferDetail(offerId) {
    this.router.navigate(['page/offers/' + offerId]);
  }

  // function to load more product variants
  // loadMore() {
  //   if (this.loadMoreBtnCount >= 2) {
  //     this.router.navigate(['page/product']);
  //     console.log('countLoadMore', this.loadMoreBtnCount);
  //     return;
  //   }
  //   const payload = {
  //     productId: this.productCategoryId,
  //     offset: 6,
  //     limit: 12,
  //     itemName: ''
  //   };
  //   this.homeService.getProductVariant(payload).subscribe(response => {
  //     if (response.status === 200) {
  //       const variantArr = response.data;
  //       if (variantArr && variantArr.length > 0) {
  //         variantArr.forEach(element => {
  //           this.productVariantsArr.push(element);
  //         });
  //       } else {
  //         this.loadMoreBtnFlag = false;
  //       }
  //       this.homeProductVariantLength = this.productVariantsArr.length;
  //       this.loadMoreBtnCount += 1;
  //     } else {
  //       this.commonService.showError(response.message);
  //     }
  //   });
  // }

  // function to copy invite link to clipboard
  handleClipboardResponse() {
    this._clipboardService.copyResponse$.subscribe((res: IClipboardResponse) => {
      if (res.isSuccess) {
        this.commonService.showSuccess('Invite link copied');
        try {
          // clevertap.event.push(app_strings.CUSTOME.REFERRAL, {
          //   "platform": localStorage.getItem('deviceType')
          // });
          // this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.REFERRAL);
          clevertap.event.push('referal copied', {
            "platform": localStorage.getItem('deviceType')
          });
        } catch (error) {
          console.log(error);
        }
      }
    });

  }

  // function to get home data
  getHomeData() {
    this.sharedService.fetchUserHome();
    this.homeSubs$ = this.sharedService.homeData$.subscribe(response => {
      if (response && response.status === 200) {
        this.minimumRechargeAmountToGetReferralCode = response.data.appVersion.minmumAmoutToshare;
        this.offerArr = response.data.offers;
        this.productArr = response.data.categories;
        this.bannerArr = response.data.banners;
        this.bannerArrDemo.length = 0;
        this.getProductVariant(this.productArr[0]);
        this.selectedCat = this.productArr[0];
        this.selectedVal = this.productArr[0]._id;
        this.getNewBannerList();
        // this.walletBalance = response.data.userWalletAndStarBalance.walletAmount;
        if (response.data.isLowBalanceString === 'ACTIVE') {
          this.isLowBalance = true;
        }
        // localStorage.setItem('crone', JSON.stringify(response.data.orderCronTiming));
        if (response.data.customerReferral.status === 'ACTIVE') {
          // localStorage.setItem('isRef', '1');
          // this.sharedService.saveReferralStatusLocal('1');
          this.isRef = true;
          this.getReferralAmount();
          this.checkRechargeAmount();
        } else {
          // localStorage.setItem('isRef', '0');
          // this.sharedService.saveReferralStatusLocal('0');
          this.isRef = false;
        }
        if (response.data.displayOfferStatus.status === 'ACTIVE') {
          // localStorage.setItem('isRef', '1');
          // this.sharedService.saveOfferStatusLocal('1');
          // this.isRef = true;
          this.getOffersList();
        } else {
          // localStorage.setItem('isRef', '0');
          // this.sharedService.saveOfferStatusLocal('0');
          // this.isRef = false;
        }
        // this.sharedService.saveStarStatus(response.data.gyanStarStatus.status);
        // if (response.data.retrackPayment) {
        //   this.razorpayPaymentStatus();
        // }
      }
    });
  }

  // function to check recharge amount for referral code
  checkRechargeAmount() {
    const obj = {
      amount: 0
    }
    this.homeService.checkRechargeAmount(obj).subscribe(res => {
      if (res && res.status === 200) {
        const val = res.data.hasrecharged;
        if (val) {
          this.showReferralCode = true;
        } else {
          this.showReferralCode = false;
        }
      }
    })
  }

  // function to get referral amount
  getReferralAmount() {
    this.homeService.getReferralMoney().subscribe(res => {
      this.referralAmount = res.data.toAmount;
      this.referralMsg = res.data.message;
    });
  }

  // function to hit retrack razor payment api
  razorpayPaymentStatus() {
    this.homeService.razorPayPaymentStatus().subscribe(res => {
      console.log('razorpayPaymentStatus', res);
    });
  }

  // function to get product variant
  getProductVariant(item, condition?, categoryId?: string) {
    if (!categoryId && !this.firstLoad) {
      clevertap.event.push(app_strings.CT_CATEGORY_CHECKED, {
        'Category Name': item.categoryName,
        'date': new Date(),
        "platform": localStorage.getItem('deviceType')
      });
      this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.CATEGORY_VIEWED, {
        'Category Name': item.categoryName,
        'date': new Date(),
      });
      this.fireAnalytics.logFacebookPixelEvent(app_strings.FACEBOOK_PIXEL.PRODUCT_CATEGORY);
      this.fireAnalytics.logGoogleAnalyticsEvent(app_strings.GOOGLE_ANALYTICS.PRODUCT_CATEGORY);
    }
    const ob = {
      catId: categoryId ? categoryId : item._id,
      limit: this.limit,
      offset: this.offset
    }
    this.productVariant$ = this.homeService.getProducts(ob).subscribe(res => {
      if (res && res.status === 200) {
        this.firstLoad = false;
        this.productLoadedFlag = true;
        this.showMoreLoadingFlag = false;
        if (!categoryId && condition) {
          const result = [] = res.data;
          result.forEach(element => {
            this.productVariantsArr.push(element);
          });
          // this.productVariantsArr.push(res.data);
        } else {
          // this.productVariantsArr = [];
          this.productVariantsArr = res.data;
        }
        if (res.data?.length !== 6) {
          this.showLoadMore = false;
        } else {
          this.showLoadMore = true;
        }
        // console.log('productsVariantsArr', this.productVariantsArr);
      }
    })
  }

  subscribeProduct(item, type: number) {
    this.router.navigate(['/page/product/list/' + item._id + '/subscribe'], { queryParams: { data: JSON.stringify(item), type: type } });
  }

  // buyOnce(item) {
  //   this.commonService.showSpinner();
  //   this.buyService.setFormField(item, 1, new Date(), { editFlag: false, editVal: [] });
  // }

  buyOnce(item, counterVal?: any, index?: any) {
    if (!counterVal && this.walletAvailableBal < item.price) {
      this.walletNeededBal = item.price - this.walletAvailableBal;
      $('#myModal1').modal('show');
    } else if (counterVal && counterVal > 0 && this.walletAvailableBal < item.price) {
      this.walletNeededBal = item.price - this.walletAvailableBal;
      $('#myModal1').modal('show');
    } else {
      this.commonService.showSpinner();
      this.buyService.setFormField(item, counterVal ? counterVal : 1, new Date(),
      { editFlag: false, editVal: [], alreadySubscribe: counterVal ? true : false })
      .then(res => {
        if (counterVal) {
          // this.productVariantsArr[index].subscriptions.weeklyData[0].qty += counterVal;
          this.offset = 0;
          this.productLoadedFlag = false;
          this.productVariantsArr = [];
          this.getProductVariant('', '', this.selectedVal);
        } else {
          $('#buyOnceModal').modal('show');
          // this.getHomeData();
          this.offset = 0;
          this.productLoadedFlag = false;
          this.productVariantsArr = [];
          this.getProductVariant('', '', this.selectedVal);
        }
      });
    }
  }

  closeLessBalModal() {
    $('#myModal1').modal('hide');
  }

  // function to navigate to stripe checkout if wallet bal is below order total amount
  navigateToAddMoney() {
    $('#myModal1').modal('hide');
    const payload = {
      amount: this.walletNeededBal,
      currency: 'inr'
    };
    this.router.navigate(['page/wallet/addMoney'], { queryParams: { amount: this.walletNeededBal } });
  }

  counterLogic(type: string, item, i) {
    if (type === 'MINUS') {
      if (item.subscriptions.weeklyData[0].qty === 1) {
        // return;
        this.buyOnce(item, -1, i);
      } else {
        // this.quantity -= 1;
        this.buyOnce(item, -1, i);
      }
    } else {
      // this.quantity += 1;
      if (item.subscriptions.weeklyData[0].qty >= 10) {
        return;
      }
      this.buyOnce(item, +1, i);
    }
  }

  offerProductBuy(item) {
    if (this.walletAvailableBal < item.price) {
      this.walletNeededBal = item.price - this.walletAvailableBal;
      $('#myModal1').modal('show');
    } else {
      this.commonService.showSpinner();
      this.commonService.openDialog('productOffer', false, item).subscribe( response => {
        if (response && response !=='skip') {
          this.buyService.setFormField(item, 1, new Date(),
            { editFlag: false, editVal: [], alreadySubscribe: false }, 'productOffer', response)
            .then(res => {
              $('#buyOnceModal').modal('show');
              // this.getHomeData();
              this.offset = 0;
              this.productLoadedFlag = false;
              this.productVariantsArr = [];
              this.getProductVariant('', '', item.categoryId._id);
            });
        } else if (response === 'skip') {
          this.buyOnce(item);
        }
      });
    }
  }

  offerProductSubscribe(item, type) {
    this.commonService.showSpinner();
    this.homeService.getWalletBalance().subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.hideSpinner();
        this.walletAvailableBal = res.data.walletAmount.walletAmount;
        // this.walletAvailableBal = 10
        if (this.walletAvailableBal < item.price) {
          this.walletNeededBal = item.price - this.walletAvailableBal;
          $('#myModal1').modal('show');
        } else {
          this.commonService.showSpinner();
          this.commonService.openDialog('productOffer', false, item).subscribe( response => {
            if (response && response !=='skip') {
              this.router.navigate(['/page/product/list/' + item._id + '/subscribe'], { queryParams: { data: JSON.stringify(item), type: type, offer: JSON.stringify(response) } });
            } else if (response === 'skip') {
              this.subscribeProduct(item, type);
            }
          });
        }
      } else {
        this.commonService.hideSpinner();
        this.commonService.showError(res.message);
      }
    });

  }

  handleProductCategoryBannerClick(val) {
    console.log('checkDragging', val);
    // this.animatethis(val, 5000);
    // this.selectedVal = val;
    $('html, body').animate({
      scrollTop: $('#ourProduct').offset().top + -100
  }, 1000);
    // $('.product_list_wraper ul').scrollTo('#' + val);
    if (val !== this.selectedVal) {
      $('.product_list_wraper').animate({scrollLeft: $('#' + val).position().left}, 500);
      this.getProductVariant('', '', val);
    }
    this.selectedVal = val;
  }

 animatethis(targetElement, speed) {
    const scrollWidth = $(targetElement).get(0).scrollWidth;
    const clientWidth = $(targetElement).get(0).clientWidth;
    $(targetElement).animate({ scrollLeft: scrollWidth - clientWidth },
    {
        duration: speed,
        complete: function () {
            targetElement.animate({ scrollLeft: 0 },
            {
                duration: speed,
                complete:  () => {
                  this.getProductVariant('', '', targetElement);
                }
            });
        }
    });
  }

  getNewBannerList() {
    const userId = localStorage.getItem('user_idGyan');
    this.homeService.getNewBanner(userId).subscribe(res => {
      if (res && res.status === 200) {
        console.log('checkNewBanner', res);
        if (res && res.data && res.data.length) {
          this.bannerArr = [];
          this.bannerArr = res.data;
        }
      }
    });
  }
}
