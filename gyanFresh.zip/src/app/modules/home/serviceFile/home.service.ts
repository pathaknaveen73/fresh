import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class HomeService {

  constructor(private apiService: ApiService) { }


  // function to get product categories
  getProductCat(payload) {
    const url = 'categories?offset=' + payload.offset + '&limit=' + payload.limit;
    return this.apiService.getApi(url);
  }

  // function to get product variant
  getProductVariant(payload) {
    const url = 'products/' + payload.productId + '?offset=' + payload.offset + '&limit=' + payload.limit + '&itemName=' + payload.itemName;
    return this.apiService.getApi(url);
  }

  // function to fetch offers list
  getOffers() {
    const url = 'offerList';
    return this.apiService.getApi(url);
  }

  // function to get products and offer for home before login screen
  getHomeData() {
    const url = 'v2/userAppHome';
    return this.apiService.getApi(url);
  }

  getProducts(payload) {
    const url = `products/${payload.catId}?offset=${payload.offset}&limit=${payload.limit}&itemName=`;
    return this.apiService.getApi(url);
  }

  // function to get auto recharge detail
  getWalletBalance() {
    const url = 'getAutoRechargeDetail';
    return this.apiService.getApi(url);
  }

  // function to track razorpay payment status if retrackPayment key in userAppHome api is found true only.
  razorPayPaymentStatus() {
    const url = 'razorpayPaymentStatus';
    return this.apiService.getApi(url);
  }
  // function to fetch referral amount
  getReferralMoney() {
    const url = 'getShareRefferralPoint';
    return this.apiService.getApi(url);
  }

  checkRechargeAmount(obj) {
    const url = 'checkrechargebyamount';
    return this.apiService.postApi(url, obj);
  }

  getReferrals(obj) {
    const url = `refrrals?offset=${obj.offset}&limit=${obj.limit}`;
    return this.apiService.getApi(url);
  }

  // function to fetch new specific banner
  getNewBanner(userId) {
    const url = `getBanners?userId=${userId}`;
    return this.apiService.getApi(url);
  }
}
