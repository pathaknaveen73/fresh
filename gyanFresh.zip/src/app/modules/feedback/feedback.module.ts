import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SendFeedbackComponent } from './component/send-feedback/send-feedback.component';
import { Routes, RouterModule } from '@angular/router';
import { FeedbackService } from './serviceFile/feedback.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatSelectModule} from '@angular/material/select';

export const routes: Routes = [
  { path: '', component: SendFeedbackComponent, pathMatch: 'full' }
];

@NgModule({
  declarations: [SendFeedbackComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule
  ],
  exports: [SendFeedbackComponent],
  providers: [FeedbackService]
})
export class FeedbackModule { }
