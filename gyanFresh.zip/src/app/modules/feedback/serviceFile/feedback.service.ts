import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class FeedbackService {

  constructor(private apiService: ApiService) { }

  // function to get suggestion dropdown data
  getSuggestionData() {
    const url = 'feedbackSugestions';
    return this.apiService.getApi(url);
  }

  // function to send feedback form data
  sendFeedback(formData) {
    const url = 'sendFeedback';
    return this.apiService.postApi(url, formData);
  }
}
