import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FeedbackService } from '../../serviceFile/feedback.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/serviceFile/common.service';
declare let $: any;

@Component({
  selector: 'app-send-feedback',
  templateUrl: './send-feedback.component.html',
  styleUrls: ['./send-feedback.component.scss']
})
export class SendFeedbackComponent implements OnInit {
  suggestionListArr;
  sendFeedbackForm: FormGroup;
  submitted = false;
  selectedSuggestion;
  imageSelected = false;
  imageUrl;

  constructor(private router: Router, private feedbackService: FeedbackService, private fb: FormBuilder, private commonService: CommonService) { }

  ngOnInit(): void {
    function readname(input) {
      alert();
      var input1 = event.srcElement;
      var fileName = input.files[0].name;
      $(input1).parents('.uploadfilewr').find('label.uploadfile').text([0]['innerText'] = fileName);
      //  input.parentElement.getElementsByTagName("label.uploadfile")[0].innerText = fileName;
    }
    this.getSuggestionList();
    this.setFormField();
  }

  // function to fetch suggestion dropdown list
  getSuggestionList() {
    this.feedbackService.getSuggestionData().subscribe(response => {
      if (response.status === 200) {
        this.suggestionListArr = response.data;
        this.selectedSuggestion = this.suggestionListArr[0]._id;
        console.log('suggestionList', this.suggestionListArr);
      }
    });
  }

  // function to set form field for send feedback form
  setFormField() {
    this.sendFeedbackForm = this.fb.group({
      selectSuggestion: ['', [Validators.required]],
      message: ['', [Validators.required]],
      photo: [''],
      photoToSend: [''],
      email: ['', Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]
    });
  }

  // function to get form controls
  get f() { return this.sendFeedbackForm.controls; }

  // function to submit form data
  submitFeedbackForm() {
    this.submitted = true;
    if (!this.sendFeedbackForm.valid) {
      console.log('notValidFeedbackForm', this.sendFeedbackForm.controls);
      return;
    }
    // const formData = new FormData();
    // formData.append('files', this.sendFeedbackForm.controls.photoToSend.value);
    // formData.append('suggestion', this.sendFeedbackForm.controls.selectSuggestion.value);
    // formData.append('description', this.sendFeedbackForm.controls.message.value);
    // if (!formData.get('files')) {
    //   formData.delete('files');
    // }
    const val: any = {
      suggestion: this.sendFeedbackForm.controls.selectSuggestion.value,
      description: this.sendFeedbackForm.controls.message.value
    };
    if (this.f.email.value) {
      val.email = this.f.email.value;
    } else {
      val.email = '';
    }
    const fd = new FormData();

    for (let property in val) {
      fd.append(property, val[property]);
    };
    if (this.imageUrl) {
      fd.append('files', this.sendFeedbackForm.controls.photoToSend.value);
    }
    if (!fd.get('files')) {
      fd.delete('files');
    }
    if (fd.get('files') == '10') {
      fd.delete('files');
    }
    // console.log('checkFD', val);
    // return;

    this.commonService.showSpinner();
    this.feedbackService.sendFeedback(fd).subscribe(response => {
        if (response.status === 200) {
          this.commonService.hideSpinner();
          this.commonService.showSuccess('Feedback Submitted');
          this.router.navigate(['page/home']);
        } else {
          this.commonService.showError(response.message);
        }
      });
  }

  // function on image select
  onImageSelect(event) {
    if (event.target.files.length > 0) {
      this.sendFeedbackForm.get('photoToSend').setValue(event.target.files[0]);
      let reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (_event) => {
        this.imageUrl = reader.result;
        this.imageSelected = true;
        // $('#companyLogo').attr('src', imgURL);
      };
    }
  }

  // function to remove photo
  removePhoto() {
    // value 10 means to remove photo and send blank image
    this.sendFeedbackForm.controls.photoToSend.setValue(10);
    this.imageSelected = false;
    this.imageUrl = undefined;
  }

}
