import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from '../../serviceFile/product.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/serviceFile/common.service';

@Component({
  selector: 'app-edit-cart',
  templateUrl: './edit-cart.component.html',
  styleUrls: ['./edit-cart.component.scss']
})
export class EditCartComponent implements OnInit {
  today = new Date();
  timeSlotsArr;
  addCartForm: FormGroup;
  submitted: boolean = false;
  id;
  addedToCartFlag: boolean = false;
  data;
  selectedTimeSlot;
  productDetailObj;

  constructor(private productService: ProductService, private fb: FormBuilder, private route: ActivatedRoute, private router: Router,
              private commonService: CommonService) {
    this.today.setDate(this.today.getDate() + 1);
}

  ngOnInit(): void {
    if (!history.state.data) {
      this.router.navigate(['page/cart']);
    }
    this.data = history.state.data;
    console.log('urlParameter', this.data);
    this.id = this.route.snapshot.paramMap.get('id');
    this.getTimeSlots();
    this.setFormField();
  }

  // function to get product detail
  productDetail(id) {
    this.productService.getProductDetail(id).subscribe(response => {
      this.productDetailObj = response.data;
      console.log('productDetails', this.productDetailObj);
    });
  }

  getTimeSlots() {
    this.productService.getTimeSlot().subscribe(response => {
      this.timeSlotsArr = response && response.data ? response.data : '';
      this.timeSlotsArr.forEach(element => {
        element.timeFrame = element.from + ' - ' + element.to;
      });
      if (this.data) {
        this.timeSlotsArr.forEach(element => {
          if ((element.from === this.data.startTime) && (element.to === this.data.endTime)) {
            this.selectedTimeSlot = element;
          }
        });
        this.checkTimeSlot();
      }
      console.log('timeSlots', this.timeSlotsArr);
      console.log('selectedTimeSlot', this.selectedTimeSlot);
    });
  }
  get f() { return this.addCartForm.controls; }
  setFormField() {
    this.addCartForm = this.fb.group({
      productQuantity: [this.data && this.data.qty ? this.data.qty : 1, Validators.required],
      productId: [this.data && this.data.productId ? this.data.productId._id : '', Validators.required],
      date: [this.data && this.data.deliveryDate ? new Date(this.data.deliveryDate) : '', Validators.required],
      timeFrame: ['', Validators.required],
      selectedSlot: ['']
    });
    // this.checkTimeSlot();
  }
  submitCartForm() {
    this.submitted = true;
    if (!this.addCartForm.valid) {
      console.log('notValidCartForm', this.addCartForm.controls);
      return;
    }
    this.router.navigate(['page/cart'], { replaceUrl: true });
    // const isoDate = this.addCartForm.controls.date.value.toISOString();
    const payload = {
      qty: this.addCartForm.controls.productQuantity.value.toString(),
      productId: this.addCartForm.controls.productId.value,
      deliveryDate: this.addCartForm.controls.date.value.toISOString(),
      startTime: this.addCartForm.controls.selectedSlot.value.from,
      endTime: this.addCartForm.controls.selectedSlot.value.to
    };
    this.productService.editCart(payload, this.id).subscribe(response => {
      console.log('added to cart', response);
      if (response.status === 200) {
        this.commonService.showSuccess('Item updated in cart');
        // this.addedToCartFlag = true;
        this.router.navigate(['page/cart'], { replaceUrl: true });
      }
    });
  }
  selectSlot(slot) {
    this.addCartForm.controls.selectedSlot.setValue(slot);
    this.addCartForm.controls.timeFrame.clearValidators();
    this.addCartForm.controls.timeFrame.updateValueAndValidity();
  }
  increaseValue(value) {
    const newVal = value + 1;
    this.addCartForm.controls.productQuantity.setValue(newVal);

  }
  decreaseValue(value) {
    if (value <= 1) {
      return;
    }
    const newVal = value - 1;
    this.addCartForm.controls.productQuantity.setValue(newVal);
  }
  navigateToCart() {
    this.router.navigate(['page/cart'], { replaceUrl: true });
  }
  checkTimeSlot() {
    console.log('checkTimeSlot', this.selectedTimeSlot);
    this.addCartForm.controls.selectedSlot.setValue(this.selectedTimeSlot);
    this.addCartForm.controls.timeFrame.clearValidators();
    this.addCartForm.controls.timeFrame.updateValueAndValidity();
  }

}
