import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../../serviceFile/product.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { BuyOnceService } from 'src/app/serviceFile/buyOnce.service';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { Subscription } from 'rxjs';
import { OwlOptions } from 'ngx-owl-carousel-o';
declare let $: any;
declare var clevertap: any;

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss']
})
export class ProductDetailComponent implements OnInit, OnDestroy {
  id;
  productDetailObj;
  similarProductArr;
  firstTimeFlag = true;
  walletNeededBal;
  walletAvailableBal;
  quantity = 1;
  wallet$: Subscription;
  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: true,
    autoplay: false,
    navSpeed: 700,
    navText: ['', ''],
     nav: false,
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 1
      },
      740: {
        items: 1
      },
      940: {
        items: 1
      }
    },
  };
  totalProductImage = [];
  constructor(private route: ActivatedRoute, private productService: ProductService, private router: Router,
              private sharedService: SharedService, private commonService: CommonService, private buyService: BuyOnceService,
              private fireAnalytics: FirebaseAnalyticsCustomService) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.id = params.id;
      console.log('paramId', this.id);
      this.productDetail(this.id);
    });
    this.getWalletBalance();
    this.wallet$ = this.sharedService.walletData$.subscribe(res => {
      if (res) {
        this.walletAvailableBal = res.walletAmount;
      }
    });
    // this.id = this.route.snapshot.paramMap.get('id');
    // this.productDetail(this.id);
  }

  ngOnDestroy() {
    try {
      this.wallet$.unsubscribe();
    } catch (error) {
      console.log(error);
    }
  }

  getWalletBalance() {
    this.commonService.showSpinner();
    this.productService.getWalletBalance().subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.hideSpinner();
        this.walletAvailableBal = res.data.walletAmount.walletAmount;
      }
    }, error => {
      this.commonService.hideSpinner();
      this.commonService.showError(error);
    });
  }

  // function to get product detail
  productDetail(id) {
    this.productService.getProductDetail(id).subscribe(response => {
      if (response.status === 200) {
        if (!this.firstTimeFlag) {
          document.documentElement.scrollTop = 0;
        }
        try {
          clevertap.event.push(app_strings.CT_PRODUCT_CHECKED, {
            'Product Name': response.data.itemName,
            'Product Price': response.data.price,
            'Category Name': response.data.categoryId.categoryName,
            'productImage': response.data.image,
            'productId': response.data._id,
            "platform": localStorage.getItem('deviceType')
          });
          this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.PRODUCT_VIEWED, {
            'Product Name': response.data.itemName,
            'Product Price': response.data.price,
            'Category Name': response.data.categoryId.categoryName,
            'productImage': response.data.image,
            'productId': response.data._id
          });
          this.fireAnalytics.logEventCustom(response.data.itemName);
        } catch (error) {
          console.log('clevertapError');
        }
        this.totalProductImage = [];
        this.productDetailObj = response.data;
        this.totalProductImage.push({ url: this.productDetailObj.image, type: 'image' });
        if (this.productDetailObj.otherProductImages && this.productDetailObj.otherProductImages.length) {
          this.productDetailObj.otherProductImages.forEach(element => {
            this.totalProductImage.push({ url: element.image, type: 'image' });
          });
        }
        if (this.productDetailObj.video) {
          this.totalProductImage.push({ url: this.productDetailObj.video, type: 'video' });
        }
        console.log('totalProductImages', this.totalProductImage);
        this.id = response.data._id;
        // this.productDetailObj.subscription = {
        //   weeklyData: [ { qty: 0 } ]
        // }
        if (this.productDetailObj.subscriptions) {
          this.quantity = this.productDetailObj.subscriptions.weeklyData[0].qty;
        }
        console.log('productDetails', this.productDetailObj);
        this.getSimilarProduct(this.productDetailObj.categoryId._id);
        this.firstTimeFlag = false;
      }
    });
  }
  // function to buy product once
  // navigateBuyOnce() {
  //   this.router.navigate(['/page/product/list/' + this.id + '/buyOnce']);
  // }
  addToCart() {
    // this.router.navigate(['/page/product/list/' + item._id + '/buyOnce']);
    // console.log('item', item);
    const payload = {
      qty: '1',
      productId: this.id,
      productType: 'REGULAR',
      offerId: ''
    };
    this.productService.addToCart(payload).subscribe(response => {
      if (response.status === 200) {
        clevertap.event.push(app_strings.CT_PRODUCT_ADDED_TO_CART, {
          'Product Name': this.productDetailObj.itemName,
          'Product Price': this.productDetailObj.price,
          'Category Name': this.productDetailObj.categoryId.categoryName,
          "platform": localStorage.getItem('deviceType')
        });
        // this.sharedService.getCartItems();
        this.commonService.showSuccess('Item added to cart');
        this.router.navigate(['page/cart']);
        // this.addedToCartFlag = true;
      }
    });
  }

  // function to subscribe the product
  navigateSubscribe() {
    this.router.navigate(['/page/product/list/' + this.id + '/subscribe']);
  }
  // function to get similar products
  getSimilarProduct(id) {
    const payload = {
      productId: id,
      offset: 0,
      limit: 4,
      itemName: ''
    };
    this.productService.getProductVariant(payload).subscribe(response => {
      if (response.status === 200) {
        const similarItemArr = response.data;
        this.similarProductArr = similarItemArr.filter(element => element._id !== this.productDetailObj._id);
        console.log('similarProductArr', this.similarProductArr);
      }
    });
  }

  subscribeProduct(item, type: number) {
    this.router.navigate(['/page/product/list/' + item._id + '/subscribe'], { queryParams: { data: JSON.stringify(item), type: type } });
    // this.productService.getWalletBalance().subscribe(res => {
    //   if (res && res.status === 200) {
    //     this.walletAvailableBal = res.data.walletAmount.walletAmount;
    //     if (this.walletAvailableBal < item.price) {
    //       this.walletNeededBal = item.price - this.walletAvailableBal;
    //       $('#myModal1').modal('show');
    //     } else {
    //       this.router.navigate(['/page/product/list/' + item._id + '/subscribe'], { queryParams: { data: JSON.stringify(item), type: type } });
    //     }
    //   }
    // })
  }

  buyOnce(item, counterVal?: any) {
    if (!counterVal && this.walletAvailableBal < item.price) {
      this.walletNeededBal = item.price - this.walletAvailableBal;
      $('#myModal1').modal('show');
    } else if (counterVal && counterVal > 0 && this.walletAvailableBal < item.price) {
      this.walletNeededBal = item.price - this.walletAvailableBal;
      $('#myModal1').modal('show');
    } else {
      this.commonService.showSpinner();
      // const qty = counterVal === -1 ? '-1' : '+1';
      // this.quantity = this.quantity + counterVal;
      // debugger
      this.buyService.setFormField(item, counterVal ? counterVal : 1, new Date(), { editFlag: false, editVal: [], alreadySubscribe: counterVal ? true : false })
      .then(res => {
        if (counterVal) {
          this.productDetail(this.id);
        } else {
          $('#buyOnceModal').modal('show');
          this.productDetail(this.id);
        }
      });
    }
  }

  closeLessBalModal() {
    $('#myModal1').modal('hide');
  }

  // function to navigate to stripe checkout if wallet bal is below order total amount
  navigateToAddMoney() {
    $('#myModal1').modal('hide');
    const payload = {
      amount: this.walletNeededBal,
      currency: 'inr'
    };
    this.router.navigate(['page/wallet/addMoney'], { queryParams: { amount: this.walletNeededBal } });
  }

  counterLogic(type: string, item) {
    if (type === 'MINUS') {
      if (this.quantity === 1) {
        // return;
        this.buyOnce(item, -1);
      } else {
        // this.quantity -= 1;
        this.buyOnce(item, -1);
      }
    } else {
      if (this.quantity === 10) {
        return;
      }
      // this.quantity += 1;
      this.buyOnce(item, +1);
    }
  }

  offerProductBuy(item) {
    if (this.walletAvailableBal < item.price) {
      this.walletNeededBal = item.price - this.walletAvailableBal;
      $('#myModal1').modal('show');
    } else {
      this.commonService.showSpinner();
      this.commonService.openDialog('productOffer', false, item).subscribe( response => {
        if (response && response !=='skip') {
          this.buyService.setFormField(item, 1, new Date(),
            { editFlag: false, editVal: [], alreadySubscribe: false }, 'productOffer', response)
            .then(res => {
              $('#buyOnceModal').modal('show');
              this.productDetail(this.id);
            });
        } else if (response === 'skip') {
          this.buyOnce(item);
        }
      });
    }
  }

  offerProductSubscribe(item, type) {
    if (this.walletAvailableBal < item.price) {
      this.walletNeededBal = item.price - this.walletAvailableBal;
      $('#myModal1').modal('show');
    } else {
      this.commonService.showSpinner();
      this.commonService.openDialog('productOffer', false, item).subscribe( response => {
        if (response && response !=='skip') {
          this.router.navigate(['/page/product/list/' + item._id + '/subscribe'], { queryParams: { data: JSON.stringify(item), type: type, offer: JSON.stringify(response) } });
        } else if (response === 'skip') {
          this.subscribeProduct(item, type);
        }
      });
    }
  }

}
