import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSubsComponent } from './edit-subs.component';

describe('EditSubsComponent', () => {
  let component: EditSubsComponent;
  let fixture: ComponentFixture<EditSubsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditSubsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSubsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
