import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from '../../serviceFile/product.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { BuyOnceService } from 'src/app/serviceFile/buyOnce.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
import Swal from 'sweetalert2';
import { app_strings } from 'src/app/shared/_constant/app_strings';

declare let $: any;
declare let clevertap: any;

@Component({
  selector: 'app-edit-subs',
  templateUrl: './edit-subs.component.html',
  styleUrls: ['./edit-subs.component.scss']
})
export class EditSubsComponent implements OnInit {
  dateFrom = new Date();
  dateTo;
  dateFromSelected;
  dateFromSkip = new Date();
  addSubscriptionForm: FormGroup;
  submitted = false;
  dayForm: FormArray;
  dateToPreSelect;
  timeSlotsArr;
  selectFirstSlot = [];
  dayArr;
  noneDaySelected = false;
  setWeeklyData = [];
  userPrimaryLocation;
  id;
  productDetailObj;
  allLocation;
  primaryGFSid;
  maxOneMonthSub;
  currentTime = { HH: new Date().getHours(), MM: new Date().getMinutes() };
  croneTime = JSON.parse(localStorage.getItem('crone'));
  orderType: number;
  quantity = 1;
  altQty = 1;
  disableFlag = false;
  fromType: string;
  minDate = new Date();
  subscriptionDaysType = ['DAILY', 'ALTERNATE_DAYS', 'SELECTED_DAYS'];
  selectedSubsDayType = this.subscriptionDaysType[0];
  // dateChangeDetect = false;
  outOfStockFlag = false;

  constructor(private fb: FormBuilder, private router: Router, private productService: ProductService, private commonService: CommonService, private route: ActivatedRoute, public dialog: MatDialog,
    private buyService: BuyOnceService, private sharedService: SharedService) {
    this.minDate.setDate(this.minDate.getDate() + 1);
    // this.dateFrom.setDate(this.dateFrom.getDate() + 1);
    this.croneTime.hour += 5;
    this.croneTime.minute += 30;
    // this.croneLogic();
    // this.maxOneMonthSub.setDate(this.maxOneMonthSub.getDate() + 30);
    this.dayArr = [
      { label: 'Sun', value: 0 },
      { label: 'Mon', value: 1 },
      { label: 'Tue', value: 2 },
      { label: 'Wed', value: 3 },
      { label: 'Thu', value: 4 },
      { label: 'Fri', value: 5 },
      { label: 'Sat', value: 6 }
    ];
  }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.route.queryParams.subscribe(params => {
      if (params && params.type) {
        this.productDetailObj = JSON.parse(params.data);
        this.dateFrom = this.productDetailObj.fromDate;
        this.fromType = params.fromType;
        if (this.fromType === 'TOM') {
          this.croneLogic();
        } else {
          this.croneLogic2();
        }
        // this.quantity = this.productDetailObj.weeklyData[0].qty;
        this.selectedSubsDayType = this.productDetailObj.subscriptionDaysType;
        if (this.productDetailObj.subscriptionDaysType === this.subscriptionDaysType[0]) {
          this.quantity = this.productDetailObj.weeklyData[0].qty;
        } else if (this.productDetailObj.subscriptionDaysType === this.subscriptionDaysType[1]) {
          this.altQty = this.productDetailObj.weeklyData[0].qty;
        }
        if (!this.productDetailObj.productDetail.QTYperDayManipulate) {
          this.outOfStockFlag = true;
          this.commonService.showWarning('This item is Out Of Stock');
        }
        console.log('productDetailObj', this.productDetailObj)
      }
      // this.croneLogic();
    })
    this.setFormField();


    //   $('#adds').click(function add() {
    //     var $rooms = $("#noOfRoom");
    //     var a = $rooms.val();

    //     a++;
    //     $("#subs").prop("disabled", !a);
    //     $rooms.val(a);
    // });
    // $("#subs").prop("disabled", !$("#noOfRoom").val());

    // $('#subs').click(function subst() {
    //     var $rooms = $("#noOfRoom");
    //     var b = $rooms.val();
    //     if (b >= 1) {
    //         b--;
    //         $rooms.val(b);
    //     }
    //     else {
    //         $("#subs").prop("disabled", true);
    //     }
    // });


  }

  // get form control
  get f() { return this.addSubscriptionForm.controls; }

  // set form field
  setFormField() {
    const userPrimaryLocation = this.sharedService.getPrimaryLocation();
    const gfs = this.sharedService.getGfdId();
    this.addSubscriptionForm = this.fb.group({
      fromDate: [this.dateFrom],
      // productId: [this.productDetailObj._id],
      // toDate: [''],
      // orderType: 'SUBSCRIBE',
      // deliveryType: 'DELIVERY',
      // subtotal: [this.productDetailObj.price],
      // GrandTotal: [this.productDetailObj.price],
      // flatNo: [userPrimaryLocation && userPrimaryLocation.flatNo ? userPrimaryLocation.flatNo : ''],
      // landmark: [userPrimaryLocation && userPrimaryLocation.landMark ? userPrimaryLocation.landMark : ''],
      // area: [userPrimaryLocation.area._id],
      // city: [userPrimaryLocation.city._id],
      // zipcode: [userPrimaryLocation && userPrimaryLocation.zipcode ? userPrimaryLocation.zipcode : ''],
      // coordinates: [userPrimaryLocation.coordinates],
      // gfsId: [gfs],
      dayForm: this.fb.array([])
    });
    this.addDayForm();
  }

  // function to create form array
  createDayForm(): FormGroup {
    return this.fb.group({
      day: ['', [Validators.required]],
      dummyDay: [1],
      qty: [1, [Validators.required]],
      status: ['ACTIVE', [Validators.required]],
      // starttime: [''],
      // endtime: ['']
    });
  }

  // function to add day form
  addDayForm() {
    this.dayForm = this.addSubscriptionForm.get('dayForm') as FormArray;
    for (let i = 0; i < 7; i++) {
      this.dayForm.push(this.createDayForm());
      this.addSubscriptionForm.get('dayForm')['controls'][i].controls.day.setValue(this.dayArr[i]);
      if (this.productDetailObj.subscriptionDaysType === this.subscriptionDaysType[2]) {
        this.addSubscriptionForm.get('dayForm')['controls'][i].controls.qty.setValue(this.productDetailObj.weeklyData[i].qty);
        this.addSubscriptionForm.get('dayForm')['controls'][i].controls.status.setValue(this.productDetailObj.weeklyData[i].status);
      } else {
        this.addSubscriptionForm.get('dayForm')['controls'][i].controls.qty.setValue(1);
      }
    }
  }

  // function to submit subscribe form
  submitSubscribeForm() {
    this.submitted = true;
    if (!this.addSubscriptionForm.valid) {
      console.log('notValidSubscribeForm', this.addSubscriptionForm.controls);
      // window.scrollTo(0, 0);
      // return;
    }
    this.noneDaySelected = this.addSubscriptionForm.get('dayForm')['controls'].every(element => element.value.status === 'INACTIVE');
    if (this.noneDaySelected) {
      this.commonService.showWarning('Please add some quantity');
      return;
    }
    // if (!this.userPrimaryLocation.zipcode) {
    //   this.openDialog();
    //   return;
    // }
    const updatedValues = []; // QTY","TIMESLOT","STATUS", "TO_DATE", "FROM_DATE", "SUBSCRIPTION_DAYS_TYPE
    if (new Date(this.addSubscriptionForm.controls.fromDate.value).toLocaleDateString() !== new Date(this.productDetailObj.fromDate).toLocaleDateString()) {
      updatedValues.push('FROM_DATE')
    }
    this.setWeeklyData = [];
    this.addSubscriptionForm.get('dayForm')['controls'].forEach(element => {
      this.setWeeklyData.push(
        {
          day: element.value.day.value,
          qty: this.selectedSubsDayType === this.subscriptionDaysType[2] ? element.value.qty : (this.selectedSubsDayType === this.subscriptionDaysType[0] ? this.quantity : this.altQty),
          status: element.value.status,
          startTime: '',
          endTime: ''
        }
      );
    });
    if (this.productDetailObj.subscriptionDaysType !== this.selectedSubsDayType) {
      updatedValues.push('SUBSCRIPTION_DAYS_TYPE');
    }
    if (this.selectedSubsDayType !== this.subscriptionDaysType[2]) {
      if (this.selectedSubsDayType === this.subscriptionDaysType[0]) {
        if (this.quantity !== this.productDetailObj.weeklyData[0].qty) {
          updatedValues.push('QTY')
        }
      } else if (this.selectedSubsDayType === this.subscriptionDaysType[1]) {
        if (this.altQty !== this.productDetailObj.weeklyData[0].qty) {
          updatedValues.push('QTY')
        }
      }
    } else {
      let updatedValStatus = false;
      for (let i = 0; i < this.productDetailObj.weeklyData.length; i++) {
        if (this.productDetailObj.weeklyData[i].status !== this.setWeeklyData[i].status) {
          updatedValues.push('STATUS');
          updatedValStatus = true;
          break;
        }
      }
      let updatedValQuantity = false;
      for (let i = 0; i < this.productDetailObj.weeklyData.length; i++) {
        if (this.productDetailObj.weeklyData[i].qty !== this.setWeeklyData[i].qty) {
          updatedValues.push('QTY');
          updatedValQuantity = true;
          break;
        }
      }
    }
    // return;
    const payload = {
      weeklyData: this.setWeeklyData,
      updatedValues: updatedValues,
      fromDate: this.addSubscriptionForm.controls.fromDate.value,
      subscriptionDaysType: this.selectedSubsDayType
    }
    const data = this.productDetailObj;
    try {
      clevertap.event.push(app_strings.CT_PRODUCT_ADDED_TO_CART, {
        'Product Name': data.itemName,
        'Product Price': data.price,
        'Product Category': data.categoryId.categoryName,
        'ProductID': data._id,
        'Product Image': data.image,
        "platform": localStorage.getItem('deviceType')
      });
    } catch (error) {
      console.log('clevertapError');
    }
    this.commonService.showSpinner();
    this.productService.updateSubscription(payload, this.productDetailObj._id).subscribe(response => {
      if (response.status === 200) {
        this.commonService.hideSpinner();
        // this.commonService.showSuccess('Successfully subscribed the product');
        // this.router.navigate(['page/subscription'], { replaceUrl: true });

        try {
          clevertap.event.push(app_strings.CUSTOME.SUBSCRIBE, {
            'Product Name': data.productInfo.itemName,
            'Product Price': data.productInfo.price,
            'Product Category': data.productInfo.categoryId.categoryName,
            'ProductID': data.productId,
            'Product Image': data.productInfo.image,
            'Start Date': this.addSubscriptionForm.controls.fromDate.value,
            'Charged ID': data.uniqueId,
            'Subscription Type': this.selectedSubsDayType,
            'Type': 'Order Detail',
            "platform": localStorage.getItem('deviceType')
          });
        } catch (error) {
          console.log('clevertapError');
        }
        $('#subscribeModal').modal('show');
      } else {
        this.commonService.hideSpinner();
        this.commonService.showError(response.message);
      }
    });
  }

  // function to increase quantity
  increaseValue(value, i) {
    const newVal = value + 1;
    // this.addCartForm.controls.productQuantity.setValue(newVal);
    this.addSubscriptionForm.get('dayForm')['controls'][i].controls.qty.setValue(newVal);
    this.addSubscriptionForm.get('dayForm')['controls'][i].controls.status.setValue('ACTIVE');

  }

  // function to decrease quantity
  decreaseValue(value, i) {
    if (value <= 0) {
      return;
    }
    const newVal = value - 1;
    // this.addCartForm.controls.productQuantity.setValue(newVal);
    this.addSubscriptionForm.get('dayForm')['controls'][i].controls.qty.setValue(newVal);
    if (newVal === 0) {
      // debugger
      this.addSubscriptionForm.get('dayForm')['controls'][i].controls.status.setValue('INACTIVE');
    }
  }

  changeDate() {
    // this.dateChangeDetect = true;
    const formatDate = new Date(this.f.fromDate.value._d).toISOString()
    this.f.fromDate.setValue(formatDate);
  }

  // function to open golabl dialog
  openDialog() {
    // console.log('tableData', selectedMerchant);
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '400px',
      height: 'auto',
      disableClose: true,
      data: { type: 'noZipcode' }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result !== undefined) {
        this.router.navigate(['page/address']);
        // console.log('result', result);
        // this.activateAreaForm = false;
        // this.activateCustomerForm = true;
      }
    });
  }

  // function to navigate to subscription list once order placed
  orderPlaced() {
    $('#subscribeModal').modal('hide');
    this.router.navigate(['page/subscription'], { queryParams: { type: 'TOM' } })
    // this.router.navigate(['page/subscription'], { replaceUrl: true });
  }

  croneLogic() {
    // let total_days = (Math.round((this.dateFrom.getTime() - new Date().getTime()) / (60 * 60 * 1000 * 24)));
    if (this.croneTime.minute >= 60) {
      this.croneTime.hour += 1;
      this.croneTime.minute = this.croneTime.minute - 60;
      if (this.currentTime.HH >= this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        // this.dateFrom.setDate(this.dateFrom.getDate() + 1);
        this.disableFlag = true;
      }
    } else {
      if (this.currentTime.HH > this.croneTime.hour) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        // this.dateFrom.setDate(this.dateFrom.getDate() + 1);
        this.disableFlag = true;
      } else if (this.currentTime.HH === this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        // this.dateFrom.setDate(this.dateFrom.getDate() + 1);
        this.disableFlag = true;
      }
    }
  }

  croneLogic2() {
    // let total_days = (Math.round((this.dateFrom.getTime() - new Date().getTime()) / (60 * 60 * 1000 * 24)));
    if (this.croneTime.minute >= 60) {
      this.croneTime.hour += 1;
      this.croneTime.minute = this.croneTime.minute - 60;
      if (this.currentTime.HH >= this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        // this.dateFrom.setDate(this.dateFrom.getDate() + 1);
        // this.disableFlag = true;
      }
    } else {
      if (this.currentTime.HH > this.croneTime.hour) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        // this.dateFrom.setDate(this.dateFrom.getDate() + 1);
        // this.disableFlag = true;
      } else if (this.currentTime.HH === this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        // this.dateFrom.setDate(this.dateFrom.getDate() + 1);
        // this.disableFlag = true;
      }
    }
  }

  addQty(val) {
    if (this.selectedSubsDayType === this.subscriptionDaysType[0]) {
      if (val) {
        this.quantity += 1;
      } else {
        this.quantity -= 1;
      }
    } else {
      if (val) {
        this.altQty += 1;
      } else {
        this.altQty -= 1;
      }
    }
  }

  navigateToBasket() {
    this.router.navigate(['page/subscription'], { queryParams: { type: 'TOM' } })
  }

  // function to open susbcription log
  openSubscriptionLog(id) {
    this.router.navigate(['page/subscription/list/' + id + '/log']);
  }

  deleteSubscription(subscription) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to delete this subscription!',
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        const payload = {};
        this.productService.deleteSubscription(payload, subscription._id).subscribe(response => {
          if (response.status === 200) {
            this.commonService.showSuccess('Subscription deleted');
            this.sharedService.getCartData();
            this.router.navigate(['page/subscription'], { queryParams: { type: 'TOM' } })
          }
        });
        // Swal.fire(
        //   'Deleted!',
        //   'Your imaginary file has been deleted.',
        //   'success'
        // )
        // For more information about handling dismissals please visit
        // https://sweetalert2.github.io/#handling-dismissals
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        // Swal.fire(
        //   'Cancelled',
        //   'Your imaginary file is safe :)',
        //   'error'
        // )
      }
    })

  }

}
