import { Component, OnDestroy, OnInit } from '@angular/core';
import { ProductService } from '../../serviceFile/product.service';
import { Router } from '@angular/router';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { BuyOnceService } from 'src/app/serviceFile/buyOnce.service';
import { Subscription } from 'rxjs';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
declare let $: any;
declare var clevertap: any;

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit, OnDestroy {
  productCategoriesArr;
  variantLabel;
  viewAs = [];
  selectedView = 0;
  productVariantsArr;
  productCatOffset = 0;
  productCatLimit = 50;
  productVariantOffset = 0;
  productVariantLimit = 6;
  productCatId;
  walletNeededBal;
  walletAvailableBal;
  quantity = 1;
  selectedProduct;
  customOptions: OwlOptions = {
    loop: false,
    mouseDrag: false,
    touchDrag: true,
    pullDrag: false,
    autoWidth:true,
    items:8,
    autoplay:false,
    autoplayTimeout:3000,
    dots: false,
    navSpeed: 700,
    navText: ['', ''],
    responsive: {
      0: {
        items: 2
      },
      400:{
        items: 3
      },
      600: {
        items: 4
      },
      800: {
        items: 6
      },
      1000: {
        items:8
      },
      1200: {
        items:10
      }
    },
    nav: true
  };
  isDragging: boolean;
  productLoadedFlag = false;
  wallet$: Subscription;

  constructor(private productService: ProductService, private router: Router, private sharedService: SharedService,
              private commonService: CommonService, private buyService: BuyOnceService, private fireAnalytics: FirebaseAnalyticsCustomService) {
    this.viewAs = [
      {label: 'All', value: 0},
      {label: '1', value: 1},
      {label: '2', value: 2},
    ];
  }

  ngOnInit(): void {
    this.wallet$ = this.sharedService.walletData$.subscribe(res => {
      if (res) {
        this.walletAvailableBal = res.walletAmount;
      }
    });
    // $('.owl-carousel').owlCarousel({
    //   nav:true,
    //   loop:true,
    //   margin:10,
    //   dots:false,
    //   autoplay:true,
    //   responsive:{
    //     0:{
    //       items:1
    //     },
    //     600:{
    //       items:2
    //     },
    //     800:{
    //       items:3
    //     },
    //     1000:{
    //       items:3
    //     },
    //     1200:{
    //       items:4
    //     }
    //   }
    // });


    this.productCategroies();
    this.getWalletBalance();
  }

  ngOnDestroy() {
    try {
      this.wallet$.unsubscribe();
    } catch (error) {
      console.log(error);
    }
  }

  // function to get product categories
  productCategroies() {
    const payload = {
      offset: this.productCatOffset,
      limit: this.productCatLimit
    };
    this.productService.getProductCat(payload).subscribe(response => {
      if (response.status === 200) {
        this.productCategoriesArr = response.data;
        this.variantLabel = this.productCategoriesArr[0].categoryName;
      // console.log('productCategoriesArr', this.productCategoriesArr);
        const productId = this.productCategoriesArr[0]._id;
        this.productCatId = productId;
        this.productVariantDefault(productId);
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

  getWalletBalance() {
    this.commonService.showSpinner();
    this.productService.getWalletBalance().subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.hideSpinner();
        this.walletAvailableBal = res.data.walletAmount.walletAmount;
      }
    }, error => {
      this.commonService.hideSpinner();
      this.commonService.showError(error);
    });
  }

  // function on scroll of product categories
  onScrollCategories() {
    console.log('scrolled Categories');
    this.productCatOffset += 10;
    const payload = {
      offset: this.productCatOffset,
      limit: this.productCatLimit
    };
    this.productService.getProductCat(payload).subscribe(response => {
      if (response.status === 200) {
        if (response && response.data && response.data.length) {
          const catArr = response.data;
          catArr.forEach(element => {
            this.productCategoriesArr.push(element);
          });
          console.log('updatedCat+10', this.productCategoriesArr);
        }
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

  // function to get product variants on first load
  productVariantDefault(id) {
    const payload = {
      productId: id,
      offset: this.productVariantOffset,
      limit: this.productVariantLimit,
      itemName: ''
    };
    this.productCatId = id;
    this.productService.getProductVariant(payload).subscribe(response => {
      if (response.status === 200) {
        this.productLoadedFlag = true;
        this.productVariantsArr = response.data;
      // console.log('productDetailArr', this.productVariantsArr);
      // if (this.productDetailObj.subscription) {
      //   this.quantity = this.productDetailObj.subscription.weeklyData[0].qty;
      // }
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

  // function to get product variant on user input
  getProductVariant(product, isDrag) {
    if (isDrag) {
      return;
    }
    this.productVariantsArr = [];
    this.productLoadedFlag = false;
    // this.selectedProduct = product;
    clevertap.event.push(app_strings.CT_CATEGORY_CHECKED, {
      'Category Name': product.categoryName,
      "platform": localStorage.getItem('deviceType')
    });
    this.fireAnalytics.logFacebookPixelEvent(app_strings.FACEBOOK_PIXEL.PRODUCT_CATEGORY);
    this.fireAnalytics.logGoogleAnalyticsEvent(app_strings.GOOGLE_ANALYTICS.PRODUCT_CATEGORY);
    this.variantLabel = product.categoryName;
    // console.log('product', product);
    if (this.productVariantsArr.length > 0 && this.productVariantsArr[0].categoryId === product._id) {
      return;
    }
    this.productVariantOffset = 0;
    const payload = {
      productId: product._id,
      offset: this.productVariantOffset,
      limit: this.productVariantLimit,
      itemName: ''
    };
    this.productCatId = product._id;
    this.productService.getProductVariant(payload).subscribe(response => {
      if (response.status === 200) {
        this.productLoadedFlag = true;
        this.productVariantsArr = response.data;
      } else {
        this.commonService.showError(response.message);
      }
    });
  }
  openProductDetail(item) {
    // this.router.navigateByUrl('/page/product/list/' + item._id);
    this.router.navigate(['/page/product/list/detail'], { queryParams: { id: item._id } });
  }
  addToCart(item) {
    // this.router.navigate(['/page/product/list/' + item._id + '/buyOnce']);
    // console.log('item', item);
    const payload = {
      qty: '1',
      productId: item._id,
      productType: 'REGULAR',
      offerId: ''
    };
    this.productService.addToCart(payload).subscribe(response => {
      if (response.status === 200) {
        clevertap.event.push(app_strings.CT_PRODUCT_ADDED_TO_CART, {
          'Product Name': item.itemName,
          'Product Price': item.price,
          'Category Name': item.categoryId.categoryName,
          "platform": localStorage.getItem('deviceType')
        });
        // this.sharedService.getCartItems();
        this.commonService.showSuccess('Item added to basket');
        this.router.navigate(['page/cart']);
        // this.addedToCartFlag = true;
      }
    });
  }
  subscribeProduct(item, type: number) {
    this.router.navigate(['/page/product/list/' + item._id + '/subscribe'], { queryParams: { data: JSON.stringify(item), type: type } });
    // this.productService.getWalletBalance().subscribe(res => {
    //   if (res && res.status === 200) {
    //     this.walletAvailableBal = res.data.walletAmount.walletAmount;
    //     if (this.walletAvailableBal < item.price) {
    //       this.walletNeededBal = item.price - this.walletAvailableBal;
    //       $('#myModal1').modal('show');
    //     } else {
    //       this.router.navigate(['/page/product/list/' + item._id + '/subscribe'], { queryParams: { data: JSON.stringify(item), type: type } });
    //     }
    //   }
    // })
  }

  buyOnce(item, counterVal?: any, index?: any) {
    if (!counterVal && this.walletAvailableBal < item.price) {
          this.walletNeededBal = item.price - this.walletAvailableBal;
          $('#myModal1').modal('show');
        } else if (counterVal && counterVal > 0 && this.walletAvailableBal < item.price) {
          this.walletNeededBal = item.price - this.walletAvailableBal;
          $('#myModal1').modal('show');
        } else {
          this.commonService.showSpinner();
          this.buyService.setFormField(item, counterVal ? counterVal : 1, new Date().toISOString(),
          { editFlag: false, editVal: [], alreadySubscribe: counterVal ? true : false }).then(value => {
            if (counterVal) {
              // this.productVariantsArr[index].subscriptions.weeklyData[0].qty += counterVal;
              this.productVariantOffset = 0;
              this.productVariantsArr = [];
              this.getProductVariant2();
            } else {
              $('#buyOnceModal').modal('show');
              this.productVariantOffset = 0;
              this.productVariantsArr = [];
              this.getProductVariant2();
            }
          }, error => {
            console.log('promisee error', error);
          });
        }
  }

  // function to get product variant on user input
  getProductVariant2() {
    // this.variantLabel = product.categoryName;
    const payload = {
      productId: this.productCatId,
      offset: this.productVariantOffset,
      limit: this.productVariantLimit,
      itemName: ''
    };
    this.productLoadedFlag = false;
    this.productService.getProductVariant(payload).subscribe(response => {
      if (response.status === 200) {
        this.productLoadedFlag = true;
        this.productVariantsArr = response.data;
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

  // function on scroll
  onScrollProducts(catId) {
    if (!this.productVariantsArr || (this.productVariantsArr.length % 3 !== 0)) {
      return;
    }
    console.log('scrolled!!');
    this.productVariantOffset += 6;
    const payload = {
      productId: catId,
      offset: this.productVariantOffset,
      limit: this.productVariantLimit,
      itemName: ''
    };
    this.productLoadedFlag = false;
    this.productService.getProductVariant(payload).subscribe(response => {
      if (response.status === 200) {
        this.productLoadedFlag = true;
        if (response && response.data.length) {
          const productArr = response.data;
          productArr.forEach(element => {
            this.productVariantsArr.push(element);
          });
          console.log('updated+10Products', this.productVariantsArr);
        }
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

  closeLessBalModal() {
    $('#myModal1').modal('hide');
  }

  // function to navigate to stripe checkout if wallet bal is below order total amount
  navigateToAddMoney() {
    $('#myModal1').modal('hide');
    const payload = {
      amount: this.walletNeededBal,
      currency: 'inr'
    };
    this.router.navigate(['page/wallet/addMoney'], { queryParams: { amount: this.walletNeededBal } });
  }

  counterLogic(type: string, item, i) {
    if (type === 'MINUS') {
      if (item.subscriptions.weeklyData[0].qty === 1) {
        // return;
        this.buyOnce(item, -1, i);
      } else {
        // this.quantity -= 1;
        this.buyOnce(item, -1, i);
      }
    } else {
      // this.quantity += 1;
      if (item.subscriptions.weeklyData[0].qty >= 10) {
        return;
      }
      this.buyOnce(item, +1, i);
    }
  }

  offerProductBuy(item) {
    this.commonService.showSpinner();
    this.productService.getWalletBalance().subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.hideSpinner();
        this.walletAvailableBal = res.data.walletAmount.walletAmount;
        // this.walletAvailableBal = 10
        if (this.walletAvailableBal < item.price) {
          this.walletNeededBal = item.price - this.walletAvailableBal;
          $('#myModal1').modal('show');
        } else {
          this.commonService.showSpinner();
          this.commonService.openDialog('productOffer', false, item).subscribe( response => {
            if (response && response !=='skip') {
              this.buyService.setFormField(item, 1, new Date(),
                { editFlag: false, editVal: [], alreadySubscribe: false }, 'productOffer', response)
                .then(res => {
                  $('#buyOnceModal').modal('show');
                  this.productVariantOffset = 0;
                  this.productVariantsArr = [];
                  this.getProductVariant2();
                });
            } else if (response === 'skip') {
              this.buyOnce(item);
            }
          });
        }
      } else {
        this.commonService.hideSpinner();
        this.commonService.showError(res.message);
      }
    });

  }

  offerProductSubscribe(item, type) {
    this.commonService.showSpinner();
    this.productService.getWalletBalance().subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.hideSpinner();
        this.walletAvailableBal = res.data.walletAmount.walletAmount;
        // this.walletAvailableBal = 10
        if (this.walletAvailableBal < item.price) {
          this.walletNeededBal = item.price - this.walletAvailableBal;
          $('#myModal1').modal('show');
        } else {
          this.commonService.showSpinner();
          this.commonService.openDialog('productOffer', false, item).subscribe( response => {
            if (response && response !=='skip') {
              this.router.navigate(['/page/product/list/' + item._id + '/subscribe'], { queryParams: { data: JSON.stringify(item), type: type, offer: JSON.stringify(response) } });
            } else if (response === 'skip') {
              this.subscribeProduct(item, type);
            }
          });
        }
      } else {
        this.commonService.hideSpinner();
        this.commonService.showError(res.message);
      }
    });

  }

}
