import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from '../../serviceFile/product.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { take } from 'rxjs/operators';

declare let $: any;
declare let clevertap: any;

@Component({
  selector: 'app-subscribe',
  templateUrl: './subscribe.component.html',
  styleUrls: ['./subscribe.component.scss']
})
export class SubscribeComponent implements OnInit {
  dateFrom = new Date();
  dateTo;
  dateFromSelected;
  dateFromSkip = new Date();
  addSubscriptionForm: FormGroup;
  submitted = false;
  dayForm: FormArray;
  dateToPreSelect;
  timeSlotsArr;
  selectFirstSlot = [];
  dayArr;
  noneDaySelected = false;
  setWeeklyData = [];
  userPrimaryLocation;
  id;
  productDetailObj;
  allLocation;
  primaryGFSid;
  maxOneMonthSub;
  currentTime = { HH: new Date().getHours(), MM: new Date().getMinutes() };
  croneTime = JSON.parse(localStorage.getItem('crone'));
  orderType: number;
  quantity = 1;
  altQty = 1;
  disableFlag = false;
  fromType: string;
  minDate = new Date();
  subscriptionDaysType = ['DAILY', 'ALTERNATE_DAYS', 'SELECTED_DAYS'];
  selectedSubsDayType = this.subscriptionDaysType[0];
  walletNeededBal;
  walletAvailableBal;
  offeredProductObj;
  dateSelectedFromDatePickerFlag = false;
  couponManualFlag = true;

  constructor(private fb: FormBuilder, private router: Router, private productService: ProductService, private commonService: CommonService, private route: ActivatedRoute, public dialog: MatDialog,
              private sharedService: SharedService, private fireAnalytics: FirebaseAnalyticsCustomService) {
    this.minDate.setDate(this.minDate.getDate() + 1);
    this.dateFrom.setDate(this.dateFrom.getDate() + 1);
    this.croneTime.hour += 5;
    this.croneTime.minute += 30;
    // this.croneLogic();
    // this.maxOneMonthSub.setDate(this.maxOneMonthSub.getDate() + 30);
    this.dayArr = [
      { label: 'Sun', value: 0 },
      { label: 'Mon', value: 1 },
      { label: 'Tue', value: 2 },
      { label: 'Wed', value: 3 },
      { label: 'Thu', value: 4 },
      { label: 'Fri', value: 5 },
      { label: 'Sat', value: 6 }
    ];
   }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.getAllCouponList();
    this.route.queryParams.subscribe(params => {
      if (params && params.type) {
        this.productDetailObj = JSON.parse(params.data);
        // this.dateFrom = new Date(this.productDetailObj.fromDate);
        // this.fromType = params.fromType;
        // if (this.fromType === 'TOM') {
        //   this.croneLogic();
        // }
        console.log('productDetailObj', this.productDetailObj)
      }
      if (params && params.offer) {
        this.offeredProductObj = JSON.parse(params.offer);
      }
      this.croneLogic();
    });
    this.setFormField();
    this.getWalletBalance();


  //   $('#adds').click(function add() {
  //     var $rooms = $("#noOfRoom");
  //     var a = $rooms.val();

  //     a++;
  //     $("#subs").prop("disabled", !a);
  //     $rooms.val(a);
  // });
  // $("#subs").prop("disabled", !$("#noOfRoom").val());

  // $('#subs').click(function subst() {
  //     var $rooms = $("#noOfRoom");
  //     var b = $rooms.val();
  //     if (b >= 1) {
  //         b--;
  //         $rooms.val(b);
  //     }
  //     else {
  //         $("#subs").prop("disabled", true);
  //     }
  // });


  }

  getWalletBalance() {
    this.commonService.showSpinner();
    this.productService.getWalletBalance().subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.hideSpinner();
        this.walletAvailableBal = res.data.walletAmount.walletAmount;
      }
    }, error => {
      this.commonService.hideSpinner();
      this.commonService.showError(error);
    });
  }

  // get form control
  get f() { return this.addSubscriptionForm.controls; }

  // set form field
  setFormField() {
    const userPrimaryLocation = this.sharedService.getPrimaryLocation();
    const gfs = this.sharedService.getGfdId();
    this.addSubscriptionForm = this.fb.group({
      productId: [this.productDetailObj._id],
      fromDate: [this.dateFrom],
      toDate: [''],
      orderType: 'SUBSCRIBE',
      deliveryType: 'DELIVERY',
      subtotal: [this.productDetailObj.price],
      GrandTotal: [this.productDetailObj.price],
      flatNo: [userPrimaryLocation && userPrimaryLocation.flatNo ? userPrimaryLocation.flatNo : ''],
      landmark: [userPrimaryLocation && userPrimaryLocation.landMark ? userPrimaryLocation.landMark : ''],
      area: [userPrimaryLocation.area._id],
      city: [userPrimaryLocation.city._id],
      zipcode: [userPrimaryLocation && userPrimaryLocation.zipcode ? userPrimaryLocation.zipcode : ''],
      coordinates: [userPrimaryLocation.coordinates],
      gfsId: [gfs],
      dayForm: this.fb.array([]),
      subscriptionCoupon: ['']
    });
    this.addDayForm();
  }

  // function to create form array
  createDayForm(): FormGroup {
    return this.fb.group({
      day: ['', [Validators.required]],
      dummyDay: [1],
      qty: [this.quantity, [Validators.required]],
      status: ['ACTIVE', [Validators.required]],
      // starttime: [''],
      // endtime: ['']
    });
  }

  // function to add day form
  addDayForm() {
    this.dayForm = this.addSubscriptionForm.get('dayForm') as FormArray;
    for (let i = 0; i < 7; i++) {
      this.dayForm.push(this.createDayForm());
      this.addSubscriptionForm.get('dayForm')['controls'][i].controls.day.setValue(this.dayArr[i]);
    }
  }

  // function to submit subscribe form
  submitSubscribeForm() {
    this.submitted = true;
    if (!this.addSubscriptionForm.valid) {
      window.scrollTo(0, 0);
      return;
    }
    const data = this.productDetailObj;
    this.noneDaySelected = this.addSubscriptionForm.get('dayForm')['controls'].every(element => element.value.status === 'INACTIVE');
    if (this.noneDaySelected) {
      this.commonService.showWarning('Please add some quantity');
      return;
    }
    // if (!this.userPrimaryLocation.zipcode) {
    //   this.openDialog();
    //   return;
    // }
    this.setWeeklyData = [];
    this.addSubscriptionForm.get('dayForm')['controls'].forEach(element => {
      this.setWeeklyData.push(
        {
          day: element.value.day.value,
          // qty: this.selectedSubsDayType === this.subscriptionDaysType[2] ? element.value.qty : this.quantity,
          qty: this.selectedSubsDayType === this.subscriptionDaysType[2] ? element.value.qty : (this.selectedSubsDayType === this.subscriptionDaysType[0] ? this.quantity : this.altQty),
          status: element.value.status,
          startTime: '',
          endTime: ''
        }
      );
    });
    if (this.walletAvailableBal < this.productDetailObj.price * this.setWeeklyData[0].qty) {
      this.walletNeededBal = this.productDetailObj.price * this.setWeeklyData[0].qty - this.walletAvailableBal;
      $('#myModal1').modal('show');
      return;
    } else {
      const payload: any = {
        productId: this.addSubscriptionForm.controls.productId.value,
        fromDate: this.dateSelectedFromDatePickerFlag ? this.addSubscriptionForm.controls.fromDate.value :
        this.getRequiredDateFormat(this.addSubscriptionForm.controls.fromDate.value),
        toDate: this.addSubscriptionForm.controls.toDate.value,
        weeklyData: this.setWeeklyData,
        orderType: this.addSubscriptionForm.controls.orderType.value,
        deliveryType: this.addSubscriptionForm.controls.deliveryType.value,
        tax: [],
        deliveryCharges: '0',
        discount: '0',
        offerId: '',
        subtotal: this.productDetailObj.price,
        GrandTotal: this.productDetailObj.price,
        flatNo: this.addSubscriptionForm.controls.flatNo.value,
        landMark: this.addSubscriptionForm.controls.landmark.value,
        area: this.addSubscriptionForm.controls.area.value,
        city: this.addSubscriptionForm.controls.city.value,
        zipcode: this.addSubscriptionForm.controls.zipcode.value,
        coordinates: this.addSubscriptionForm.controls.coordinates.value,
        gfsId: this.addSubscriptionForm.controls.gfsId.value,
        subscriptionDaysType: this.selectedSubsDayType
      };
      if (this.offeredProductObj) {
        payload.productId = this.offeredProductObj.item;
        payload.offerId = this.offeredProductObj._id;
        payload.offer = {
          offerType: this.offeredProductObj.offerType,
          offerTypeValue: this.offeredProductObj.offerTypeValue,
          title: this.offeredProductObj.title,
          image: this.offeredProductObj.image,
          thumbnail: this.offeredProductObj.thumbnail
        };
      } else {
        payload.offer = {
          offerType: 'NONE',
          offerTypeValue: {}
        };
      }
      try {
        clevertap.event.push(app_strings.CT_PRODUCT_ADDED_TO_CART, {
          'Product Name': data.itemName,
          'Product Price': data.price,
          'Product Category': data.categoryId.categoryName,
          'ProductID': data._id,
          'Product Image': data.image,
          "platform": localStorage.getItem('deviceType')
        });
        this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.PRODUCT_ADDED_TO_CART, {
          'Product Name': data.itemName,
          'Product Price': data.price,
          'Product Category': data.categoryId.categoryName,
          'ProductID': data._id,
          'Product Image': data.image
        });
      } catch (error) {
        console.log('clevertapError');
      }
      this.commonService.showSpinner();
      this.productService.subscribeProduct(payload).subscribe(response => {
        if (response.status === 200) {
          this.commonService.hideSpinner();
          const data = response.data;
          data.productInfo = JSON.parse(data.productInfo);
          try {
            clevertap.event.push(app_strings.CUSTOME.SUBSCRIBE, {
              'Product Name': data.productInfo.itemName,
              'Product Price': data.productInfo.price,
              'Product Category': data.productInfo.categoryId.categoryName,
              'ProductID': data.productId,
              'Product Image': data.productInfo.image,
              'Start Date': data.fromDate,
              'Charged ID': data.uniqueId,
              'Subscription Type': data.subscriptionDaysType,
              'Type': 'Subscribe',
              "platform": localStorage.getItem('deviceType')
            });
            this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.PRODUCT_SUBSCRIBED, {
              'Product Name': data.productInfo.itemName,
              'Product Price': data.productInfo.price,
              'Product Category': data.productInfo.categoryId.categoryName,
              'ProductID': data.productId,
              'Product Image': data.productInfo.image,
              'Start Date': data.fromDate,
              'Charged ID': data.uniqueId,
              'Subscription Type': data.subscriptionDaysType,
              'Type': 'Subscribe'
            });
            if(data.isBuyFirst) {
              clevertap.event.push(app_strings.CUSTOME.FIRST_TIME_BUY, {
              'Product Name': data.productInfo.itemName,
              'Product Price': data.productInfo.price,
              'Product Category': data.productInfo.categoryId.categoryName,
              'ProductID': data.productId,
              'Product Image': data.productInfo.image,
              'Start Date': data.fromDate,
              'Charged ID': data.uniqueId,
              'Subscription Type': data.subscriptionDaysType,
              'Type': 'Subscribe',
              "platform": localStorage.getItem('deviceType')
              });
              this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.FIRST_TIME_BUY, {
              'Product Name': data.productInfo.itemName,
              'Product Price': data.productInfo.price,
              'Product Category': data.productInfo.categoryId.categoryName,
              'ProductID': data.productId,
              'Product Image': data.productInfo.image,
              'Start Date': data.fromDate,
              'Charged ID': data.uniqueId,
              'Subscription Type': data.subscriptionDaysType,
              'Type': 'Subscribe'
              });
              this.fireAnalytics.logFacebookPixelEvent(app_strings.FACEBOOK_PIXEL.FIRST_ORDER, {
                'productName': data.productInfo.itemName,
                'productPrice': data.productInfo.price,
                'productId': data.productId
              });
              this.fireAnalytics.logFacebookPixelEvent(app_strings.FACEBOOK_PIXEL.SUBSCRIBE, {
                'productName': data.productInfo.itemName,
                'productPrice': data.productInfo.price,
                'productId': data.productId
              });
              this.fireAnalytics.logGoogleAnalyticsEvent(app_strings.GOOGLE_ANALYTICS.FIRST_ORDER, {
                'event': app_strings.GOOGLE_ANALYTICS.FIRST_ORDER,
                'productName': data.productInfo.itemName,
                'productPrice': data.productInfo.price,
                'productId': data.productId
              });
              this.fireAnalytics.logGoogleAnalyticsEvent(app_strings.GOOGLE_ANALYTICS.SUBSCRIBE, {
                'event': app_strings.GOOGLE_ANALYTICS.SUBSCRIBE,
                'productName': data.productInfo.itemName,
                'productPrice': data.productInfo.price,
                'productId': data.productId
              });
            } else {
              clevertap.event.push(app_strings.CUSTOME.REPEAT_ORDER, {
                'Product Name': data.productInfo.itemName,
                'Product Price': data.productInfo.price,
                'Product Category': data.productInfo.categoryId.categoryName,
                'ProductID': data.productId,
                'Product Image': data.productInfo.image,
                'Start Date': data.fromDate,
                'Charged ID': data.uniqueId,
                'Subscription Type': data.subscriptionDaysType,
                'Type': 'Subscribe',
                "platform": localStorage.getItem('deviceType')
                });
              this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.REPEAT_ORDER, {
                'Product Name': data.productInfo.itemName,
                'Product Price': data.productInfo.price,
                'Product Category': data.productInfo.categoryId.categoryName,
                'ProductID': data.productId,
                'Product Image': data.productInfo.image,
                'Start Date': data.fromDate,
                'Charged ID': data.uniqueId,
                'Subscription Type': data.subscriptionDaysType,
                'Type': 'Subscribe'
                });
              this.fireAnalytics.logFacebookPixelEvent(app_strings.FACEBOOK_PIXEL.REPEAT_ORDER, {
                'productName': data.productInfo.itemName,
                'productPrice': data.productInfo.price,
                'productId': data.productId
              });
              this.fireAnalytics.logFacebookPixelEvent(app_strings.FACEBOOK_PIXEL.SUBSCRIBE, {
                'productName': data.productInfo.itemName,
                'productPrice': data.productInfo.price,
                'productId': data.productId
              });
              this.fireAnalytics.logGoogleAnalyticsEvent(app_strings.GOOGLE_ANALYTICS.REPEAT_ORDER, {
                'event': app_strings.GOOGLE_ANALYTICS.REPEAT_ORDER,
                'productName': data.productInfo.itemName,
                'productPrice': data.productInfo.price,
                'productId': data.productId
              });
              this.fireAnalytics.logGoogleAnalyticsEvent(app_strings.GOOGLE_ANALYTICS.SUBSCRIBE, {
                'event': app_strings.GOOGLE_ANALYTICS.SUBSCRIBE,
                'productName': data.productInfo.itemName,
                'productPrice': data.productInfo.price,
                'productId': data.productId
              });
            }
          } catch (error) {
            console.log('clevertapError');
          }
          $('#subscribeModal').modal('show');
          this.sharedService.getCartData();
        } else {
          this.commonService.hideSpinner();
          this.commonService.showError(response.message);
        }
      });
    }
  }

  // function to increase quantity
  increaseValue(value, i) {
    const newVal = value + 1;
    // this.addCartForm.controls.productQuantity.setValue(newVal);
    this.addSubscriptionForm.get('dayForm')['controls'][i].controls.qty.setValue(newVal);
    this.addSubscriptionForm.get('dayForm')['controls'][i].controls.status.setValue('ACTIVE');

  }

  // function to decrease quantity
  decreaseValue(value, i) {
    if (value <= 0) {
      return;
    }
    const newVal = value - 1;
    // this.addCartForm.controls.productQuantity.setValue(newVal);
    this.addSubscriptionForm.get('dayForm')['controls'][i].controls.qty.setValue(newVal);
    if (newVal === 0) {
      this.addSubscriptionForm.get('dayForm')['controls'][i].controls.status.setValue('INACTIVE');
    }
  }

  changeDate() {
    this.dateSelectedFromDatePickerFlag = true;
    const formatDate = new Date(this.f.fromDate.value._d).toISOString();
    this.f.fromDate.setValue(formatDate);
  }

  // function to open golabl dialog
  openDialog() {
    // console.log('tableData', selectedMerchant);
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '400px',
      height: 'auto',
      disableClose: true,
      data: {type: 'noZipcode'}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result !== undefined) {
        this.router.navigate(['page/address']);
      }
    });
  }

  // function to navigate to subscription list once order placed
  orderPlaced() {
    $('#subscribeModal').modal('hide');
    this.router.navigate(['page/subscription'], { queryParams: { type: 'TOM' } });
    // this.router.navigate(['page/subscription'], { replaceUrl: true });
  }

  croneLogic() {
    // let total_days = (Math.round((this.dateFrom.getTime() - new Date().getTime()) / (60 * 60 * 1000 * 24)));
    if (this.croneTime.minute >= 60) {
      this.croneTime.hour += 1;
      this.croneTime.minute = this.croneTime.minute - 60;
      if (this.currentTime.HH >= this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        this.dateFrom.setDate(this.dateFrom.getDate() + 1);
        // this.disableFlag = true;
      }
    } else {
      if (this.currentTime.HH > this.croneTime.hour) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        this.dateFrom.setDate(this.dateFrom.getDate() + 1);
        // this.disableFlag = true;
      } else if (this.currentTime.HH === this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        this.dateFrom.setDate(this.dateFrom.getDate() + 1);
        // this.disableFlag = true;
      }
    }
  }

  // addQty(val) {
  //   if (val) {
  //     this.quantity += 1;
  //   } else {
  //     this.quantity -= 1;
  //   }
  // }

  addQty(val) {
    if (this.selectedSubsDayType === this.subscriptionDaysType[0]) {
      if (val) {
        this.quantity += 1;
      } else {
        this.quantity -= 1;
      }
    } else {
      if (val) {
        this.altQty += 1;
      } else {
        this.altQty -= 1;
      }
    }
  }

  closeLessBalModal() {
    $('#myModal1').modal('hide');
  }

  // function to navigate to stripe checkout if wallet bal is below order total amount
  navigateToAddMoney() {
    $('#myModal1').modal('hide');
    const payload = {
      amount: this.walletNeededBal,
      currency: 'inr'
    };
    this.router.navigate(['page/wallet/addMoney'], { queryParams: { amount: this.walletNeededBal } });
  }

  getRequiredDateFormat(date: Date) {
    let dd: any = date.getDate();
    let mm: any = date.getMonth() + 1;
    const yyyy = date.getFullYear();
    if (dd < 10) {
      dd = '0' + dd;
    }
    if (mm < 10) {
      mm = '0' + mm;
    }
    return `${yyyy}-${mm}-${dd}T00:00:00.000Z`;
  }

  getAllCouponList() {
    this.productService.getCoupon(this.id).pipe(take(1)).subscribe(res => {
      if (res && res.status === 200) {
        const list = res.data;
        console.log('couponList', list);
        if (list.length) {
          const selectedCoupon = list[0];
          this.addSubscriptionForm.controls.subscriptionCoupon.setValue(selectedCoupon.couponCode);
          this.applyCoupon();
        }
      }
    });
  }

  applyCoupon() {
    const obj = {
      couponCode: this.f.subscriptionCoupon.value,
      productId: this.id
    };
    this.productService.applyOrRemoveCoupon(1, obj).pipe(take(1)).subscribe(res => {
      if (res && res.status === 200) {
        console.log('data', res);
        const data = res.data;
        this.couponManualFlag = false;
        this.commonService.showSuccess(data.title, `WOHOO!! ${data.couponCode} Applied`);
        try {
          clevertap.event.push('Apply coupon Clicked', {
            "platform": localStorage.getItem('deviceType')
          });
        } catch (error) {
          console.log(error);
        }
      } else {
        this.commonService.showError(res.message);
      }
    }, err => {
      this.commonService.showError(err);
    });
  }

  RemoveCoupon() {
    const obj = {
      couponCode: this.f.subscriptionCoupon.value
    };
    this.productService.applyOrRemoveCoupon(2, obj).pipe(take(1)).subscribe(res => {
      if (res && res.status === 200) {
        console.log('data', res);
        this.couponManualFlag = true;
        this.commonService.showSuccess(`${res.data}`);
        this.f.subscriptionCoupon.setValue('');
      } else {
        this.commonService.showError(res.message);
      }
    }, err => {
      this.commonService.showError(err);
    });
  }

}
