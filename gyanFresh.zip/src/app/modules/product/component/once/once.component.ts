import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from '../../serviceFile/product.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { BuyOnceService } from 'src/app/serviceFile/buyOnce.service';
import Swal from 'sweetalert2';
import { SharedService } from 'src/app/serviceFile/shared.service';

declare let $: any;

@Component({
  selector: 'app-once',
  templateUrl: './once.component.html',
  styleUrls: ['./once.component.scss']
})
export class OnceComponent implements OnInit {
  dateFrom = new Date();
  addSubscriptionForm: FormGroup;
  productDetailObj;
  primaryGFSid;
  currentTime = { HH: new Date().getHours(), MM: new Date().getMinutes() };
  croneTime = JSON.parse(localStorage.getItem('crone'));
  orderType: number;
  quantity = 1;
  disableFlag = false;
  fromType: string;
  minDate = new Date();
  outOfStockFlag = false;

  constructor(private fb: FormBuilder, private router: Router, private productService: ProductService, private commonService: CommonService, private route: ActivatedRoute, public dialog: MatDialog,
              private buyService: BuyOnceService, private sharedService: SharedService) {
    this.minDate.setDate(this.minDate.getDate() + 1);
    this.croneTime.hour += 5;
    this.croneTime.minute += 30;
   }

  ngOnInit(): void {
    // this.id = this.route.snapshot.paramMap.get('id');
    this.route.queryParams.subscribe(params => {
      if (params && params.type) {
        this.orderType = params.type;
        this.productDetailObj = JSON.parse(params.data);
        this.dateFrom = this.productDetailObj.fromDate;
        this.fromType = params.fromType;
        this.quantity = this.productDetailObj.weeklyData[0].qty;
        if (this.fromType === 'TOM') {
          if (this.productDetailObj.status === 'PLACED') {
            this.disableFlag = true;
          } else {
            this.croneLogic();
          }
        } else {
          this.croneLogic2();
        }
        if (!this.productDetailObj.productDetail.QTYperDayManipulate) {
          this.outOfStockFlag = true;
          this.commonService.showWarning('This item is Out Of Stock');
        }
        console.log('productDetailObj', this.productDetailObj);
      }
    })
    this.setFormField();


    $('#adds').click(function add() {
      var $rooms = $("#noOfRoom");
      var a = $rooms.val();

      a++;
      $("#subs").prop("disabled", !a);
      $rooms.val(a);
  });
  $("#subs").prop("disabled", !$("#noOfRoom").val());

  $('#subs').click(function subst() {
      var $rooms = $("#noOfRoom");
      var b = $rooms.val();
      if (b >= 1) {
          b--;
          $rooms.val(b);
      }
      else {
          $("#subs").prop("disabled", true);
      }
  });


  }

  // get form control
  get f() { return this.addSubscriptionForm.controls; }

  // set form field
  setFormField() {
    this.addSubscriptionForm = this.fb.group({
      fromDate: [this.dateFrom, [Validators.required]]
    });
  }

  // function to submit subscribe form
  submitSubscribeForm() {
    const updatedValues = []; // QTY","TIMESLOT","STATUS", "TO_DATE", "FROM_DATE", "SUBSCRIPTION_DAYS_TYPE
    if (this.quantity !== this.productDetailObj.weeklyData[0].qty) {
      updatedValues.push('QTY');
    }
    if (new Date(this.addSubscriptionForm.controls.fromDate.value).toLocaleDateString() !== new Date(this.productDetailObj.fromDate).toLocaleDateString()) {
      updatedValues.push('FROM_DATE')
    }
    console.log('checkDate', 'updatedValues', this.f.fromDate.value, updatedValues);
    // return;
    this.commonService.showSpinner();
    this.buyService.setFormField(this.productDetailObj, this.quantity, this.addSubscriptionForm.controls.fromDate.value,
      { editFlag: true, editVal: updatedValues });
    // if (this.orderType == 1) {
    //   this.buyOnce(this.productDetailObj);
    // }
    // return;
  }

  changeDate() {
    const formatDate = new Date(this.f.fromDate.value._d).toISOString()
    this.f.fromDate.setValue(formatDate);
  }

  // function to open golabl dialog
  openDialog() {
    // console.log('tableData', selectedMerchant);
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '400px',
      height: 'auto',
      disableClose: true,
      data: {type: 'noZipcode'}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result !== undefined) {
        this.router.navigate(['page/address']);
        // console.log('result', result);
        // this.activateAreaForm = false;
        // this.activateCustomerForm = true;
      }
    });
  }

  // function to navigate to subscription list once order placed
  orderPlaced() {
    $('#subscribeModal').modal('hide');
    this.router.navigate(['page/subscription'], { replaceUrl: true });
  }

  croneLogic() {
    // let total_days = (Math.round((this.dateFrom.getTime() - new Date().getTime()) / (60 * 60 * 1000 * 24)));
    if (this.croneTime.minute >= 60) {
      this.croneTime.hour += 1;
      this.croneTime.minute = this.croneTime.minute - 60;
      if (this.currentTime.HH >= this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        this.disableFlag = true;
      }
    } else {
      if (this.currentTime.HH > this.croneTime.hour) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        this.disableFlag = true;
      } else if (this.currentTime.HH === this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        this.disableFlag = true;
      }
    }
  }

  croneLogic2() {
    // let total_days = (Math.round((this.dateFrom.getTime() - new Date().getTime()) / (60 * 60 * 1000 * 24)));
    if (this.croneTime.minute >= 60) {
      this.croneTime.hour += 1;
      this.croneTime.minute = this.croneTime.minute - 60;
      if (this.currentTime.HH >= this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        // this.disableFlag = true;
      }
    } else {
      if (this.currentTime.HH > this.croneTime.hour) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        // this.disableFlag = true;
      } else if (this.currentTime.HH === this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.minDate.setDate(this.minDate.getDate() + 1);
        // this.disableFlag = true;
      }
    }
  }

  addQty(val) {
    if (val) {
      this.quantity += 1;
    } else {
      this.quantity -= 1;
    }
  }

  navigateToBasket() {
    this.router.navigate(['page/subscription'], { queryParams: { type: 'TOM' } })
  }

  // buyOnce(item) {
  //   this.commonService.showSpinner();
  //   this.buyService.setFormField(item, this.quantity, this.addSubscriptionForm.controls.fromDate.value, true);
  // }

  // function to open susbcription log
  openSubscriptionLog(id) {
    this.router.navigate(['page/subscription/list/' + id + '/log']);
  }

  deleteSubscription(subscription) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to delete this subscription!',
      icon: 'warning',
      showCancelButton: true,
      allowOutsideClick: false,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        const payload = {};
        this.productService.deleteSubscription(payload, subscription._id).subscribe(response => {
      if (response.status === 200) {
        this.commonService.showSuccess('Subscription deleted');
        this.sharedService.getCartData();
        this.router.navigate(['page/subscription'], { queryParams: { type: 'TOM' } })
      }
    });
        // Swal.fire(
        //   'Deleted!',
        //   'Your imaginary file has been deleted.',
        //   'success'
        // )
      // For more information about handling dismissals please visit
      // https://sweetalert2.github.io/#handling-dismissals
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        // Swal.fire(
        //   'Cancelled',
        //   'Your imaginary file is safe :)',
        //   'error'
        // )
      }
    })

  }

}
