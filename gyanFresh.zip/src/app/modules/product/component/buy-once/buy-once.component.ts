import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../serviceFile/product.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/app/serviceFile/common.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
declare let $: any;

@Component({
  selector: 'app-buy-once',
  templateUrl: './buy-once.component.html',
  styleUrls: ['./buy-once.component.scss']
})
export class BuyOnceComponent implements OnInit {
  today = new Date();
  timeSlotsArr;
  addCartForm: FormGroup;
  submitted: boolean = false;
  id;
  addedToCartFlag: boolean = false;
  productDetailObj;

  constructor(private productService: ProductService, private fb: FormBuilder, private route: ActivatedRoute, private router: Router,
              private commonService: CommonService, private sharedService: SharedService) {
    this.today.setDate(this.today.getDate() + 1);
   }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.productDetail(this.id);
    this.getTimeSlots();
    this.setFormField();
  }

  // function to get product detail
  productDetail(id) {
    this.productService.getProductDetail(id).subscribe(response => {
      this.productDetailObj = response.data;
      // console.log('productDetails', this.productDetailObj);
    });
  }

  getTimeSlots() {
    this.productService.getTimeSlot().subscribe(response => {
      this.timeSlotsArr = response && response.data ? response.data : '';
      this.timeSlotsArr.forEach(element => {
        element.timeFrame = element.from + ' - ' + element.to;
      });
      console.log('timeSlots', this.timeSlotsArr);
    });
  }
  get f() { return this.addCartForm.controls; }
  setFormField() {
    this.addCartForm = this.fb.group({
      productQuantity: [1, Validators.required],
      productId: [this.id, Validators.required],
      date: ['', Validators.required],
      timeFrame: ['', Validators.required],
      selectedSlot: ['']
    });
  }
  submitCartForm() {
    this.submitted = true;
    if (!this.addCartForm.valid) {
      console.log('notValidCartForm', this.addCartForm.controls);
      return;
    }
    // const isoDate = this.addCartForm.controls.date.value.toISOString();
    const payload = {
      qty: this.addCartForm.controls.productQuantity.value.toString(),
      productId: this.addCartForm.controls.productId.value,
      deliveryDate: this.addCartForm.controls.date.value.toISOString(),
      startTime: this.addCartForm.controls.selectedSlot.value.from,
      endTime: this.addCartForm.controls.selectedSlot.value.to
    };
    this.productService.addToCart(payload).subscribe(response => {
      if (response.status === 200) {
        // this.sharedService.getCartItems();
        this.commonService.showSuccess('Item added to cart');
        this.addedToCartFlag = true;
      }
    });
  }
  selectSlot(slot) {
    console.log('selectedSlot', slot);

    // $('.selectslotclick input[type="radio"],.selectslotclick input[type="checkbox"]').click(function () {
    //   $('.selectslotclick input[type="radio"]:not(:checked),.selectslotclick input[type="checkbox"]:not(:checked)').parent().removeClass("active");
    //   $('.selectslotclick input[type="radio"]:checked,.selectslotclick input[type="checkbox"]:checked').parent().addClass("active");
    //   });

    this.addCartForm.controls.selectedSlot.setValue(slot);
    this.addCartForm.controls.timeFrame.clearValidators();
    this.addCartForm.controls.timeFrame.updateValueAndValidity();
  }
  increaseValue(value) {
    const newVal = value + 1;
    this.addCartForm.controls.productQuantity.setValue(newVal);

  }
  decreaseValue(value) {
    if (value <= 1) {
      return;
    }
    const newVal = value - 1;
    this.addCartForm.controls.productQuantity.setValue(newVal);
  }
  navigateToCart() {
    this.router.navigate(['page/cart'], { replaceUrl: true });
  }

}
