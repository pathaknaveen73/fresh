import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyOnceComponent } from './buy-once.component';

describe('BuyOnceComponent', () => {
  let component: BuyOnceComponent;
  let fixture: ComponentFixture<BuyOnceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyOnceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyOnceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
