import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './component/product-list/product-list.component';
import { ProductService } from './serviceFile/product.service';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProductDetailComponent } from './component/product-detail/product-detail.component';
// import { BuyOnceComponent } from './component/buy-once/buy-once.component';
import { SubscribeComponent } from './component/subscribe/subscribe.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatIconModule} from '@angular/material/icon';
// import { EditCartComponent } from './component/edit-cart/edit-cart.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
// import { MAT_DATE_LOCALE } from '@angular/material/core';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { OnceComponent } from './component/once/once.component';
import { EditSubsComponent } from './component/edit-subs/edit-subs.component';

import { MomentUtcDateAdapter } from 'src/app/MomentUtcDateAdapter';
import { MatMomentDateModule, MAT_MOMENT_DATE_FORMATS } from '@angular/material-moment-adapter';
import { MAT_DATE_FORMATS, DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import { SkeletonModule } from '../skeleton/skeleton.module';

export const routes: Routes = [
  { path: 'list', component: ProductListComponent },
  { path: 'list/detail', component: ProductDetailComponent },
  // { path: 'list/:id/buyOnce', component: BuyOnceComponent },
  { path: 'list/:id/subscribe', component: SubscribeComponent },
  // { path: 'editCart/:id', component: EditCartComponent },
  { path: 'list/:id/once', component: OnceComponent },
  { path: 'list/:id/editSubs', component: EditSubsComponent },
  { path: '', redirectTo: 'list', pathMatch: 'full' }
];

@NgModule({
  declarations: [ProductListComponent,
     ProductDetailComponent,
      // BuyOnceComponent,
       SubscribeComponent,
        // EditCartComponent,
         OnceComponent,
          EditSubsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    LazyLoadImageModule,
    FormsModule,
    MatSelectModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatIconModule,
    ReactiveFormsModule,
    InfiniteScrollModule,
    CarouselModule,
    SkeletonModule
  ],
  exports: [
    ProductListComponent,
    ProductDetailComponent,
    // BuyOnceComponent,
    SubscribeComponent,
    // EditCartComponent
  ],
  providers: [ProductService, { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
  { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  { provide: DateAdapter, useClass: MomentUtcDateAdapter }]
})
export class ProductModule { }
