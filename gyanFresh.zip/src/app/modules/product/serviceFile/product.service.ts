import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class ProductService {

  constructor(private apiService: ApiService) { }

  getProductCat(payload) {
    const url = 'categories?offset=' + payload.offset + '&limit=' + payload.limit;
    return this.apiService.getApi(url);
  }
  getProductVariant(payload) {
    const url = 'products/' + payload.productId + '?offset=' + payload.offset + '&limit=' + payload.limit + '&itemName=' + payload.itemName;
    return this.apiService.getApi(url);
  }
  getProductDetail(payload) {
    const url = 'productDetail/' + payload;
    return this.apiService.getApi(url);
  }
  getTimeSlot() {
    const url = 'timeSlots';
    return this.apiService.getApi(url);
  }
  addToCart(payload) {
    const url = 'cartItems';
    return this.apiService.postApi(url, payload);
  }
  editCart(payload, id) {
    const url = 'cartItems/' + id;
    return this.apiService.putApi(url, payload);
  }
  subscribeProduct(payload) {
    const url = 'subscribeProduct';
    return this.apiService.postApi(url, payload);
  }

  // function to get all addresses
  getAllAddress() {
    const url = 'allAddress';
    return this.apiService.getApi(url);
  }

  // function to get nearest GFS
  getNearbyGFS() {
    const url = 'myNearbyGfs';
    return this.apiService.getApi(url);
  }

  updateSubscription(payload, id) {
    const url = 'subscriptionDetail/' + id;
    return this.apiService.putApi(url, payload);
  }

  // function to get auto recharge detail
  getWalletBalance() {
    const url = 'getAutoRechargeDetail';
    return this.apiService.getApi(url);
  }

  deleteSubscription(paylaod, id) {
    const url = 'subscriptionStatus/' + id;
    return this.apiService.putApi(url, paylaod);
  }

  // function to get list of available subscription coupon
  getCoupon(id) {
    const url = `userCouponListOnSubscription?productId=${id}`;
    return this.apiService.getApi(url);
  }

  // function to apply or remove coupon
  applyOrRemoveCoupon(type: number, payload) {
    let url = '';
    if (type === 1) {
      url = 'userApplyCouponOnSubscription';
    } else {
      url = 'userRemoveCoupon';
    }
    return this.apiService.postApi(url, payload);
  }
}
