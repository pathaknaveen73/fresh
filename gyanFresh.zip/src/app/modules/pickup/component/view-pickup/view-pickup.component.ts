import { Component, OnInit } from '@angular/core';
import { PickupService } from '../../serviceFile/pickup.service';
import { ActivatedRoute } from '@angular/router';
declare let $: any;

@Component({
  selector: 'app-view-pickup',
  templateUrl: './view-pickup.component.html',
  styleUrls: ['./view-pickup.component.scss']
})
export class ViewPickupComponent implements OnInit {
  id;
  pickupDetailArr;
  customerDetail;

  constructor(private pickupService: PickupService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.getPickupDetail(this.id);
    this.getProfileDetail();
  }

  // function to get pickup detail
  getPickupDetail(id) {
    this.pickupService.getPickupDetail(id).subscribe(response => {
      if (response.status === 200) {
        this.pickupDetailArr = response.data;
        this.pickupDetailArr[0].allproduct.forEach(element => {
          element.productDetails = JSON.parse(element.productDetails);
        });
        console.log('pickupDetailArr', this.pickupDetailArr);
      }
    });
  }

  // function to get user profile detail
  getProfileDetail() {
    this.pickupService.getUserProfile().subscribe(response => {
      if (response.status === 200) {
        this.customerDetail = response.data;
        console.log('customerDetail', this.customerDetail);
      }
    });
  }

}
