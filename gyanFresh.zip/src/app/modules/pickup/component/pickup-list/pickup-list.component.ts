import { Component, OnInit } from '@angular/core';
import { PickupService } from '../../serviceFile/pickup.service';
declare let $: any;

@Component({
  selector: 'app-pickup-list',
  templateUrl: './pickup-list.component.html',
  styleUrls: ['./pickup-list.component.scss']
})
export class PickupListComponent implements OnInit {
  today = new Date();
  pickupListArr;
  selectedDate;

  constructor(private pickupService: PickupService) { }

  ngOnInit(): void {
    /* filter datepicker start here */
  // $('#dp').datepicker({ isRTL: true });
  // $('#filteropen').on('click', function () {
  //   $('#dp').focus();
  // });
     /* filter datepicker end here */
     this.getPickupList();
  }

  // function to get pickup list
  getPickupList(date?) {
    if (date) {
      date = date.toISOString();
    }
    // console.log(date);
    this.pickupService.getPickupList(date ? date : null).subscribe(response => {
      if (response.status === 200) {
        this.pickupListArr = response.data;
        console.log('pickupListArr', this.pickupListArr);
      }
    });
  }

}
