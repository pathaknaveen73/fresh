import { Component, OnInit } from '@angular/core';
import { PickupService } from '../../serviceFile/pickup.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/serviceFile/common.service';
declare let $: any;

@Component({
  selector: 'app-add-pickup',
  templateUrl: './add-pickup.component.html',
  styleUrls: ['./add-pickup.component.scss']
})
export class AddPickupComponent implements OnInit {
  addPickupForm: FormGroup;
  submitted = false;
  pickupOrderArr;
  GFSlistArr;
  selectedGFS;
  changeGFSflag = false;
  hideButtonFlag = false;
  timeSlotsArr;
  allLocation;
  userPrimaryLocation;
  gfsAddress;

  constructor(private pickupService: PickupService, private router: Router, private fb: FormBuilder,
              private commonService: CommonService) { }

  ngOnInit(): void {
    // $('.datepicker').datepicker({ isRTL: true });
    this.getPickupOrder();
    this.nearbyGFS();
    this.getTimeSlots();
    // this.getAllAddress();
    this.setFormField();
  }

  // function to set add pickup form field
  setFormField() {
    this.addPickupForm = this.fb.group({
      gfs: ['', [Validators.required]],
      selectOrder: ['', [Validators.required]]
    });
    $('#timeSlotKK').hide();
  }

  // function to get form controls
  get f() { return this.addPickupForm.controls; }

  // function on submit form
  submit() {
    this.submitted = true;
    if (!this.addPickupForm.valid) {
      console.log('invalidAddpickupForm', this.addPickupForm.controls);
      return;
    }
    const orderId = this.addPickupForm.controls.selectOrder.value._id;
    // console.log('orderId', orderId)
    const payload = {
      gfsId: this.addPickupForm.controls.gfs.value._id
    };
    this.pickupService.addPickup(payload, orderId).subscribe(response => {
      if (response.status === 200) {
        this.commonService.showSuccess(response.message);
        this.router.navigate(['page/pickup'], { replaceUrl: true });
      } else {
        this.commonService.showError(response.message);
      }
    });
  }

  // function to get active pickup order list
  getPickupOrder() {
    this.pickupService.getActiveOrder().subscribe(response => {
      if (response.status === 200) {
        const pickupOrders = response.data;
        this.pickupOrderArr = [];
        pickupOrders.forEach(element1 => {
          if (element1.deliveryType === 'DELIVERY') {
            element1.allproduct.forEach(element2 => {
              element2.productDetails = JSON.parse(element2.productDetails);
            });
            this.pickupOrderArr.push(element1);
          }
        });
        console.log('pickupOrdersArr', this.pickupOrderArr);
      }
    });
  }

  // function to get nearby GFS
  nearbyGFS() {
    this.pickupService.getNearbyGFS().subscribe(response => {
      if (response.status === 200) {
        this.GFSlistArr = response.data.nearbyGfs;
        this.selectedGFS = response.data.primaryGfs.gfsId;
        this.gfsAddress = response.data.primaryGfs.gfsId.location.gfsName + ', ' + response.data.primaryGfs.gfsId.townId.location.townName;
        this.addPickupForm.controls.gfs.setValue(this.selectedGFS);
        this.addPickupForm.controls.gfs.updateValueAndValidity();
        console.log('GFSlistArr', this.GFSlistArr);
      }
    });
  }

  // function on change gfs button click
  btnClick() {
    this.changeGFSflag = true;
    this.hideButtonFlag = true;
  }

  // function on select gfs
  onSelectGFS(data) {
    console.log('selectedGFS', data);
    this.gfsAddress = data.location.gfsName + ', ' + data.town.location.townName;
    this.changeGFSflag = false;
    this.hideButtonFlag = false;
    this.addPickupForm.controls.gfs.setValue(data);
    this.addPickupForm.controls.gfs.updateValueAndValidity();
  }

  // function to get time slots
  getTimeSlots() {
    this.pickupService.getTimeSlot().subscribe(response => {
      if (response.status === 200) {
        this.timeSlotsArr = response && response.data ? response.data : '';
        this.timeSlotsArr.forEach(element => {
          element.timeFrame = element.from + ' - ' + element.to;
        });
        // if (this.data) {
        //   this.timeSlotsArr.forEach(element => {
        //     if ((element.from === this.data.startTime) && (element.to === this.data.endTime)) {
        //       this.selectedTimeSlot = element;
        //     }
        //   });
        //   this.checkTimeSlot();
        // }
        console.log('timeSlots', this.timeSlotsArr);
        // console.log('selectedTimeSlot', this.selectedTimeSlot);
      }
    });
  }

  // function on select a order from dropdown
  orderSelected(data) {
    if (!data) {
      $('#timeSlotKK').hide();
      return;
    }
    $('#timeSlotKK').show();
    console.log('selectedOrder', data);
    this.timeSlotsArr.forEach((element, i) => {
      if (element.from == data.timeSlot.startTime) {
        $('#selectslot_' + i).prop('checked', true);
      }
    });
  }

  // to get user all address and watch for user primary address
  getAllAddress() {
    this.pickupService.getAllAddress().subscribe(response => {
      if (response.status === 200) {
        this.allLocation = response.data.location;
        this.allLocation.forEach(element => {
          if (element.default === 'PRIMARY') {
            this.userPrimaryLocation = element;
          }
        });
      }
      console.log('userPrimaryLocation', this.userPrimaryLocation);
    });
  }

}
