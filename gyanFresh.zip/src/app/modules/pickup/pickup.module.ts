import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PickupListComponent } from './component/pickup-list/pickup-list.component';
import { AddPickupComponent } from './component/add-pickup/add-pickup.component';
import { ViewPickupComponent } from './component/view-pickup/view-pickup.component';
import { Routes, RouterModule } from '@angular/router';
import { PickupService } from './serviceFile/pickup.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatMomentDateModule, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';

export const routes: Routes = [
  { path: '', component: PickupListComponent, pathMatch: 'full' },
  { path: 'addPickup', component: AddPickupComponent },
  { path: 'viewPickup/:id', component: ViewPickupComponent }
];

@NgModule({
  declarations: [PickupListComponent, AddPickupComponent, ViewPickupComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatDatepickerModule,
    MatMomentDateModule
  ],
  exports: [PickupListComponent, AddPickupComponent, ViewPickupComponent],
  providers: [PickupService, {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}]
})
export class PickupModule { }
