import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';

@Injectable()
export class PickupService {

  constructor(private apiService: ApiService) { }

  // function to get active order list
  getActiveOrder() {
    const url = 'myInitiatedorders';
    return this.apiService.getApi(url);
  }

  // function to get pikcup list
  getPickupList(date?) {
    let url = 'pickupList';
    if (date) {
      url = 'pickupList?date=' + date;
    }
    return this.apiService.getApi(url);
  }

  // function to get picup detail
  getPickupDetail(id) {
    const url ='pickupDetail/' + id;
    return this. apiService.getApi(url);
  }

  // function to get nearest GFS
  getNearbyGFS() {
    const url = 'myNearbyGfs';
    return this.apiService.getApi(url);
  }

  // function to add pickup
  addPickup(payload, id) {
    const url = 'addPickup/' + id;
    return this.apiService.postApi(url, payload);
  }

  // function to get user profile data
  getUserProfile() {
    const url = 'getProfile';
    return this.apiService.getApi(url);
  }

  // function to get time slots
  getTimeSlot() {
    const url = 'timeSlots';
    return this.apiService.getApi(url);
  }

  // function to get all addresses
  getAllAddress() {
    const url = 'allAddress';
    return this.apiService.getApi(url);
  }
}
