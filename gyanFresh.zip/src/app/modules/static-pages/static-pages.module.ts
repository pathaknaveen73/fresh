import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TermsAndConditionComponent } from './component/terms-and-condition/terms-and-condition.component';
import { PrivacyPolicyComponent } from './component/privacy-policy/privacy-policy.component';
import { Routes, RouterModule } from '@angular/router';
import { StaticService } from './serviceFile/static.service';

export const routes: Routes = [
  { path: 'terms&Condition', component: TermsAndConditionComponent },
  { path: 'privacy', component: PrivacyPolicyComponent }
];

@NgModule({
  declarations: [TermsAndConditionComponent, PrivacyPolicyComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  providers: [StaticService],
  exports: [TermsAndConditionComponent, PrivacyPolicyComponent]
})
export class StaticPagesModule { }
