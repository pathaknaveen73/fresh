import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LandingApiService } from 'src/app/landing/serviceFile/landing-api.service';
import { CommonService } from 'src/app/serviceFile/common.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  // largeFooter = false;
  // smallFooter = true;
  // url: string;
  sendLinkForm: FormGroup;
  submitted = false;

  constructor(private fb: FormBuilder, private landingService: LandingApiService, private commonService: CommonService) {
    // this.url = window.location.href;
  }

  ngOnInit(): void {
    // if (this.url.search('page/home') > 0) {
    //   this.largeFooter = true;
    //   this.smallFooter = false;
    // } else {
    //   this.largeFooter = false;
    //   this.smallFooter = true;
    // }
    this.sendLinkFormField();
  }

  // function to set form field
  sendLinkFormField() {
    this.submitted = false;
    this.sendLinkForm = this.fb.group({
      mobile: ['', [Validators.required, Validators.pattern(/^[1-9]\d{9}$/)]],
    });
  }

  get f() { return this.sendLinkForm.controls; }

  // function to accept number only
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // function on submit
  submit() {
    this.submitted = true;
    if (!this.sendLinkForm.valid) {
      return;
    }
    const payload = {
      phone: this.f.mobile.value
    };
    this.landingService.sendAppLink(payload).subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.showSuccess('success');
        this.sendLinkFormField();
      } else {
        this.commonService.showError('success');
      }
    }, error => {
      this.commonService.showError(error);
    });
  }

}
