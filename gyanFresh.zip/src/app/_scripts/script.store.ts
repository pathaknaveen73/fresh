import { app_strings } from '../shared/_constant/app_strings';

interface Scripts {
  name: string;
  src: string;
}
export const ScriptStore: Scripts[] = [
  {name: 'razorpay', src: 'https://checkout.razorpay.com/v1/checkout.js'},
  {name: 'paytmProd', src: `https://securegw.paytm.in/merchantpgpui/checkoutjs/merchants/${app_strings.PAYTM_PRODUCTION.MID}.js`},
  {name: 'paytmStaging', src: `https://securegw-stage.paytm.in/merchantpgpui/checkoutjs/merchants/${app_strings.PAYTM_STAGING.MID}.js`},
  {name: 'juspay', src: `https://public.releases.juspay.in/hyper-sdk-web/HyperServices.js`}
];
