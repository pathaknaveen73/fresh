import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HowItWorkDeskComponent } from './how-it-work-desk.component';

describe('HowItWorkDeskComponent', () => {
  let component: HowItWorkDeskComponent;
  let fixture: ComponentFixture<HowItWorkDeskComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HowItWorkDeskComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HowItWorkDeskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
