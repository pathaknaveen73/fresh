import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StaticService {
  baseUrl = environment.api_url;
  adminRoute = `https://replica.gyandairy.com/api/admin/v1/`;

  constructor(private http: HttpClient) { }

  getPurityMeter(url): Observable<any> {
    const finalUrl = this.baseUrl + url;
    return this.http.get(finalUrl);
  }

  getWheel(url, token: string): Observable<any> {
    const headerr = new HttpHeaders({ 'wheelToken': token });
    const finalUrl = this.baseUrl + url;
    return this.http.get(finalUrl, { headers:  headerr});
  }

  redeemPrize(url, token: string, obj): Observable<any> {
    const headerr = new HttpHeaders({ 'wheelToken': token });
    const finalUrl = this.baseUrl + url;
    return this.http.post(finalUrl, obj, { headers:  headerr});
  }
}
