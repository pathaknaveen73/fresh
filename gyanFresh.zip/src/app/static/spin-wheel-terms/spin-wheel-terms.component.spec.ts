import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpinWheelTermsComponent } from './spin-wheel-terms.component';

describe('SpinWheelTermsComponent', () => {
  let component: SpinWheelTermsComponent;
  let fixture: ComponentFixture<SpinWheelTermsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpinWheelTermsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SpinWheelTermsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
