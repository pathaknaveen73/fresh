import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DailyStreakTermsComponent } from './daily-streak-terms.component';

describe('DailyStreakTermsComponent', () => {
  let component: DailyStreakTermsComponent;
  let fixture: ComponentFixture<DailyStreakTermsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DailyStreakTermsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DailyStreakTermsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
