import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurityMeterComponent } from './purity-meter.component';

describe('PurityMeterComponent', () => {
  let component: PurityMeterComponent;
  let fixture: ComponentFixture<PurityMeterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurityMeterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PurityMeterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
