import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TermGyanStarComponent } from './term-gyan-star.component';

describe('TermGyanStarComponent', () => {
  let component: TermGyanStarComponent;
  let fixture: ComponentFixture<TermGyanStarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TermGyanStarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TermGyanStarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
