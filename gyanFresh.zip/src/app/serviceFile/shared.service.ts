import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject, Observable, Subscription } from 'rxjs';
import { ApiService } from './api.service';

@Injectable()
export class SharedService {
  // count = 0;
  // simpleObservable = new Subject();
  // simpleObservable$ = this.simpleObservable.asObservable();
  userLocation = [];
  locationObservable = new Subject();
  locationObservable$ = this.locationObservable.asObservable();
  userProfileInfo = JSON.parse(localStorage.getItem('userInfo'));
  profileInfoObservable = new Subject();
  profileInfoObservable$ = this.profileInfoObservable.asObservable();
  // searchBox = new Subject();
  // searchBox$ = this.searchBox.asObservable();
  notificationCount = 0;
  notificationObservable = new Subject();
  notificationObservable$ = this.notificationObservable.asObservable();
  refVal = '0';
  isRef = new Subject();
  isRef$ = this.isRef.asObservable();
  offerVal = '0';
  isOffer = new Subject();
  isOffer$ = this.isOffer.asObservable();
  starData$ = new BehaviorSubject<any>('');
  homeData$ = new BehaviorSubject<any>('');
  cartCount$ = new BehaviorSubject<any>('');
  walletData$ = new BehaviorSubject<any>(0);
  home$: Subscription;
  profile$: Subscription;
  dailyStarBonus$ = new BehaviorSubject<any>(false);

  constructor(private apiService: ApiService) {
    // this.getCartItems();
    // this.getAllLocation();
    // this.getUserProfile();
    // console.log('Entered in Shared Service');
   }

  // function to get cart items
  // getCartItems() {
  //   const url = 'cartItems';
  //   this.apiService.getApi(url).subscribe(response => {
  //     if (response.status === 200) {
  //       const cartArr = response.data.cartItems;
  //       this.count = cartArr.length;
  //       this.simpleObservable.next(this.count);
  //     }
  //   });
  // }
  // getCount() {
  //   return this.simpleObservable$;
  // }

  // checkAddress() {
  //   // debugger
  //   this.address = localStorage.getItem('isAdd');
  //   this.isAddress.next(this.address);
  // }

  // getAddressValidation() {
  //   // debugger
  //   return this.isAddress$;
  // }

  // function to get user location
  getAllLocation() {
    const url = 'allAddress';
    this.apiService.getApi(url).subscribe(resonse => {
      if (resonse.status === 200) {

        this.userLocation = resonse.data.location;
        let primaryLocation;
        this.userLocation.forEach(element => {
          if (element.default === 'PRIMARY') {
            primaryLocation = element;
            return;
          }
        });
        localStorage.setItem('primaryLocation', JSON.stringify(primaryLocation));
        this.locationObservable.next(this.userLocation);
      }
    });
  }
  getPrimaryLocation() {
    const address = JSON.parse(localStorage.getItem('primaryLocation'));
    return address;
  }
  // function to get user's primary GFS
  nearbyGFS() {
    const url = 'myNearbyGfs';
    this.apiService.getApi(url).subscribe(response => {
      if (response.status === 200) {
        const primaryGFSid = response.data.primaryGfs.gfsId._id;
        localStorage.setItem('gfsId', primaryGFSid);
      }
    });
  }
  getUserLocation() {
    return this.locationObservable$;
  }
  getGfdId() {
    return localStorage.getItem('gfsId');
  }

  // function to watch for user profile info changes
  getUserProfileInfo() {
    return this.profileInfoObservable$;
  }

  // function to get user profile
  getUserProfile() {
    try {
      this.profile$.unsubscribe();
    } catch (error) {
      console.log(error);
    }
    const url = 'getProfile';
    this.profile$ = this.apiService.getApi(url).subscribe(response => {
      if (response.status === 200) {
        this.profileInfoObservable.next(response.data);
      }
    });
  }

  // // function to set search box param
  // setSearchBoxParam(data) {
  //   this.searchBox.next(data);
  // }

  // // function to watch for header param
  // getSearchBoxUrlParam() {
  //   return this.searchBox$;
  // }

  // function to get notification unread count
  getNotifications() {
    const url = 'getNotificationList';
    this.apiService.getApi(url).subscribe(response => {
      if (response.status === 200) {
        const notificationArr = response.data;
        // let unreadNotificationArr = [];
        // notificationArr.forEach(element => {
        //   if (element.read === 'UNREAD') {
        //     unreadNotificationArr.push(element);
        //   }
        // });
        // this.notificationCount = unreadNotificationArr.length;
        this.notificationObservable.next(notificationArr);
      }
    });
  }
  getNotificationCount() {
    return this.notificationObservable$;
  }

  saveReferralStatusLocal(val: string) {
    this.refVal = val;
    // debugger
    localStorage.setItem('isRef', val);
    this.isRef.next(this.refVal);
  }
  getReferralStatusVal() {
    return this.isRef$;
  }
  saveOfferStatusLocal(val: string) {
    this.offerVal = val;
    localStorage.setItem('isOffer', val);
    this.isOffer.next(this.offerVal);
  }
  getOfferStatusVal() {
    return this.isOffer$;
  }
  fetchUserHome() {
    try {
      this.home$.unsubscribe();
    } catch (error) {
      console.log(error);
    }
    const url = 'v2/userAppHome';
    this.home$ = this.apiService.getApi(url).subscribe(response => {
      if (response && response.status === 200) {
        localStorage.setItem('crone', JSON.stringify(response.data.orderCronTiming));
        if (response.data.customerReferral.status === 'ACTIVE') {
          // localStorage.setItem('isRef', '1');
          this.saveReferralStatusLocal('1');
        } else {
          // localStorage.setItem('isRef', '0');
          this.saveReferralStatusLocal('0');
        }
        if (response.data.displayOfferStatus.status === 'ACTIVE') {
          // localStorage.setItem('isRef', '1');
          this.saveOfferStatusLocal('1');
        } else {
          // localStorage.setItem('isRef', '0');
          this.saveOfferStatusLocal('0');
          // this.isRef = false;
        }
        this.starData$.next({status: response.data.gyanStarStatus.status});
        this.homeData$.next(response);
        this.dailyStarBonus$.next(response.data.isGsStreak);
      }
    });
  }

  resetAppHomeData() {
    this.homeData$.next('');
  }

  getCartData() {
    const url = 'tommorowOrders';
    this.apiService.getApi(url).subscribe(res => {
      if (res && res.status === 200) {
        let cartOnly = 0;
        res.data.forEach(element => {
          if (element.status !== 'SINGLE_PAUSED') {
            cartOnly += 1;
          }
        });
        const totalCount = cartOnly + res.gyanOrderOrCategory.length;
        this.cartCount$.next(totalCount);
      }
    });
  }

  fetchBalance() {
    const url = 'getAutoRechargeDetail';
    this.apiService.getApi(url).subscribe(res => {
      if (res && res.status === 200) {
        this.walletData$.next(res.data.walletAmount);
      }
    })
  }
}
