import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { SharedService } from './shared.service';
import { ApiService } from './api.service';
import { Router } from '@angular/router';
import { CommonService } from './common.service';
import { app_strings } from '../shared/_constant/app_strings';
import { FirebaseAnalyticsCustomService } from './firebase-analytics-custom.service';

declare var clevertap: any;

@Injectable()
export class BuyOnceService {
  dateFrom = new Date();
  buyOnceFrmGrp: FormGroup;
  currentTime;
  croneTime;
  dayForm: FormArray;
  dayArr;
  offerType;
  offerObj;
  quantity;
  dayType: string;
  editFlag = false;
  itemObj;
  updatedValue;
  alreadySubsFlag = false;
  editDate: string;
  constructor(private fb: FormBuilder, private sharedService: SharedService, private apiService: ApiService, private router: Router,
              private commonService: CommonService, private fireAnalytics: FirebaseAnalyticsCustomService) {}

  // set form field
  setFormField(item, qty: any, fromDate: any, editData?: { editFlag: boolean, editVal, alreadySubscribe?: boolean }, prouctType?: string, offerTypeVal?) {

    const userPrimaryLocation = this.sharedService.getPrimaryLocation();
    const gfs = this.sharedService.getGfdId();
    this.currentTime = { HH: new Date().getHours(), MM: new Date().getMinutes() };
    this.croneTime = JSON.parse(localStorage.getItem('crone'));
    this.croneTime.hour += 5;
    this.croneTime.minute += 30;
    this.quantity = qty;
    // debugger
    this.itemObj = item;
    const data = this.itemObj;
    try {
            clevertap.event.push(app_strings.CT_PRODUCT_ADDED_TO_CART, {
              'Product Name': data.productInfo.itemName,
              'Product Price': data.productInfo.price,
              'Product Category': data.productInfo.categoryId.categoryName,
              'ProductID': data.productId,
              'Product Image': data.productInfo.image,
              "platform": localStorage.getItem('deviceType')
            });
            this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.PRODUCT_ADDED_TO_CART, {
              'Product Name': data.productInfo.itemName,
              'Product Price': data.productInfo.price,
              'Product Category': data.productInfo.categoryId.categoryName,
              'ProductID': data.productId,
              'Product Image': data.productInfo.image,
            });
          } catch (error) {
            console.log('clevertapError');
          }
    if (editData.editFlag) {
      // debugger
      this.editFlag = editData.editFlag;
      // this.dateFrom = new Date();
      this.editDate = fromDate;
      this.updatedValue = editData.editVal;
      // this.dayType = dayType
    } else {
      this.dateFrom = new Date();
      this.dateFrom.setDate(this.dateFrom.getDate() + 1);
      // debugger
      this.croneLogic();
    }
    // debugger
    if (editData.alreadySubscribe) {
      this.alreadySubsFlag = true;
    }
    if (prouctType) {
      this.offerType = prouctType;
      this.offerObj = offerTypeVal;
      // console.log('itemObj', this.itemObj);
      // console.log('offerObj', this.offerObj);
    } else {
      this.offerType = '';
      this.offerObj = '';
    }
    this.dayArr = [
      { label: 'Sunday', value: 0 },
      { label: 'Monday', value: 1 },
      { label: 'Tuesday', value: 2 },
      { label: 'Wednesday', value: 3 },
      { label: 'Thursday', value: 4 },
      { label: 'Friday', value: 5 },
      { label: 'Saturday', value: 6 }
    ];
    this.buyOnceFrmGrp = this.fb.group({
      productId: [item._id],
      fromDate: [this.editFlag ? this.editDate : this.dateFrom],
      toDate: [''],
      orderType: 'SUBSCRIBE',
      deliveryType: 'DELIVERY',
      subtotal: [item && item.price ? item.price : 0],
      GrandTotal: [item && item.price ? item.price : 0],
      flatNo: [userPrimaryLocation && userPrimaryLocation.flatNo ? userPrimaryLocation.flatNo : ''],
      landmark: [userPrimaryLocation && userPrimaryLocation.landMark ? userPrimaryLocation.landMark : ''],
      area: [userPrimaryLocation.area._id],
      city: [userPrimaryLocation.city._id],
      zipcode: [userPrimaryLocation && userPrimaryLocation.zipcode ? userPrimaryLocation.zipcode : ''],
      coordinates: [userPrimaryLocation.coordinates],
      gfsId: [gfs],
      dayForm: this.fb.array([])
    });
    // this.addDayForm();
    this.dayForm = this.buyOnceFrmGrp.get('dayForm') as FormArray;
    for (let i = 0; i < 7; i++) {
      this.dayForm.push(this.createDayForm());
      this.buyOnceFrmGrp.get('dayForm')['controls'][i].controls.day.setValue(this.dayArr[i]);
      if (i === 6) {
        // this.submitSubscribeForm();
        break;
      }
    }
    // this.submitSubscribeForm();
    const promisee = new Promise((resolve, reject) => {
      if (!this.buyOnceFrmGrp.valid) {
        console.log('notValidSubscribeForm', this.buyOnceFrmGrp.controls);
        return;
      }
      const setWeeklyData = [];
      this.buyOnceFrmGrp.get('dayForm')['controls'].forEach(element => {
        setWeeklyData.push(
          {
            day: element.value.day.value,
            startTime: '',
            endTime: '',
            qty: element.value.qty,
            status: element.value.status,
            // isSelected: false,
            // id: ''
          }
        );
      });
      // console.log('weeklyData', this.setWeeklyData);

      // console.log('subsPayload', payload);
      // return;
      // this.commonService.showSpinner()
      if (this.editFlag) {
        const payload = {
          weeklyData: setWeeklyData,
          updatedValues: this.updatedValue,
          fromDate: this.buyOnceFrmGrp.controls.fromDate.value,
          subscriptionDaysType: 'ONCE'
        }
        const url = 'subscriptionDetail/' + this.itemObj._id;
        this.apiService.putApi(url, payload).subscribe(response => {
          if (response.status === 200) {
            this.sharedService.fetchBalance();
            this.commonService.hideSpinner();
            // const data = response.data;
            // data.productInfo = JSON.parse(data.productInfo);
            // console.log('checkEditResponse', data);
            this.commonService.showSuccess(response.message);
            console.log('itemObj', this.itemObj);
            const data = this.itemObj;
            try {
              clevertap.event.push(app_strings.CUSTOME.BUY_ONCE, {
                'Product Name': data.productInfo.itemName,
                'Product Price': data.productInfo.price,
                'Product Category': data.productInfo.categoryId.categoryName,
                'ProductID': data.productId,
                'Product Image': data.productInfo.image,
                'Start Date': this.buyOnceFrmGrp.controls.fromDate.value,
                'Charged ID': data.uniqueId,
                'Subscription Type': data.subscriptionDaysType,
                'Type': 'Order Detail',
                "platform": localStorage.getItem('deviceType')
              });
              this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.PRODUCT_BUY_ONCE, {
                'Product Name': data.productInfo.itemName,
                'Product Price': data.productInfo.price,
                'Product Category': data.productInfo.categoryId.categoryName,
                'ProductID': data.productId,
                'Product Image': data.productInfo.image,
                'Start Date': this.buyOnceFrmGrp.controls.fromDate.value,
                'Charged ID': data.uniqueId,
                'Subscription Type': data.subscriptionDaysType,
                'Type': 'Order Detail'
              });
            } catch (error) {
              console.log('clevertapError');
            }
            this.router.navigate(['page/subscription'], { queryParams: { type: 'TOM' } });
          } else {
            this.commonService.showError(response.message);
            this.commonService.hideSpinner();
          }
        });
      } else {
        // debugger
        const payload:any = {
          productId: this.buyOnceFrmGrp.controls.productId.value,
          fromDate: this.getRequiredDateFormat(new Date(this.buyOnceFrmGrp.controls.fromDate.value)),
          toDate: this.buyOnceFrmGrp.controls.toDate.value,
          weeklyData: setWeeklyData,
          orderType: this.buyOnceFrmGrp.controls.orderType.value,
          deliveryType: this.buyOnceFrmGrp.controls.deliveryType.value,
          tax: [],
          deliveryCharges: '0',
          discount: '0',
          offerId: '',
          subtotal: this.buyOnceFrmGrp.controls.subtotal.value,
          GrandTotal: this.buyOnceFrmGrp.controls.GrandTotal.value,
          flatNo: this.buyOnceFrmGrp.controls.flatNo.value,
          landMark: this.buyOnceFrmGrp.controls.landmark.value,
          area: this.buyOnceFrmGrp.controls.area.value,
          city: this.buyOnceFrmGrp.controls.city.value,
          zipcode: this.buyOnceFrmGrp.controls.zipcode.value,
          coordinates: this.buyOnceFrmGrp.controls.coordinates.value,
          gfsId: this.buyOnceFrmGrp.controls.gfsId.value,
          subscriptionDaysType: 'ONCE'
        };
        // debugger
        if (this.offerType) {
          payload.productId = this.offerType === 'offer' ? this.offerObj.item._id : this.offerObj.item;
          payload.offerId = this.offerObj._id;
          payload.offer = {
            offerType: this.offerObj.offerType,
            offerTypeValue: this.offerObj.offerTypeValue,
            title: this.offerObj.title,
            image: this.offerObj.image,
            thumbnail: this.offerObj.thumbnail
          }
        } else {
          payload.offer = {
            offerType: 'NONE',
            offerTypeValue: {}
          }
        }
        const url = 'subscribeProduct';
        this.apiService.postApi(url, payload).subscribe(response => {
          if (response.status === 200) {
            this.sharedService.fetchBalance();
            this.commonService.hideSpinner();
            const data = response.data;
            data.productInfo = JSON.parse(data.productInfo);
            // console.log('checkData', data);
            // this.commonService.showSuccess(response.message);
            resolve(response.message);
            // console.log('checkQty', this.quantity);
            if (this.quantity > 0) {
              try {
                clevertap.event.push(app_strings.CUSTOME.BUY_ONCE, {
                  'Product Name': data.productInfo.itemName,
                  'Product Price': data.productInfo.price,
                  'Product Category': data.productInfo.categoryId.categoryName,
                  'ProductID': data.productId,
                  'Product Image': data.productInfo.image,
                  'Start Date': data.fromDate,
                  'Charged ID': data.uniqueId,
                  'Subscription Type': data.subscriptionDaysType,
                  'Type': 'Subscribe',
                  "platform": localStorage.getItem('deviceType')
                });
                this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.PRODUCT_BUY_ONCE, {
                  'Product Name': data.productInfo.itemName,
                  'Product Price': data.productInfo.price,
                  'Product Category': data.productInfo.categoryId.categoryName,
                  'ProductID': data.productId,
                  'Product Image': data.productInfo.image,
                  'Start Date': data.fromDate,
                  'Charged ID': data.uniqueId,
                  'Subscription Type': data.subscriptionDaysType,
                  'Type': 'Subscribe'
                });
                if(data.isBuyFirst) {
                  clevertap.event.push(app_strings.CUSTOME.FIRST_TIME_BUY, {
                    'Product Name': data.productInfo.itemName,
                    'Product Price': data.productInfo.price,
                    'Product Category': data.productInfo.categoryId.categoryName,
                    'ProductID': data.productId,
                    'Product Image': data.productInfo.image,
                    'Start Date': data.fromDate,
                    'Charged ID': data.uniqueId,
                    'Subscription Type': data.subscriptionDaysType,
                    'Type': 'Subscribe',
                    "platform": localStorage.getItem('deviceType')
                  });
                  this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.FIRST_TIME_BUY, {
                    'Product Name': data.productInfo.itemName,
                    'Product Price': data.productInfo.price,
                    'Product Category': data.productInfo.categoryId.categoryName,
                    'ProductID': data.productId,
                    'Product Image': data.productInfo.image,
                    'Start Date': data.fromDate,
                    'Charged ID': data.uniqueId,
                    'Subscription Type': data.subscriptionDaysType,
                    'Type': 'Subscribe'
                  });
                  this.fireAnalytics.logFacebookPixelEvent(app_strings.FACEBOOK_PIXEL.FIRST_ORDER, {
                    'productName': data.productInfo.itemName,
                    'productPrice': data.productInfo.price,
                    'productId': data.productId,
                  });
                  this.fireAnalytics.logGoogleAnalyticsEvent(app_strings.GOOGLE_ANALYTICS.FIRST_ORDER, {
                    'event': app_strings.GOOGLE_ANALYTICS.FIRST_ORDER,
                    'productName': data.productInfo.itemName,
                    'productPrice': data.productInfo.price,
                    'productId': data.productId,
                  });
                } else {
                  clevertap.event.push(app_strings.CUSTOME.REPEAT_ORDER, {
                    'Product Name': data.productInfo.itemName,
                    'Product Price': data.productInfo.price,
                    'Product Category': data.productInfo.categoryId.categoryName,
                    'ProductID': data.productId,
                    'Product Image': data.productInfo.image,
                    'Start Date': data.fromDate,
                    'Charged ID': data.uniqueId,
                    'Subscription Type': data.subscriptionDaysType,
                    'Type': 'Subscribe',
                    "platform": localStorage.getItem('deviceType')
                  });
                  this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.REPEAT_ORDER, {
                    'Product Name': data.productInfo.itemName,
                    'Product Price': data.productInfo.price,
                    'Product Category': data.productInfo.categoryId.categoryName,
                    'ProductID': data.productId,
                    'Product Image': data.productInfo.image,
                    'Start Date': data.fromDate,
                    'Charged ID': data.uniqueId,
                    'Subscription Type': data.subscriptionDaysType,
                    'Type': 'Subscribe'
                  });
                  this.fireAnalytics.logFacebookPixelEvent(app_strings.FACEBOOK_PIXEL.REPEAT_ORDER, {
                    'productName': data.productInfo.itemName,
                    'productPrice': data.productInfo.price,
                    'productId': data.productId,
                  });
                  this.fireAnalytics.logGoogleAnalyticsEvent(app_strings.GOOGLE_ANALYTICS.REPEAT_ORDER, {
                    'event': app_strings.GOOGLE_ANALYTICS.REPEAT_ORDER,
                    'productName': data.productInfo.itemName,
                    'productPrice': data.productInfo.price,
                    'productId': data.productId,
                  });
                }
              } catch (error) {
                console.log('clevertapError');
              }
            }
            if (this.alreadySubsFlag) {
              // do nothing
            } else {
              // this.router.navigate(['page/subscription'], { queryParams: { type: 'TOM' } })
              this.sharedService.getCartData();
            }
          } else {
            this.commonService.showError(response.message);
            this.commonService.hideSpinner();
          }
        });
      }
    });
    return promisee;
  }

  // function to create form array
  createDayForm(): FormGroup {
    return this.fb.group({
      day: ['', [Validators.required]],
      dummyDay: [1],
      // startTime: ['', [Validators.required]],
      // endTime: ['', [Validators.required]],
      qty: [this.quantity, [Validators.required]],
      status: ['ACTIVE', [Validators.required]],
      timeFrame: ['']
    });
  }

  // function to add day form
  addDayForm() {
    this.dayForm = this.buyOnceFrmGrp.get('dayForm') as FormArray;
    for (let i = 0; i < 7; i++) {
      this.dayForm.push(this.createDayForm());
      this.buyOnceFrmGrp.get('dayForm')['controls'][i].controls.day.setValue(this.dayArr[i]);
      if (i === 6) {
        this.submitSubscribeForm();
        return;
      }
    }
  }

  // function to submit subscribe form
  submitSubscribeForm() {
    if (!this.buyOnceFrmGrp.valid) {
      console.log('notValidSubscribeForm', this.buyOnceFrmGrp.controls);
      return;
    }
    const setWeeklyData = [];
    this.buyOnceFrmGrp.get('dayForm')['controls'].forEach(element => {
      setWeeklyData.push(
        {
          day: element.value.day.value,
          startTime: '',
          endTime: '',
          qty: element.value.qty,
          status: element.value.status,
          // isSelected: false,
          // id: ''
        }
      );
    });
    // console.log('weeklyData', this.setWeeklyData);

    // console.log('subsPayload', payload);
    // return;
    // this.commonService.showSpinner()
    if (this.editFlag) {
      const payload = {
        weeklyData: setWeeklyData,
        updatedValues: this.updatedValue,
        fromDate: this.buyOnceFrmGrp.controls.fromDate.value,
        subscriptionDaysType: 'ONCE'
      }
      const url = 'subscriptionDetail/' + this.itemObj._id;
      this.apiService.putApi(url, payload).subscribe(response => {
        if (response.status === 200) {
          this.commonService.hideSpinner();
          // const data = response.data;
          // data.productInfo = JSON.parse(data.productInfo);
          // console.log('checkEditResponse', data);
          this.commonService.showSuccess(response.message);
          console.log('itemObj', this.itemObj);
          const data = this.itemObj;
          try {
            clevertap.event.push(app_strings.CUSTOME.BUY_ONCE, {
              'Product Name': data.productInfo.itemName,
              'Product Price': data.productInfo.price,
              'Product Category': data.productInfo.categoryId.categoryName,
              'ProductID': data.productId,
              'Product Image': data.productInfo.image,
              'Start Date': this.buyOnceFrmGrp.controls.fromDate.value,
              'Charged ID': data.uniqueId,
              'Subscription Type': data.subscriptionDaysType,
              'Type': 'Order Detail',
              "platform": localStorage.getItem('deviceType')
            });
          } catch (error) {
            console.log('clevertapError');
          }
          this.router.navigate(['page/subscription'], { queryParams: { type: 'TOM' } });
        } else {
          this.commonService.showError(response.message);
          this.commonService.hideSpinner();
        }
      });
    } else {
      // debugger
      const payload:any = {
        productId: this.buyOnceFrmGrp.controls.productId.value,
        fromDate: this.getRequiredDateFormat(new Date(this.buyOnceFrmGrp.controls.fromDate.value)),
        toDate: this.buyOnceFrmGrp.controls.toDate.value,
        weeklyData: setWeeklyData,
        orderType: this.buyOnceFrmGrp.controls.orderType.value,
        deliveryType: this.buyOnceFrmGrp.controls.deliveryType.value,
        tax: [],
        deliveryCharges: '0',
        discount: '0',
        offerId: '',
        subtotal: this.buyOnceFrmGrp.controls.subtotal.value,
        GrandTotal: this.buyOnceFrmGrp.controls.GrandTotal.value,
        flatNo: this.buyOnceFrmGrp.controls.flatNo.value,
        landMark: this.buyOnceFrmGrp.controls.landmark.value,
        area: this.buyOnceFrmGrp.controls.area.value,
        city: this.buyOnceFrmGrp.controls.city.value,
        zipcode: this.buyOnceFrmGrp.controls.zipcode.value,
        coordinates: this.buyOnceFrmGrp.controls.coordinates.value,
        gfsId: this.buyOnceFrmGrp.controls.gfsId.value,
        subscriptionDaysType: 'ONCE'
      };
      // debugger
      if (this.offerType) {
        payload.productId = this.offerType === 'offer' ? this.offerObj.item._id : this.offerObj.item;
        payload.offerId = this.offerObj._id;
        payload.offer = {
          offerType: this.offerObj.offerType,
          offerTypeValue: this.offerObj.offerTypeValue,
          title: this.offerObj.title,
          image: this.offerObj.image,
          thumbnail: this.offerObj.thumbnail
        }
      } else {
        payload.offer = {
          offerType: 'NONE',
          offerTypeValue: {}
        }
      }
      const url = 'subscribeProduct';
      this.apiService.postApi(url, payload).subscribe(response => {
        if (response.status === 200) {
          this.commonService.hideSpinner();
          const data = response.data;
          data.productInfo = JSON.parse(data.productInfo);
          console.log('checkData', data);
          this.commonService.showSuccess(response.message);
          try {
            clevertap.event.push(app_strings.CUSTOME.BUY_ONCE, {
              'Product Name': data.productInfo.itemName,
              'Product Price': data.productInfo.price,
              'Product Category': data.productInfo.categoryId.categoryName,
              'ProductID': data.productId,
              'Product Image': data.productInfo.image,
              'Start Date': data.fromDate,
              'Charged ID': data.uniqueId,
              'Subscription Type': data.subscriptionDaysType,
              'Type': 'Subscribe',
              "platform": localStorage.getItem('deviceType')
            });
          } catch (error) {
            console.log('clevertapError');
          }
          if (this.alreadySubsFlag) {
            // do nothing
          } else {
            // this.router.navigate(['page/subscription'], { queryParams: { type: 'TOM' } })
          }
        } else {
          this.commonService.showError(response.message);
          this.commonService.hideSpinner();
        }
      });
    }
  }

  // function to increase quantity
  // increaseValue(value, i) {
  //   const newVal = value + 1;
  //   this.addSubscriptionForm.get('dayForm')['controls'][i].controls.qty.setValue(newVal);

  // }

  // function to decrease quantity
  // decreaseValue(value, i) {
  //   if (value <= 1) {
  //     return;
  //   }
  //   const newVal = value - 1;
  //   this.addSubscriptionForm.get('dayForm')['controls'][i].controls.qty.setValue(newVal);
  // }

  croneLogic() {
    // debugger
    if (this.croneTime.minute >= 60) {
      this.croneTime.hour += 1;
      this.croneTime.minute = this.croneTime.minute - 60;
      if (this.currentTime.HH >= this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.dateFrom.setDate(this.dateFrom.getDate() + 1);
      }
    } else {
      if (this.currentTime.HH > this.croneTime.hour) {
        this.dateFrom.setDate(this.dateFrom.getDate() + 1);
      } else if (this.currentTime.HH === this.croneTime.hour && this.currentTime.MM >= this.croneTime.minute) {
        this.dateFrom.setDate(this.dateFrom.getDate() + 1);
      }
    }
    // if (this.editFlag && this.dayType === 'TOM') {
    //   // do something
    // } else if (this.editFlag && this.dayType === 'REST') {
    //   // do something
    // } else {

    // }
    // let total_days = (Math.round((this.dateFrom.getTime() - new Date().getTime()) / (60 * 60 * 1000 * 24)));
  }

  getRequiredDateFormat(date: Date) {
    let dd: any = date.getDate();
    let mm: any = date.getMonth() + 1;
    const yyyy = date.getFullYear();
    if (dd < 10) {
      dd = '0' + dd;
    }
    if (mm < 10) {
      mm = '0' + mm;
    }
    return `${yyyy}-${mm}-${dd}T00:00:00.000Z`;
  }
}
