import { Injectable } from '@angular/core';
import { SharedService } from './shared.service';

declare let clevertap: any;

interface PROFILE {
  Name: string;
  Email: any;
  identity: any;
  Phone: any;
  WalletStatus: any;
}

@Injectable({
  providedIn: 'root'
})
export class ClevertapService {

  constructor(private sharedService: SharedService) { }

  loginOrSignup(
    {Name,
    Email,
    Identity,
    Phone,
    WalletStatus,
    referallCode,
    deleteAccount,
    walletAmount,
    countryCode,
    deactivateAccount}
  ) {
    try {
      const primaryLocation = this.sharedService.getPrimaryLocation();
      clevertap.onUserLogin.push({
        Site: {
          Name, // String
          Identity,  // String or number
          Email, // Email address of the user
          Phone: countryCode + Phone,  // Phone (with the country code)
          // 'Wallet Status': WalletStatus,
          // 'Referral Code': referallCode,
          // 'Delete Account': deleteAccount,
          // 'Deactivate Account': deactivateAccount,
          'Wallet Amount': walletAmount,
          TownName: primaryLocation ? primaryLocation.city.location.townName : '',
          AreaName: primaryLocation ? primaryLocation.area.location.areaName : ''
        }
       });
    } catch (error) {
      console.log('clevertapError', error);
    }
  }
}
