import { Injectable } from '@angular/core';
import { AngularFireAnalytics } from '@angular/fire/analytics';
import { environment } from 'src/environments/environment';

declare let fbq:Function;
declare let gtag: Function;

// Declare gTM dataLayer array.
declare global {
  interface Window { dataLayer: any[]; }
}

@Injectable({
  providedIn: 'root'
})
export class FirebaseAnalyticsCustomService {
  envStatus = environment.paytm.script;

  constructor(private analytics: AngularFireAnalytics) { }

  logEventCustom(eventName: string, properties?: object) {
    // if (this.envStatus === 'paytmProd') {
    //   if (properties) {
    //     this.analytics.logEvent(eventName, properties);
    //   } else {
    //     this.analytics.logEvent(eventName);
    //   }
    // }
    }

  logFacebookPixelEvent(eventName: string, params?: object) {
    console.log(eventName, params)
    if (this.envStatus === 'paytmProd') {
      const id = new Date().getTime();
      if (params) {
        // send event with parameters value
        fbq('track', eventName, params, {eventID: `${eventName}_${id}`});
      } else {
        // send only event name
        fbq('track', eventName, {}, {eventID: `${eventName}_${id}`});
      }
    }
  }

  logGoogleAnalyticsEvent(eventName: string, params?: object) {
    // window.dataLayer.push({
    //   'event': eventName
    // })
    // console.log('check>>>', window.dataLayer);
    if (this.envStatus === 'paytmProd') {
      if (params) {
        // send event with parameters value
        // gtag('event', eventName, params);
        window.dataLayer.push(params);
      //   if ("ga" in window) {
      //     const tracker = window['ga'].getAll()[0];
      //     if (tracker) {
      //       tracker.send("event", eventName, params);
      //     }
      // }
      } else {
        // send only event name
        // gtag('event', eventName);
        window.dataLayer.push({
          event: eventName
        });
      //   if ("ga" in window) {
      //     const tracker = window['ga'].getAll()[0];
      //     if (tracker) {
      //       tracker.send("event", eventName);
      //     }
      // }
      }
    }
  }

  logRechargeEventFB(eventName: string, params?: object) {
    if (this.envStatus === 'paytmProd') {
      const id = new Date().getTime();
      const timeInterval = setInterval(() => {
        if (fbq['loaded']) {
          fbq('track', eventName, params, {eventID: `${eventName}_${id}`});
          // console.log(`clearingTimeIntervalFB>>>${eventName}`);
          clearInterval(timeInterval);
        }
      }, 500);
    }
  }

  logRechargeEventGA(eventName: string, params?: object) {
    if (this.envStatus === 'paytmProd') {
      const timeInterval = setInterval(() => {
        if (window.dataLayer) {
          // const tracker = window['ga'].getAll()[0];
          // if (tracker) {
          //     tracker.send("event", eventName, params);
          //   }
          // gtag('event', eventName, params);
          window.dataLayer.push(params);
          clearInterval(timeInterval);
        }
      }, 500);
    }
  }
}
