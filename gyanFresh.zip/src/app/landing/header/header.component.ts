import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LandingApiService } from '../serviceFile/landing-api.service';
import { FormControl } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { Subscription } from 'rxjs';

declare let $: any;
declare let clevertap: any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {
  searchTerm = new FormControl('');
  options = [];
  isHomePage = true;
  cityList = [];
  selectedCity = '';
  selectedCityId = '';
  placeholderImg = app_strings.PLACEHOLDER_IMAGE;
  city$: Subscription;

  constructor(private router: Router, private landingService: LandingApiService, private fireAnalytics: FirebaseAnalyticsCustomService) { }

  ngOnInit(): void {
    this.searchProduct();
    this.landingService.getFooter().subscribe(data => {
      if (data === 'home') {
        this.isHomePage = true;
        this.city$ = this.landingService.cityID.subscribe(res => {
          if (res && res.id) {
            this.selectedCityId = res.id;
            this.selectedCity = res.name;
          } else {
            this.selectCityHandle();
          }
        });
        // if (!this.selectedCityId) {
        //   this.selectCityHandle();
        // }
      } else {
        this.isHomePage = false;
      }
    });
  }

  ngOnDestroy() {
    try {
      this.city$.unsubscribe();
    } catch (error) {
      console.log(error);
    }
  }

  login() {
    this.router.navigate(['/login']);
  }

  // function to navigate to home page
  home() {
    this.router.navigate(['']);
  }

  // function to open searched product detail
  openSearchedProductDetail(productId) {
    // this.router.navigateByUrl('/page/product/list/' + productId);
    this.router.navigate(['/product'], { queryParams: { id: JSON.stringify(productId) } });
  }

  // function to submit search term
  searchProduct() {
    this.searchTerm.valueChanges.pipe(debounceTime(500)).subscribe(data => {
      if (!data) {
        this.options = [];
        return;
      }
      let payload = {
        product: data
      };
      console.log('wihoutLoginSearch', payload.product);
      this.landingService.searchRegularProduct(payload).subscribe(response => {
        if (response.status === 200) {
          this.options = [];
          this.options = response.data;
        }
      });
    });
  }

  selectCityHandle() {
    $('#cityModal').modal('show');
    if (!this.cityList.length) {
      this.landingService.getCity().subscribe(res => {
        if (res && res.status === 200) {
          this.cityList = res.data;
          console.log('cityList', this.cityList);
        }
      });
    } else {
      // $('#cityModal').modal('show');
    }
  }

  cityClickHandle(item) {
    this.selectedCity = item.location.townName;
    this.selectedCityId = item._id;
    this.landingService.cityID.next({id: item._id, name: this.selectedCity});
    $('#cityModal').modal('hide');
    clevertap.event.push(app_strings.CUSTOME.CITY_NAME, {
      "cityName": item.location.townName,
      "cityId": item._id,
      "platform": localStorage.getItem('deviceType')
    });
    this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.DEFAULT_CITY_SELECTED, {
      city_id: item._id,
      city_name: item.location.townName
    });
  }

  onImageError(e) {
    e.target.src = this.placeholderImg;
  }

}
