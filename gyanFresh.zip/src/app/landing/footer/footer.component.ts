import { Component, OnInit } from '@angular/core';
import { LandingApiService } from '../serviceFile/landing-api.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/serviceFile/common.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  largeFooter = false;
  smallFooter = true;
  sendLinkForm: FormGroup;
  submitted = false;
  addressss = localStorage.getItem('isAdd');
  isAddress = true;

  constructor( private landingService: LandingApiService, private fb: FormBuilder, private commonService: CommonService ) {
    if (this.addressss === '1') {
      this.isAddress = true;
    } else {
      this.isAddress = false;
    }
   }

  ngOnInit(): void {
    this.sendLinkFormField();
    // function to watch for url change for large and small footer
    this.landingService.getFooter().subscribe(data => {
      if (data === 'home') {
        this.largeFooter = true;
        this.smallFooter = false;
        // this.sendLinkFormField();
      } else {
        this.smallFooter = true;
        this.largeFooter = false;
      }
    });
  }

  // function to set form field
  sendLinkFormField() {
    this.submitted = false;
    this.sendLinkForm = this.fb.group({
      mobile: ['', [Validators.required, Validators.pattern(/^[1-9]\d{9}$/)]],
    });
  }

  get f() { return this.sendLinkForm.controls; }

  // function to accept number only
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // function on submit
  submit() {
    this.submitted = true;
    if (!this.sendLinkForm.valid) {
      return;
    }
    const payload = {
      phone: this.f.mobile.value
    };
    this.landingService.sendAppLink(payload).subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.showSuccess('success');
        this.sendLinkFormField();
      } else {
        this.commonService.showError('success');
      }
    }, error => {
      this.commonService.showError(error);
    });
  }

}
