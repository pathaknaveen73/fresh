import { EventEmitter, Injectable } from '@angular/core';
import { ApiService } from 'src/app/serviceFile/api.service';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable()
export class LandingApiService {
  authRequired;
  contentTypeRequired;

  private messageSource = new BehaviorSubject('default message');
  currentMessage = this.messageSource.asObservable();

  footer = new Subject();
  footer$ = this.footer.asObservable();

  // cityID = new EventEmitter<any>(true);
  cityID = new BehaviorSubject({ id: '', name: '' });

  constructor(private apiService: ApiService) { }

  changeMessage(message: string) {
    this.messageSource.next(message);
  }

  testApi() {
    this.authRequired = true;
    return this.apiService.fetch();
  }
  checkAccount(payload) {
    const url = 'checkAccount';
    return this.apiService.postApi(url, payload);
  }
  loginAccount(payload) {
    const url = 'login';
    return this.apiService.postApi(url, payload);
  }
  verifyOtp(payload) {
    const url = 'verifyOpt';
    return this.apiService.postApi(url, payload);
  }
  getCity() {
    const url = 'townsAreas';
    return this.apiService.getApi(url);
  }
  resendOtp(method: string) {
    const url = 'resendOtp?otpMode=' + method;
    return this.apiService.getApi(url);
  }
  register(payload) {
    const url = 'register';
    return this.apiService.postApi(url, payload);
  }
  requestAddArea(payload) {
    const url = 'addAreaRequest';
    return this.apiService.postApi(url, payload);
  }
  // getProductCat(payload) {
  //   const url = 'categories?offset=' + payload.offset + '&limit=' + payload.limit;
  //   return this.apiService.getApi(url);
  // }
  // getProductVariant(payload) {
  //   const url = 'products/' + payload.productId + '?offset=' + payload.offset + '&limit=' + payload.limit + '&itemName=' + payload.itemName;
  //   return this.apiService.getApi(url);
  // }

  // update device token after login
  updateDeviceToken(payload) {
    const url = 'updateDeviceToken';
    return this.apiService.postApi(url, payload);
  }

  // function to set footer param
  setFooter(data) {
    this.footer.next(data);
  }

  // function to watch for footer param
  getFooter() {
    return this.footer$;
  }

  // function to get products and offer for home before login screen
  getHomeData(cityid: string) {
    // const url = 'v2/webUserAppHome';
    const url = cityid ? `v2/userAppHome?cityId=${cityid}` : 'v2/userAppHome';
    return this.apiService.getApi(url);
  }

  // function to search product
  searchRegularProduct(payload) {
    const url = 'searchProductWeb';
    return this.apiService.postApi(url, payload);
  }

  // function to send app link
  sendAppLink(payload) {
    const url = 'sendAppLink';
    return this.apiService.postApi(url, payload);
  }

  getProducts(payload, cityid?: string) {
    const url = cityid ? `products/${payload.catId}?offset=${payload.offset}&limit=${payload.limit}&cityId=${cityid}&itemName=` : `products/${payload.catId}?offset=${payload.offset}&limit=${payload.limit}&itemName=`;
    return this.apiService.getApi(url);
  }

  // function to fetch offers list
  getOffers() {
    const url = 'offerList';
    return this.apiService.getApi(url);
  }

  // function to fetch referral amount
  getReferralMoney() {
    const url = 'getShareRefferralPoint';
    return this.apiService.getApi(url);
  }

  // function to fetch new specific banner
  getNewBanner(cityId) {
    const url = `getBanners?cityId=${cityId}`;
    return this.apiService.getApi(url);
  }
}
