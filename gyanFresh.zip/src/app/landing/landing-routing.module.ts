import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { LoginGuard } from '../guards/login.guard';
import { RegisterComponent } from './component/register/register.component';
import { LandingComponent } from './landing.component';
import { ProductDetailHomeComponent } from './component/product-detail/product-detail.component';
import { OfferDetailHomeComponent } from './component/offer-detail/offer-detail.component';
import { ContentComponent } from './component/content/content.component';


const routes: Routes = [
  { path: '', component: LandingComponent, children: [
  { path: '', component: HomeComponent, canLoad: [LoginGuard] },
  { path: 'login', component: LoginComponent, canLoad: [LoginGuard]},
  { path: 'register', component: RegisterComponent, canLoad: [LoginGuard] },
  {  path: 'product', component: ProductDetailHomeComponent, canLoad: [LoginGuard] },
  { path: 'offer/:id', component: OfferDetailHomeComponent, canLoad: [LoginGuard] },
  { path: 'content', component: ContentComponent, canLoad: [LoginGuard] }
  // { path: 'landing', component: LandingComponent },
  // { path: '', redirectTo: 'home', pathMatch: 'full', canLoad: [LoginGuard] }
  ] },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LandingRoutingModule { }
