import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { app_strings } from 'src/app/shared/_constant/app_strings';

declare let clevertap: any;

@Component({
  selector: 'app-offer-detail',
  templateUrl: './offer-detail.component.html',
  styleUrls: ['./offer-detail.component.scss']
})
export class OfferDetailHomeComponent implements OnInit {
  offerDetailArr;

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // clevertap.event.push(app_strings.OFFER_CHECK, {
    //   "platform": localStorage.getItem('deviceType')
    // });
    // if (!history.state.data) {
    //   this.router.navigate(['/']);
    // } else {
    //   this.offerDetailArr = [];
    //   this.offerDetailArr.push(history.state.data);
    // }
    this.route.queryParams.subscribe(res => {
      this.offerDetailArr = [];
      this.offerDetailArr.push(JSON.parse(res.data));
    });
  }

  // function to navigate to login
  navigateLogin() {
    this.router.navigate(['/login']);
  }

}
