import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferDetailHomeComponent } from './offer-detail.component';

describe('OfferDetailComponent', () => {
  let component: OfferDetailHomeComponent;
  let fixture: ComponentFixture<OfferDetailHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfferDetailHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferDetailHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
