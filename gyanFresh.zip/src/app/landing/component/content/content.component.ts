import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.scss']
})
export class ContentComponent implements OnInit, OnDestroy {
  type = 'about';
  route$: Subscription;

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    // this.type = this.route.snapshot.queryParams.type;
    this.route$ = this.route.queryParams.subscribe(res => {
      this.type = res.type;
    });
  }

  ngOnDestroy(): void {
    this.route$.unsubscribe();
  }

}
