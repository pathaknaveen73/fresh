import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { LandingApiService } from '../../serviceFile/landing-api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/serviceFile/common.service';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';
declare let $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterViewInit, OnDestroy {
  productCategoriesArr;
  productVariantsArr;
  productArr;
  offerArr;
  bannerArr;
  previousIdVal;
  selectedVal = 0;
  isDragging: boolean;
  limit = 6;
  offset = 0;
  productVariantsSubs: Subscription;
  selectedCatId;
  showLoadMore = true;
  offerListArr;
  isRef = false;
  referralAmount = 0;
  referralMsg = '';
  citySubs$: Subscription;
  cityid = '';
  customOptions: OwlOptions = {
    loop: false,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: ['', ''],
    autoplay: true,
    autoWidth: true,
    center: false,
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true,
  };
  bannerOptions: OwlOptions = {
    nav: true,
      loop: true,
       margin: 10,
      dots: true,
      autoplay: true,
      responsive: {
        0: {
          items: 1
         },
        600: {
          items: 1
        },
        1000: {
          items: 1
        },
        1200: {
          items: 1
        }
      }
  };

  verifyOtpSection: boolean = false;
  accessToken;
  phone;

  constructor(private landingService: LandingApiService, private router: Router, private commonService: CommonService,
              private fireAnalytics: FirebaseAnalyticsCustomService, 
              private route:ActivatedRoute) { }

  ngOnInit(): void {


    localStorage.removeItem('verifyOtpToken');
    this.landingService.setFooter('home');
    // $('.owl-carousel').owlCarousel({
    //   nav: true,
    //   loop: true,
    //    margin: 10,
    //   dots: false,
    //   autoplay: true,
    //   responsive: {
    //     0: {
    //       items: 1
    //      },
    //     600: {
    //       items: 1
    //     },
    //     1000: {
    //       items: 1
    //     },
    //     1200: {
    //       items: 1
    //     }
    //   }
    // });

    // this.productCategroies();
    // this.getOffersList();
    // this.getHomeData();     
    
     /* here come from admin panel customer as login */
    this.route.queryParams.subscribe(params => {
      console.log(params); 
      this.phone = params.phone;
      console.log(this.phone); 
    });
    if(this.phone){
      this.customerAslogin();
    } 

    /* end */


    this.citySubs$ = this.landingService.cityID.subscribe(res => {
      // this.cityid = res;
      // if (this.cityid) {
      //   this.getHomeData();
      // } else {
      //   this.getHomeData();
      // }
      if (res && res.id) {
        this.cityid = res.id;
        // this.getNewBannerList();
      }
      this.getHomeData();
    });

   


  }

/* here come from admin panel customer as login */
customerAslogin(): void {

  let payload = {
    phone: this.phone
  };

    // localStorage.removeItem('userToken');
    // localStorage.removeItem('gyanReferralCode');      
    // localStorage.removeItem('gName');
    // localStorage.removeItem('user_idGyan');
    // localStorage.removeItem('userStatus');
    // localStorage.removeItem('gPhone');
    // localStorage.removeItem('verifyOtpToken');
    // localStorage.removeItem('userLocation');  


  this.landingService.loginAccount(payload).subscribe(response => {
    if (response.status === 200) {
      this.accessToken = response.data.token;
      this.verifyOtpSection = true;
      localStorage.removeItem('verifyOtpToken');
      localStorage.removeItem('userLocation');  
      localStorage.setItem('verifyOtpToken', response.data.token);
      localStorage.setItem('userLocation', JSON.stringify(response.data.location));      
      this.submitOtp();    

    } else {
      this.commonService.showError(response.message);
    }
  });
}

submitOtp() {  
  let payload = {   
    otp: '111111',
    loginAs:'admin'
  };
  this.commonService.showSpinner();
  this.landingService.verifyOtp(payload).subscribe(response => {
    this.commonService.hideSpinner();
    if (response.status === 200) {
      // debugger
      localStorage.setItem('userToken', this.accessToken);
      localStorage.setItem('gyanReferralCode', response.data.myReferralCode);
      // localStorage.setItem('userEmail', response.data.email);
      localStorage.setItem('gName', response.data.fullName);
      localStorage.setItem('user_idGyan', response.data._id);
      localStorage.setItem('userStatus', response.data.status);
      localStorage.setItem('gPhone', response.data.phone);
      //this.commonService.showSuccess('Login Successfully');
      localStorage.removeItem('verifyOtpToken');
      let location = response.data.location;
      // location = [];
      try {
        const splitName = response.data.fullName.split(' ');
        const loc = { TownName: '', AreaName: '' };
        console.log('---location----',loc);
        if (location.length) {
          location.forEach(element => {
            if (element.default === 'PRIMARY') {
              loc.TownName = element.city.location.townName;
              loc.AreaName = element.area.location.areaName;
            }
          });
        }     
        
      } catch (error) {
      }
     
      //  debugger
      if (location.length) {
        localStorage.setItem('isAdd', '1');
        console.log('/page/subscription/list');
        this.router.navigate(['/page/subscription/list'],{queryParams:{type:'TOM'}});
        setTimeout(()=>{
          window.location.reload();
        },500);
       
      } else {
        localStorage.setItem('isAdd', '0');
        const title = [];
        this.router.navigate(['page/address/newAddress'], { queryParams: { title: JSON.stringify(title), first: '1' } });
      }    
    } else {
      this.commonService.showWarning(response.message);
    }
  }, error => {
    this.commonService.showError(error);
    this.commonService.hideSpinner();
  });
}


 /* end */





  // function to get product categories
  // productCategroies() {
  //   const payload = {
  //     offset: 0,
  //     limit: 8
  //   };
  //   this.landingService.getProductCat(payload).subscribe(response => {
  //     if (response.status === 200) {
  //       this.productCategoriesArr = response.data;
  //     // this.variantLabel = this.productCategoriesArr[0].categoryName;
  //       const productId = this.productCategoriesArr[0]._id;
  //       const offset = 0;
  //       const limit = 6;
  //       const nameOfItem = '';
  //       this.productVariant(productId, offset, limit, nameOfItem);
  //     }
  //   });
  // }
  // function to get product variants on first load
  // productVariant(id: number, offsetVal: number, limitVal: number, nameOfItem: string) {
  //   const payload = {
  //     productId: id,
  //     offset: offsetVal,
  //     limit: limitVal,
  //     itemName: nameOfItem
  //   };
  //   this.landingService.getProductVariant(payload).subscribe(response => {
  //     if (response.status === 200) {
  //       this.productVariantsArr = response.data;
  //     }
  //   });
  // }
  // function to get product variant on user input
  // getProductVariant(product) {
  //   if (this.productVariantsArr.length > 0 && this.productVariantsArr[0].categoryId === product._id) {
  //     return;
  //   }
  //   const payload = {
  //     productId: product._id,
  //     offset: 0,
  //     limit: 6,
  //     itemName: ''
  //   };
  //   this.landingService.getProductVariant(payload).subscribe(response => {
  //     if (response.status === 200) {
  //       this.productVariantsArr = response.data;
  //     }
  //   });
  // }

  ngAfterViewInit(): void {
    $('#landingProductCat0').addClass('active');
  }

  // function on destroy of the component
  ngOnDestroy(): void {
    this.landingService.setFooter('notHome');
    if (this.productVariantsArr) {
      this.productVariantsSubs.unsubscribe();
    }
    this.citySubs$.unsubscribe();
  }

  // function to get home data
  getHomeData() {
    this.offset = 0;
    this.commonService.showSpinner();
    this.landingService.getHomeData(this.cityid).subscribe(response => {
      if (response.status === 200) {
        this.commonService.hideSpinner();
        this.offerArr = response.data.offers;
        this.productArr = response.data.categories;
        this.bannerArr = response.data.banners;
        this.getProductVariant(this.productArr[0]._id);
        this.selectedCatId = this.productArr[0]._id;
        if (response.data.customerReferral.status === 'ACTIVE') {
          localStorage.setItem('isRef', '1');
          this.getReferralAmount();
          this.isRef = true;
        } else {
          localStorage.setItem('isRef', '0');
          this.isRef = false;
        }
        if (this.cityid) {
          this.getNewBannerList();
        }
      } else {
        this.commonService.hideSpinner();
      }
    }, error => {
      this.commonService.showError(error);
      this.commonService.hideSpinner();
    });
  }

  // function to get referral amount
  getReferralAmount() {
    this.landingService.getReferralMoney().subscribe(res => {
      this.referralAmount = res.data.toAmount;
      this.referralMsg = res.data.message;
    });
  }

  // function to get product variant
  getProductVariant(itemId, condition?, userInput?: boolean) {
    if (userInput) {
      // hit fb event
      this.fireAnalytics.logFacebookPixelEvent(app_strings.FACEBOOK_PIXEL.PRODUCT_CATEGORY);
      this.fireAnalytics.logGoogleAnalyticsEvent(app_strings.GOOGLE_ANALYTICS.PRODUCT_CATEGORY);
    }
    const ob = {
      catId: itemId,
      limit: this.limit,
      offset: this.offset
    }
    this.productVariantsSubs = this.landingService.getProducts(ob, this.cityid).subscribe(res => {
      if (res && res.status === 200) {
        if (condition) {
          const result = [] = res.data;
          result.forEach(element => {
            this.productVariantsArr.push(element);
          });
          // this.productVariantsArr.push(res.data);
        } else {
          this.productVariantsArr = [];
          this.productVariantsArr = res.data;
        }
        if (res.data?.length !== 6) {
          this.showLoadMore = false;
        } else {
          this.showLoadMore = true;
        }
      }
    })
  }

  // function to open product detail
  openProductDetail(item) {
    // this.router.navigate(['/product/' + item._id], { state: { data: item.itemId } });
    this.router.navigate(['/product'], { queryParams: { id: JSON.stringify(item) } });
  }

  // function to open offer detail
  openOfferDetail(offer) {
    this.router.navigate(['/offer/' + offer._id], { state: { data: offer } });
  }

  // function to get offers list
  getOffersList() {
    this.landingService.getOffers().subscribe(response => {
      if (response.status === 200) {
        this.offerListArr = response.data;
        // this.offerArrived = true;
      }
    });
  }

  handleProductCategoryBannerClick(val) {
    // this.animatethis(val, 5000);
    $('html, body').animate({
      scrollTop: $('#ourProduct').offset().top + -100
  }, 1000);
    // $('.product_list_wraper ul').scrollTo('#' + val);
    if (val !== this.selectedCatId) {
      $('.product_list_wraper').animate({scrollLeft: $('#' + val).position().left}, 500);
      this.getProductVariant(val, false, true);
    }
    this.selectedCatId = val;
  }

  getNewBannerList() {
    this.landingService.getNewBanner(this.cityid).subscribe(res => {
      if (res && res.status === 200) {
        console.log('checkNewBanner', res);
        if (res && res.data && res.data.length) {
          this.bannerArr = [];
          this.bannerArr = res.data;
        }
      }
    });
  }

}
