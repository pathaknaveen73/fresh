import { Component, OnInit, OnDestroy, ElementRef } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { LandingApiService } from '../../serviceFile/landing-api.service';
import { Observable, fromEvent } from 'rxjs';
import { CommonService } from 'src/app/serviceFile/common.service';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { GlobalDialogComponent } from 'src/app/shared/global-dialog/global-dialog.component';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { debounceTime, take } from 'rxjs/operators';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
declare let $: any;
declare var clevertap: any;

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit, OnDestroy {
  customerDetailsForm: FormGroup;
  submitted: boolean = false;
  customerAreaForm: FormGroup;
  cityListArr = [];
  areaListArr = [];
  activateAreaForm: boolean = false;
  activateCustomerForm: boolean = false;
  selectedAreaArr = [];
  city = '5eabd0bd6cff8948c1b2ec18';
  sortedAreaArr = [];
  disabelAreaNextBtn: boolean = false;
  activateAddressForm: boolean = false;
  addAddressForm: FormGroup;
  submittedAddress: boolean = false;
  addressFormSkipped: boolean = false;
  activateOtpForm: boolean = false;
  // verifyOtpForm: FormGroup;
  accessToken;
  submittedOtp: boolean = false;
  chooseCiyEnable: boolean = false;
  noLocationEnable: boolean = false;
  areaForRequest;
  userCoordinates;
  selectedCity = '';
  selectedArea;
  resend = false;
  timeLeft = 30;
  intervalId;
  addressType = [ { label: 'Individual House', value: 'OWN_HOUSE' }, { label: 'Apartment', value: 'APARTMENT' } ];
  selectedAddressType;
  apiKey = 'AIzaSyDAIJ08X0BznyCJXQiD5Dt3cRXWoj8WZd8';
  mapApiUrl = 'https://maps.googleapis.com/maps/api/geocode/json?';
  config = {
    allowNumbersOnly: true,
    length: 6,
    isPasswordInput: false,
    disableAutoFocus: false,
    placeholder: '',
    inputStyles: {
      'width': '50px',
      'height': '50px'
    }
  };
  otp: string;
  isRef = false;
  styleHeight = 50;
  disableAddressBtn = true;

  constructor(private formBuilder: FormBuilder, private landingService: LandingApiService,
              private commonService: CommonService, private router: Router, public dialog: MatDialog,
              private el: ElementRef, private fireAnalytics: FirebaseAnalyticsCustomService) {}

  ngOnInit(): void {
    localStorage.removeItem('verifyOtpToken');
    const ref = localStorage.getItem('isRef');
    if (ref && ref === '1') {
      this.isRef = true;
    } else {
      this.getReferralAmount();
    }
    this.landingService.setFooter('notFooter');
    this.getAllCity();
    this.setAddressFormField();
    this.setFormField();
    // this.setVerifyOtpFormField();
    // this.setCustomerAreaFormField();
    this.activateAddress();

  }

  get f() { return this.customerDetailsForm.controls; }

  setFormField() {
    this.customerDetailsForm = this.formBuilder.group({
      mobile: ['', [Validators.required, Validators.pattern(/^[1-9]\d{9}$/)]],
      fullName: ['', [Validators.required, Validators.pattern(/^[a-zA-Z][a-zA-Z ]*$/)]],
      // tslint:disable-next-line: max-line-length
      // email: ['', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]],
      email: [''],
      referralCode: ['']
    });
  }

  submitCustomerForm() {
    this.submitted = true;
    if (!this.customerDetailsForm.valid) {
      for (const key of Object.keys(this.customerDetailsForm.controls)) {
        if (this.customerDetailsForm.controls[key].invalid) {
          const invalidControl = this.el.nativeElement.querySelector('[formcontrolname="' + key + '"]');
          // invalidControl.focus();
          this.scrollToFirstInvalidControl(invalidControl);
          break;
       }
  }
      return;
    }
    const termAccepted = document.getElementsByClassName('checkboxClass')[0]['checked'];
    if (!termAccepted) {
      this.commonService.showWarning('Please confirm the Terms & Conditions');
      return;
    }
    let payload1 = {
      fullName: this.customerDetailsForm.controls.fullName.value,
      email: this.customerDetailsForm.controls.email.value,
      countryCode: '+91',
      phone: this.customerDetailsForm.controls.mobile.value,
      usedReferralCode: this.customerDetailsForm.controls.referralCode &&
        this.customerDetailsForm.controls.referralCode.value ? this.customerDetailsForm.controls.referralCode.value : '',
      city: this.addAddressForm.controls.city.value.id,
      area: this.addAddressForm.controls.area &&
        this.addAddressForm.controls.area.value ? this.addAddressForm.controls.area.value : '',
      addressTitle: this.addAddressForm.controls.title &&
        this.addAddressForm.controls.title.value ? this.addAddressForm.controls.title.value : '',
      flatNo: this.addAddressForm.controls.flat &&
        this.addAddressForm.controls.flat.value ? this.addAddressForm.controls.flat.value : '',
      landMark: this.addAddressForm.controls.landmark &&
        this.addAddressForm.controls.landmark.value ? this.addAddressForm.controls.landmark.value : '',
      zipcode: '',
      lognitude: this.addAddressForm.controls.long.value,
      lattitude: this.addAddressForm.controls.lat.value,
      addressType: this.addAddressForm.controls.addressType.value ? this.addAddressForm.controls.addressType.value : ''
    };
    this.commonService.showSpinner();
    this.landingService.register(payload1).subscribe(resp => {
      if (resp.status === 200) {
        this.commonService.hideSpinner();
        try {
          clevertap.event.push(app_strings.CT_SEND_OTP_SUCCESS, {
            'phoneNumber': `${payload1.countryCode}${payload1.phone}`,
            "platform": localStorage.getItem('deviceType')
          });
          this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.OTP_SEND, {
            phoneNumber: `${payload1.countryCode}${payload1.phone}`
          });
        } catch (error) {
        }
        localStorage.setItem('verifyOtpToken', resp.data.token);
        this.accessToken = resp.data.token;
        this.activateCustomerForm = false;
        this.activateOtpForm = true;
        window.scrollTo(0,0);
        this.resendOtpTimer();
      } else {
        this.commonService.hideSpinner();
        this.commonService.showError(resp.message);
      }
    }, err => {
      this.commonService.hideSpinner();
    });
    // let payload = {
    //   phone: this.customerDetailsForm.controls.mobile.value,
    //   countryCode: '+91',
    //   email: this.customerDetailsForm.controls.email.value
    // };
    // this.landingService.checkAccount(payload).subscribe(response => {
    //   if (response.status === 200) {

    //   } else if (response.status === 409) {
    //     this.commonService.showWarning(response.message);
    //   } else {
    //     debugger
    //     this.commonService.showError(response.message);
    //   }
    // });

  }

  // get a() { return this.customerAreaForm.controls; }

  // setCustomerAreaFormField() {
  //   this.customerAreaForm = this.formBuilder.group({
  //     city: [this.cityListArr && this.cityListArr.length > 0 ? this.cityListArr[1] : '', Validators.required],
  //     area: ['', Validators.required]
  //   });
  // }

  getAllCity() {
    this.landingService.getCity().subscribe(response => {
      $('#noChoose').fadeOut();
      const dataArr = response && response.data ? response.data : [];
      dataArr.forEach(element => {
        this.cityListArr.push({ id: element._id, cityName: element.location.townName,
        areaArr: this.getArea(element.area)});
      });
      // this.selectedCity = this.cityListArr[0];
      this.chooseCiyEnable = true;
      // this.sortedAreaArr = this.selectedCity.areaArr;
      // this.selectedAreaArr = this.selectedCity.areaArr;
    });
    // this.selectedCity = this.cityListArr[1];

  }

  getArea(element) {
    let data = [];
    element.forEach(abc => {
      data.push({ id: abc._id, areaName: abc.location.areaName});
      this.areaListArr.push(abc);
    });
    return data;
  }

  onSelectCity(val) {
    // this.selectedAreaArr = this.areaListArr.filter( obj =>
    //   obj && obj.townId ? (obj.townId.indexOf(val) >= 0) : false
    // );
    this.selectedAreaArr = val.areaArr;
    // this.sortedAreaArr = val.areaArr;
    $('#choose').fadeIn();
    $('#noChoose').fadeOut();
    this.chooseCiyEnable = true;
    // this.customerAreaForm.controls.area.setValue('');
    // this.customerAreaForm.controls.area.updateValueAndValidity();
  }

  onSelectArea(val) {
    this.selectedArea = val;
    // this.customerAreaForm.controls.area.setValue(val);
    // this.customerAreaForm.controls.area.updateValueAndValidity();
  }
  searchArea(e) {
    const val = e.target.value;
    this.areaForRequest = e.target.value;
    if (!val) {
      // this.sortedAreaArr = this.selectedAreaArr;
      this.sortedAreaArr = [];
      $('#choose').fadeIn();
      $('#noChoose').fadeOut();
      return;
    }
    this.sortedAreaArr = this.selectedAreaArr.filter( obj =>
      obj && obj.areaName ? (obj.areaName.toLowerCase().indexOf(val.toLowerCase()) >= 0) : false
    );
    if(this.sortedAreaArr && this.sortedAreaArr.length === 0) {
      $('#choose').fadeOut();
      $('#noChoose').fadeIn();
    } else {
      $('#choose').fadeIn();
      $('#noChoose').fadeOut();
    }
  }
  activateAddress() {
    // this.activateAreaForm = false;
    this.activateAddressForm = true;
  }
  get ad() { return this.addAddressForm.controls; }
  setAddressFormField() {
    this.addAddressForm = this.formBuilder.group({
      title: ['Home', Validators.required],
      flat: ['', [Validators.required]],
      landmark: [''],
      city: ['', [Validators.required]],
      // area: ['', [Validators.required]],
      // zipcode: ['', [Validators.required, Validators.pattern(/^[1-9][0-9]{5}$/)]],
      lat: [''],
      long: [''],
      // addressType: ['OWN_HOUSE', [Validators.required]]
      addressType: ['']
    });
    this.ad.flat.disable();
  }
  submitAddressForm() {
    this.submittedAddress = true;
    if (this.ad.flat.disabled) {
      this.commonService.showError('Please enter address');
      return;
    }
    if (!this.addAddressForm.valid) {
      // this.addAddressForm.markAllAsTouched();
      // this.scrollToFirstInvalidControl();
      for (const key of Object.keys(this.addAddressForm.controls)) {
        if (this.addAddressForm.controls[key].invalid) {
          const invalidControl = this.el.nativeElement.querySelector('[formcontrolname="' + key + '"]');
          // invalidControl.focus();
          this.scrollToFirstInvalidControl(invalidControl);
          break;
       }
  }
      return;
    }
    // console.log('checkValue', this.ad);
    // return;
    this.openDialog1();
    // this.activateAddressForm = false;
    // this.activateCustomerForm = true;
  }
  private scrollToFirstInvalidControl(firstInvalidControl) {
    // const firstInvalidControl: HTMLElement = this.el.nativeElement.querySelector(
    //   "form .ng-invalid"
    // );


    window.scroll({
      top: this.getTopOffset(firstInvalidControl),
      left: 0,
      behavior: "smooth"
    });

    fromEvent(window, "scroll")
      .pipe(
        debounceTime(100),
        take(1)
      )
      .subscribe(() => firstInvalidControl.focus());
  }

  private getTopOffset(controlEl: HTMLElement): number {
    const labelOffset = 150;
    return controlEl.getBoundingClientRect().top + window.scrollY - labelOffset;
  }
  skipAddressForm() {
    this.addressFormSkipped = true;
    this.activateAddressForm = false;
    this.activateCustomerForm = true;

  }
  // setVerifyOtpFormField() {
  //   this.verifyOtpForm = this.formBuilder.group({
  //     verifyOtp1: ['', Validators.required],
  //     verifyOtp2: ['', Validators.required],
  //     verifyOtp3: ['', Validators.required],
  //     verifyOtp4: ['', Validators.required],
  //     verifyOtp5: ['', Validators.required],
  //     verifyOtp6: ['', Validators.required]
  //   });
  // }
  submitOtpForm() {
    this.submittedOtp = true;
    if (!this.otp || this.otp.length < 6) {
      return;
    }
    let payload = {

      // otp: this.verifyOtpForm.controls.verifyOtp1.value + this.verifyOtpForm.controls.verifyOtp2.value + this.verifyOtpForm.controls.verifyOtp3.value + this.verifyOtpForm.controls.verifyOtp4.value,
      // tslint:disable-next-line: max-line-length
      // otp: this.verifyOtpForm.controls.verifyOtp1.value + this.verifyOtpForm.controls.verifyOtp2.value + this.verifyOtpForm.controls.verifyOtp3.value + this.verifyOtpForm.controls.verifyOtp4.value + this.verifyOtpForm.controls.verifyOtp5.value + this.verifyOtpForm.controls.verifyOtp6.value
      otp: this.otp
    };
    this.commonService.showSpinner();
    this.landingService.verifyOtp(payload).subscribe(response => {
      this.commonService.hideSpinner();
      if (response.status === 200) {
        localStorage.setItem('userToken', this.accessToken);
        localStorage.setItem('gyanReferralCode', response.data.myReferralCode);
        // localStorage.setItem('userEmail', response.data.email);
        localStorage.setItem('user_idGyan', response.data._id);
        localStorage.setItem('userLocation', JSON.stringify(response.data.location));
        localStorage.setItem('userStatus', response.data.status);
        localStorage.setItem('gPhone', response.data.phone);
        localStorage.setItem('gName', response.data.fullName);
        this.commonService.showSuccess('Welcome to Gyan Dairy, Always Fresh !');

        // onPushProfile
        // clevertap.onUserLogin.push({
        //   "Site": {
        //     "Name": response.data.fullName, // String
        //     "Identity": response.data._id,  // String or number
        //     // "Email": response.data.email, // Email address of the user
        //     "Phone": response.data.countryCode+response.data.phone,  // Phone (with the country code)

        //  // optional fields. controls whether the user will be sent email, push etc.
        //     "MSG-email": false, // Disable email notifications
        //     "MSG-push": true,   // Enable push notifications
        //     "MSG-sms": true,    // Enable sms notifications
        //     "MSG-whatsapp": true, // Enable WhatsApp notifications
        //   }
        //  });
        localStorage.removeItem('verifyOtpToken');
        let location = response.data.location;
        try {
          const splitName = response.data.fullName.split(' ');
          const loc = { TownName: '', AreaName: '' };
          if (location.length) {
            location.forEach(element => {
              if (element.default === 'PRIMARY') {
                loc.TownName = element.city.location.townName;
                loc.AreaName = element.area.location.areaName;
              }
            });
          }
          clevertap.onUserLogin.push({
            "Site": {
              "Name": response.data.fullName, // String
              "Identity": response.data._id,  // String or number
              // "Email": response.data.email, // Email address of the user
              "Phone": response.data.countryCode + response.data.phone,  // Phone (with the country code)
              "first_name": splitName && splitName.length ? splitName[0] : '',
              // "last_name": splitName && splitName.length ? splitName[1] : '',
              // "Wallet Status": new Date(),
              // "Referral Code": response.data.myReferralCode,
              // "Delete Account": false,
              // "Deactivate Account": false,
              "Wallet Amount": response.data.walletAmount,
              "TownName": loc.TownName,
              "AreaName": loc.AreaName,
              "platform": localStorage.getItem('deviceType')
            }
           });
          this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.SIGN_UP_SUCCESS, {
            "Name": response.data.fullName, // String
              "Identity": response.data._id,  // String or number
              // "Email": response.data.email, // Email address of the user
              "Phone": response.data.countryCode + response.data.phone,  // Phone (with the country code)
              "first_name": splitName && splitName.length ? splitName[0] : '',
              "last_name": splitName && splitName.length ? splitName[1] : '',
              "Wallet Status": new Date(),
              "Referral Code": response.data.myReferralCode,
              "Delete Account": false,
              "Deactivate Account": false,
              "Wallet Amount": response.data.walletAmount,
              "TownName": loc.TownName,
              "AreaName": loc.AreaName
          });
          this.fireAnalytics.logFacebookPixelEvent(app_strings.FACEBOOK_PIXEL.SIGN_UP, {
            'CustomerID': response.data._id,
            'Platform': localStorage.getItem('deviceType')
          });
          this.fireAnalytics.logGoogleAnalyticsEvent(app_strings.GOOGLE_ANALYTICS.SIGN_UP, {
            'event': app_strings.GOOGLE_ANALYTICS.SIGN_UP,
            'CustomerID': response.data._id,
            'Platform': localStorage.getItem('deviceType')
          });
        } catch (error) {
        }
        clevertap.event.push(app_strings.CT_SIGNUP_SUCCESS, {
          'phoneNumber': response.data.countryCode + response.data.phone,
          "platform": localStorage.getItem('deviceType'),
          'screenName': 'Signup new user'
        });
        if (location.length) {
          localStorage.setItem('isAdd', '1');
          this.router.navigate(['/page'], { replaceUrl: true });
        } else {
          localStorage.setItem('isAdd', '0');
          const title = [];
          this.router.navigate(['page/address/newAddress'], { queryParams: { title: JSON.stringify(title), first: '1' } });
        }
        // this.router.navigate(['/page'], { replaceUrl: true });


        // to save user profile info
        // let gyanUserInfo = {
        //   countryCode: response.data.countryCode,
        //   deliveryOption: response.data.deliveryOption,
        //   email: response.data.email,
        //   fullName: response.data.fullName,
        //   image: response.data.image ? response.data.image : '',
        //   phone: response.data.phone,
        //   registrationDate: response.data.registrationDate,
        //   thumbnail: response.data.thumbnail ? response.data.thumbnail : ''
        // };
        // // localStorage.setItem('userInfo', JSON.stringify(gyanUserInfo));
        // this.sharedService.setUserProfileInfo(gyanUserInfo);

        // update device token after login
        // const deviceID = localStorage.getItem('gyannFCMdeviceId');
        // if (deviceID) {
        //   const deviceIdPayload = {
        //     deviceId: localStorage.getItem('gyannFCMdeviceId'),
        //     deviceType: 'web'
        //   };
        //   this.landingService.updateDeviceToken(deviceIdPayload).subscribe(resp => {
        //     if (resp.status === 200) {
        //     } else {
        //     }
        //   });
        // }
      } else {
        this.commonService.showWarning(response.message);
      }
    }, error => {
      this.commonService.showError(error);
      this.commonService.hideSpinner();
    });
  }
  onOtpChange(otp) {
    this.otp = otp;
    if (this.otp && this.otp.length === 6) {
      this.submitOtpForm();
    }
  }
  resendOTP(method: string) {
    this.landingService.resendOtp(method).subscribe(response => {
      if (response.status === 200) {
        clevertap.event.push(app_strings.CT_RESEND_SUCCESS, {
          "platform": localStorage.getItem('deviceType')
        });
        this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.RESEND_OTP, {
          phoneNumber: this.customerDetailsForm.controls.mobile.value
        })
        this.timeLeft = 30;
        this.resend = false;
        this.resendOtpTimer();
        this.commonService.showSuccess('OTP sent successfully');
      } else {
        this.commonService.showError('Something went wrong');
      }
    });
  }

  resendOtpTimer() {
    this.intervalId = setInterval(() => {
      this.timeLeft--;
      if (!this.timeLeft) {
        clearInterval(this.intervalId);
        this.resend = true;
      }
    }, 1000);
  }

  navigateLogin() {
    this.router.navigate(['/login']);
  }
  requestLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.userCoordinates = position;
        this.requestLocationDialog();
      }, (error) => {
        if (error.code == error.PERMISSION_DENIED) {
          this.requestLocationDialog();
        }
      });
    } else {
    }
  }

  // function to request for location
  requestLocationDialog() {
    let payload = {
      lattitude: this.userCoordinates && this.userCoordinates.coords ? this.userCoordinates.coords.latitude : '',
      lognitude: this.userCoordinates && this.userCoordinates.coords ? this.userCoordinates.coords.longitude : '',
      areaName: this.areaForRequest
    };
    this.landingService.requestAddArea(payload).subscribe(response => {
      if (response.status === 200) {
        this.openDialog();
        this.commonService.showSuccess(response.message);
        // this.activateAreaForm = false;
        // this.activateCustomerForm = true;
      } else {
        this.commonService.showWarning(response.message);
      }
    });
  }
  // keyUpEvent() {
  //   $('.digit-group').find('input').each(function () {
  //     $(this).attr('maxlength', 1);
  //     $(this).on('keyup', function (e) {
  //       var parent = $($(this).parent());
  //       if (e.keyCode === 8 || e.keyCode === 37) {
  //         var prev = parent.find('input#' + $(this).data('previous'));

  //         if (prev.length) {
  //           $(prev).select();
  //         }
  //       } else if ((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
  //         var next = parent.find('input#' + $(this).data('next'));

  //         if (next.length) {
  //           $(next).select();
  //         } else {
  //           if (parent.data('autosubmit')) {
  //             parent.submit();
  //           }
  //         }
  //       }
  //     });
  //   });
  // }
  openDialog() {
    // console.log('tableData', selectedMerchant);
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '400px',
      height: 'auto',
      disableClose: true,
      data: {type: 'noLocation'}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result !== undefined) {
        // console.log('result', result);
        this.activateAreaForm = false;
        this.activateCustomerForm = true;
      }
    });
  }

  // function to accept number only
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // function to detect current user location
  findMe() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        console.log(position);
        this.addAddressForm.controls.lat.setValue(position.coords.latitude);
        this.addAddressForm.controls.long.setValue(position.coords.longitude);
        this.ad.flat.enable();
        this.getUserAddress(position.coords.latitude, position.coords.longitude);
        // this.locate();
      });
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  }

  // function to get user formatted address using lat, long
  getUserAddress(lat, long) {
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = () => {
      if (xhttp.readyState === 4 && xhttp.status === 200) {
        const address = JSON.parse(xhttp.responseText);
        this.addAddressForm.controls.flat.setValue(address.results[0].formatted_address);
        this.checkTextareaLength(address.results[0].formatted_address.length);
        // console.log('formattedUserAddress', address.results[0].formatted_address);
      }
    };
    xhttp.open('GET', this.mapApiUrl + 'latlng=' + lat + ',' + long + '&key=' + this.apiKey, true);
    xhttp.send();
  }

  getGeocodeOnManualInputAddress() {
    const userAdd = this.addAddressForm.controls.flat.value;
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = () => {
      if (xhttp.readyState === 4 && xhttp.status === 200) {
        const latLng = JSON.parse(xhttp.responseText);
        console.log('adddress', latLng.results[0].geometry.location);
        this.addAddressForm.controls.lat.setValue(latLng.results[0].geometry.location.lat);
        this.addAddressForm.controls.long.setValue(latLng.results[0].geometry.location.lng);
      }
    };
    xhttp.open('GET', this.mapApiUrl + 'address=' + userAdd + '&components=country:IN&key=' + this.apiKey, true);
    xhttp.send();
  }

  enableToCheckLatLng() {
    this.getGeocodeOnManualInputAddress();
  }

  // function to open golabl dialog
  openDialog1() {
    // console.log('tableData', selectedMerchant);
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '600px',
      height: 'auto',
      disableClose: true,
      data: {type: 'checkAdd'}
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed', result);
      if (result === 'cancel') {
        console.log('cancelled', result);
        return;
      }
      if (result !== undefined) {
        this.activateAddressForm = false;
        this.activateCustomerForm = true;
        window.scrollTo(0,0);
      }
    });
  }

  // function on login component destroy
  ngOnDestroy() {
    clearInterval(this.intervalId);
    console.log('login component destroyed and interval cleared');
  }

  // function to open golabl dialog for change address
  openDialog2() {
    // console.log('tableData', selectedMerchant);
    const dialogRef = this.dialog.open(GlobalDialogComponent, {
      width: '600px',
      height: '450px',
      disableClose: true,
      data: {type: 'ADDRESS'}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result !== undefined) {
        // this.activateAddressForm = false;
        // this.activateCustomerForm = true;
        if (result && result.address !== '') {
          this.addAddressForm.controls.flat.setValue(result.address);
          this.addAddressForm.controls.lat.setValue(result.lat);
          this.addAddressForm.controls.long.setValue(result.lng);
          this.ad.flat.enable();
          this.checkTextareaLength(result.address.length);
        }
      }
    });
  }

  checkTextareaLength(len) {
    if (len) {
      if (len > 66 && len < 132) {
        this.styleHeight = 70;
      } else if (len > 132) {
        this.styleHeight = 100;
      }
    } else {
      this.styleHeight = 50;
    }
  }

  // function to get referral amount
  getReferralAmount() {
    this.landingService.getReferralMoney().subscribe(res => {
      if (res && res.status === 200) {
        if (res.data.status === 'ACTIVE') {
          this.isRef = true;
        }
      }
    });
  }
}
