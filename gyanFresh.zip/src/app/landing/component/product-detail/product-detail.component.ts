import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss']
})
export class ProductDetailHomeComponent implements OnInit {
  productDetailObj;

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.productDetailObj = JSON.parse(params.id);
    });
  }

  // function to navigate to login
  navigateLogin() {
    this.router.navigate(['/login']);
  }

}
