import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductDetailHomeComponent } from './product-detail.component';

describe('ProductDetailComponent', () => {
  let component: ProductDetailHomeComponent;
  let fixture: ComponentFixture<ProductDetailHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductDetailHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductDetailHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
