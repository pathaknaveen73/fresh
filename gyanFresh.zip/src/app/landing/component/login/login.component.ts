import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LandingApiService } from '../../serviceFile/landing-api.service';
import { CommonService } from 'src/app/serviceFile/common.service';
import { SharedService } from 'src/app/serviceFile/shared.service';
import { app_strings } from 'src/app/shared/_constant/app_strings';
import { FirebaseAnalyticsCustomService } from 'src/app/serviceFile/firebase-analytics-custom.service';
declare let $: any;
declare var clevertap: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  addMobileForm: FormGroup;
  submitted: boolean = false;
  verifyOtpSection: boolean = false;
  accessToken;
  submittedOtp: boolean = false;
  resend = false;
  timeLeft = 30;
  intervalId;
  config = {
    allowNumbersOnly: true,
    length: 6,
    isPasswordInput: false,
    disableAutoFocus: false,
    placeholder: '',
    inputStyles: {
      'width': '50px',
      'height': '50px'
    }
  };
  otp: string;

  constructor(private fb: FormBuilder, private router: Router, private landingApi: LandingApiService,
              private commonService: CommonService, private fireAnalytics: FirebaseAnalyticsCustomService) { }

  ngOnInit(): void {
   
    this.landingApi.setFooter('notHome');
    this.setFormField();
    localStorage.removeItem('verifyOtpToken');
  }

  get f() { return this.addMobileForm.controls; }
  setFormField() {
    this.addMobileForm = this.fb.group({
      countryCode: ['+91'],
      mobile: ['', [Validators.required, Validators.pattern(/^[1-9]\d{9}$/)]],
    });
  }
  submitForm() {
    this.submitted = true;
    if (!this.addMobileForm.valid) {
      return;
    }
    let payload = {
      countryCode: this.addMobileForm.controls.countryCode.value,
      phone: this.addMobileForm.controls.mobile.value
    }
    this.landingApi.checkAccount(payload).subscribe(data => {
      if (data.status === 200) {
        // this.setVerifyOtpFormField();
        let payload = {
          phone: this.addMobileForm.controls.mobile.value
        };
        this.landingApi.loginAccount(payload).subscribe(response => {
          if (response.status === 200) {
            try {
              clevertap.event.push(app_strings.CT_SEND_OTP_SUCCESS, {
                'phoneNumber': `${this.addMobileForm.controls.countryCode.value}${payload.phone}`,
                "platform": localStorage.getItem('deviceType')
              });
              this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.OTP_SEND, {
                phoneNumber: `${this.addMobileForm.controls.countryCode.value}${payload.phone}`
              })
            } catch (error) {
            }
            this.accessToken = response.data.token;
            this.verifyOtpSection = true;
            localStorage.setItem('verifyOtpToken', response.data.token);
            localStorage.setItem('userLocation', JSON.stringify(response.data.location));
            this.resendOtpTimer();
          } else {
            this.commonService.showError(response.message);
          }
        });
      } else {
        this.commonService.showWarning(data.message);
      }
    });
  }
  resendOtpTimer() {
    this.intervalId = setInterval(() => {
      this.timeLeft--;
      if (!this.timeLeft) {
        clearInterval(this.intervalId);
        this.resend = true;
      }
    }, 1000);
  }
  resendOTP(method: string) {
    this.landingApi.resendOtp(method).subscribe(response => {
      if (response.status === 200) {
        clevertap.event.push(app_strings.CT_RESEND_SUCCESS, {
          "platform": localStorage.getItem('deviceType')
        });
        this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.RESEND_OTP, {
          phoneNumber: `${this.addMobileForm.controls.countryCode.value}${this.addMobileForm.controls.mobile.value}`
        })
        this.timeLeft = 30;
        this.resend = false;
        this.resendOtpTimer();
        this.commonService.showSuccess('OTP sent successfully');
      } else {
        this.commonService.showError('Something went wrong');
      }
    });
  }
  navigateRegister() {
    this.router.navigate(['/register']);
  }
  // get() { return this.verifyOtpForm.controls; }
  // setVerifyOtpFormField() {
  //   this.verifyOtpForm = this.fb.group({
  //     verifyOtp: ['', Validators.required]
  //   });
  //   // this.resendOtpTimer();
  // }
  submitOtpForm() {
    this.submittedOtp = true;
    if (!this.otp || this.otp.length < 6) {
      return;
    }
    let payload = {
      // otp: this.verifyOtpForm.controls.verifyOtp1.value + this.verifyOtpForm.controls.verifyOtp2.value + this.verifyOtpForm.controls.verifyOtp3.value + this.verifyOtpForm.controls.verifyOtp4.value,
      // tslint:disable-next-line: max-line-length
      // otp: this.verifyOtpForm.controls.verifyOtp1.value + this.verifyOtpForm.controls.verifyOtp2.value + this.verifyOtpForm.controls.verifyOtp3.value + this.verifyOtpForm.controls.verifyOtp4.value + this.verifyOtpForm.controls.verifyOtp5.value + this.verifyOtpForm.controls.verifyOtp6.value
      otp: this.otp
    };
    this.commonService.showSpinner();
    this.landingApi.verifyOtp(payload).subscribe(response => {
      this.commonService.hideSpinner();
      if (response.status === 200) {
        // debugger
        localStorage.setItem('userToken', this.accessToken);
        localStorage.setItem('gyanReferralCode', response.data.myReferralCode);
        // localStorage.setItem('userEmail', response.data.email);
        localStorage.setItem('gName', response.data.fullName);
        localStorage.setItem('user_idGyan', response.data._id);
        localStorage.setItem('userStatus', response.data.status);
        localStorage.setItem('gPhone', response.data.phone);
        this.commonService.showSuccess('Login Successfully');
        localStorage.removeItem('verifyOtpToken');
        let location = response.data.location;
        // location = [];
        try {
          const splitName = response.data.fullName.split(' ');
          const loc = { TownName: '', AreaName: '' };
          if (location.length) {
            location.forEach(element => {
              if (element.default === 'PRIMARY') {
                loc.TownName = element.city.location.townName;
                loc.AreaName = element.area.location.areaName;
              }
            });
          }
          clevertap.onUserLogin.push({
            "Site": {
              "Name": response.data.fullName, // String
              "Identity": response.data._id,  // String or number
              // "Email": response.data.email, // Email address of the user
              "Phone": response.data.countryCode + response.data.phone,  // Phone (with the country code)
              "first_name": splitName && splitName.length ? splitName[0] : '',
              // "last_name": splitName && splitName.length ? splitName[1] : '',
              // "Wallet Status": new Date(),
              // "Referral Code": response.data.myReferralCode,
              // "Delete Account": false,
              // "Deactivate Account": false,
              "Wallet Amount": response.data.walletAmount,
              "TownName": loc.TownName,
              "AreaName": loc.AreaName,
              "platform": localStorage.getItem('deviceType')
            }
           });
          this.fireAnalytics.logEventCustom(app_strings.FIREBASE_ANALYTICS.LOGIN_SUCCESS, {
            "Name": response.data.fullName, // String
              "Identity": response.data._id,  // String or number
              // "Email": response.data.email, // Email address of the user
              "Phone": response.data.countryCode + response.data.phone,  // Phone (with the country code)
              "first_name": splitName && splitName.length ? splitName[0] : '',
              "last_name": splitName && splitName.length ? splitName[1] : '',
              "Wallet Status": new Date(),
              "Referral Code": response.data.myReferralCode,
              "Delete Account": false,
              "Deactivate Account": false,
              "Wallet Amount": response.data.walletAmount,
              "TownName": loc.TownName,
              "AreaName": loc.AreaName,
          });
        } catch (error) {
        }
        clevertap.event.push(app_strings.CT_LOGIN_SUCCESS, {
          'phoneNumber': response.data.countryCode + response.data.phone,
          "platform": localStorage.getItem('deviceType')
        });
        clevertap.event.push('login', {
          "platform": localStorage.getItem('deviceType')
        });
        //  debugger
        if (location.length) {
          localStorage.setItem('isAdd', '1');
          this.router.navigate(['/page'], { replaceUrl: true });
        } else {
          localStorage.setItem('isAdd', '0');
          const title = [];
          this.router.navigate(['page/address/newAddress'], { queryParams: { title: JSON.stringify(title), first: '1' } });
        }


        // to save user profile info
        // let gyanUserInfo = {
        //   countryCode: response.data.countryCode,
        //   deliveryOption: response.data.deliveryOption,
        //   email: response.data.email,
        //   fullName: response.data.fullName,
        //   image: response.data.image ? response.data.image : '',
        //   phone: response.data.phone,
        //   registrationDate: response.data.registrationDate,
        //   thumbnail: response.data.thumbnail ? response.data.thumbnail : ''
        // };
        // // localStorage.setItem('userInfo', JSON.stringify(gyanUserInfo));
        // this.sharedService.setUserProfileInfo(gyanUserInfo);

        // update device token after login
        // const deviceID = localStorage.getItem('gyannFCMdeviceId');
        // if (deviceID) {
        //   const deviceIdPayload = {
        //     deviceId: localStorage.getItem('gyannFCMdeviceId'),
        //     deviceType: 'web'
        //   };
        //   this.landingApi.updateDeviceToken(deviceIdPayload).subscribe(resp => {
        //     if (resp.status === 200) {
        //     } else {
        //     }
        //   });
        // }
      } else {
        this.commonService.showWarning(response.message);
      }
    }, error => {
      this.commonService.showError(error);
      this.commonService.hideSpinner();
    });
  }




  
  onOtpChange(otp) {
    // console.log('checkOTP', otp);

    this.otp = otp;
    if (this.otp && this.otp.length === 6) {
      this.submitOtpForm();
    }
  }

  // keyUpEvent(event) {
  //   const charCode = (event.which) ? event.which : event.keyCode;
  //   if (charCode > 31 && (charCode < 48 || charCode > 57)) {
  //     return false;
  //   }
  //   // return true;
  //   $('.digit-group').find('input').each(function () {
  //     $(this).attr('maxlength', 1);
  //     $(this).on('keyup', function (e) {
  //       var parent = $($(this).parent());
  //       if (e.keyCode === 8 || e.keyCode === 37) {
  //         var prev = parent.find('input#' + $(this).data('previous'));

  //         if (prev.length) {
  //           $(prev).select();
  //         }
  //       } else if ((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
  //         var next = parent.find('input#' + $(this).data('next'));

  //         if (next.length) {
  //           $(next).select();
  //         } else {
  //           if (parent.data('autosubmit')) {
  //             parent.submit();
  //           }
  //         }
  //       }
  //     });
  //   });
  // }

  // function to accept number only
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // function on login component destroy
  ngOnDestroy() {
    clearInterval(this.intervalId);
    // alert('reoload or close')
    localStorage.removeItem('verifyOtpToken');
  }

}
