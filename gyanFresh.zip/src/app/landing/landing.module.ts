import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { LandingRoutingModule } from './landing-routing.module';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { RegisterComponent } from './component/register/register.component';
import { LandingApiService } from './serviceFile/landing-api.service';
import { LandingComponent } from './landing.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import {MatSelectModule} from '@angular/material/select';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import { OfferDetailHomeComponent } from './component/offer-detail/offer-detail.component';
import { ProductDetailHomeComponent } from './component/product-detail/product-detail.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
import {MatRadioModule} from '@angular/material/radio';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { NgOtpInputModule } from 'ng-otp-input';
import { CircleLoaderModule } from '../circle-loader/circle-loader.module';
import { StaticModule } from '../static/static.module';
import { ContentComponent } from './component/content/content.component';


@NgModule({
  declarations: [HomeComponent, LoginComponent, RegisterComponent, LandingComponent, HeaderComponent, FooterComponent, ProductDetailHomeComponent, OfferDetailHomeComponent, ContentComponent],
  imports: [
    CommonModule,
    LandingRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    LazyLoadImageModule,
    CarouselModule,
    MatRadioModule,
    MatAutocompleteModule,
    NgOtpInputModule,
    CircleLoaderModule,
    StaticModule
  ],
  providers: [LandingApiService],
  exports: [ProductDetailHomeComponent, OfferDetailHomeComponent]
})
export class LandingModule { }
