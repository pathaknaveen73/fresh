import { Injectable } from '@angular/core';
import { CanLoad, Route, UrlSegment, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CommonService } from '../serviceFile/common.service';

@Injectable({
  providedIn: 'root'
})
export class ReferGuard implements CanLoad {
  constructor(private router: Router, private commonService: CommonService) {}
  // canLoad(
  //   route: Route,
  //   segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
  //   return true;
  // }
  canLoad(route: Route) {
    const storage: any = localStorage.getItem('isRef');
    if (storage && storage === '1') {
      // this.router.navigate(['/page'], { replaceUrl: true });
      return true;
    }
    this.commonService.showError('Unexpected error occurred, please try again');
    this.router.navigate(['/page'], { replaceUrl: true });
    return false;
  }
}
