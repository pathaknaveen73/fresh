	$(document).ready(function () {
		$(window).scroll(function () {
			var scroll = $(window).scrollTop();
			if (scroll > 80) {
				$(".navbar-fixed-top").css({"background":"#0a94d6","box-shadow":"-1px 6px 25px -7px rgba(10,148,214,1)"});
				$(".navbar-nav a").css("color", "black");
			}
			else {
				$(".navbar-fixed-top").css({"background":"transparent","box-shadow":"0px 0px 0px 0px rgba(0,0,0,0"});
				$(".navbar-nav a").css("color", "#333");

			}
		});
	});




	