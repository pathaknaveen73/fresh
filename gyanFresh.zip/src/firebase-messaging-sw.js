importScripts('https://www.gstatic.com/firebasejs/7.6.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/7.6.0/firebase-messaging.js');
// importScripts('https://s3-eu-west-1.amazonaws.com/static.wizrocket.com/js/sw_webpush.js');
firebase.initializeApp({
  apiKey: "AIzaSyB1y_lvJCzdb4XMK4jqD-QG4hKrFzapqaI",
  authDomain: "gyan-fresh-278410.firebaseapp.com",
  databaseURL: "https://gyan-fresh-278410.firebaseio.com",
  projectId: "gyan-fresh-278410",
  storageBucket: "gyan-fresh-278410.appspot.com",
  messagingSenderId: "90505039313",
  appId: "1:90505039313:web:abe156b515fec9d011e4f0"
});
const messaging = firebase.messaging();
