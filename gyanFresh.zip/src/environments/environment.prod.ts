import { app_strings } from "src/app/shared/_constant/app_strings";

export const apiVersion = 'v12';
export const environment = {
  production: false,
  // api_url: `http://13.127.3.182:3000/api/user/${apiVersion}/`, // development new testing only
  // api_url: `https://replica.gyandairy.com/api/user/${apiVersion}/`, // development
  paytm: {
    // paytm staging
    mid: app_strings.PAYTM_STAGING.MID,
    websiteName: app_strings.PAYTM_STAGING.website,
    script: 'paytmStaging'

    // live paytm
    // mid: app_strings.PAYTM_PRODUCTION.MID,
    // websiteName: app_strings.PAYTM_PRODUCTION.website,
    // script: 'paytmProd'
  },
  // api_url: `https://api.gyandairy.com/api/user/${apiVersion}/`, // live
  // api_url: `http://3.109.142.12:3000/api/user/${apiVersion}/`, // preprod
   api_url: `https://preprod.gyanfresh.com/api/user/${apiVersion}/`, // preprod
  //  api_url: `http://192.0.0.174:6464/api/user/${apiVersion}/`, // local
  // paytm: {
  //   mid: app_strings.PAYTM_PRODUCTION.MID,
  //   websiteName: app_strings.PAYTM_PRODUCTION.website,
  //   script: 'paytmProd'
  // },
  firebase: {
    apiKey: 'AIzaSyB1y_lvJCzdb4XMK4jqD-QG4hKrFzapqaI',
    authDomain: 'gyan-fresh-278410.firebaseapp.com',
    databaseURL: 'https://gyan-fresh-278410.firebaseio.com',
    projectId: 'gyan-fresh-278410',
    storageBucket: 'gyan-fresh-278410.appspot.com',
    messagingSenderId: '90505039313',
    appId: '1:90505039313:web:abe156b515fec9d011e4f0',
  },
  razor_url: 'https://api.razorpay.com/v1/orders'
};
